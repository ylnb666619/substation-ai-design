﻿# PrefabSubstation-AI Report

Status: passed

Scene: Placed Components

Module: not_selected

Dimension mode: adaptive

Component count: 3166

## BOM

- 预制舱轴流风机通风口 x 82
- 变电设备槽钢焊接底座 x 74
- 干式变压器 x 74
- 非设备区底座（槽钢梁格） x 283
- GCS抽屉式低压配电柜 x 178
- 玻璃窗 x 10
- 预制舱空心方矩管立柱 x 600
- 预制舱绝缘内壁面层 x 61
- 中置式高压开关柜 x 73
- 手提式干粉灭火器 x 150
- 预制舱三角复合山墙挡墙 x 124
- 屋面面层（分层做法+密封体系） x 75
- 预制舱外墙（三层复合墙） x 1226
- 壁挂式终端配电箱 x 4
- 预制舱逃生门 x 77
- 预制舱屋面龙骨 x 75

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
