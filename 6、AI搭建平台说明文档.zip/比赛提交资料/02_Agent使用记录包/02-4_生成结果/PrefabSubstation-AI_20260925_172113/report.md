﻿# PrefabSubstation-AI Report

Status: passed

Scene: Placed Components

Module: not_selected

Dimension mode: adaptive

Component count: 3552

## BOM

- 预制舱轴流风机通风口 x 92
- 变电设备槽钢焊接底座 x 74
- 干式变压器 x 83
- 非设备区底座（槽钢梁格） x 293
- GCS抽屉式低压配电柜 x 190
- GGD固定式低压配电柜 x 9
- 玻璃窗 x 30
- 预制舱空心方矩管立柱 x 680
- HXGN环网开关柜 x 6
- 预制舱绝缘内壁面层 x 79
- 中置式高压开关柜 x 80
- 手提式干粉灭火器 x 170
- 预制舱三角复合山墙挡墙 x 144
- 屋面面层（分层做法+密封体系） x 85
- 预制舱外墙（三层复合墙） x 1360
- 壁挂式终端配电箱 x 5
- 预制舱逃生门 x 87
- 预制舱屋面龙骨 x 85

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
