﻿# PrefabSubstation-AI Report

Status: passed

Scene: Placed Components

Module: not_selected

Dimension mode: adaptive

Component count: 1361

## BOM

- 预制舱轴流风机通风口 x 22
- 变电设备槽钢焊接底座 x 74
- 干式变压器 x 20
- 非设备区底座（槽钢梁格） x 227
- GCS抽屉式低压配电柜 x 40
- 玻璃窗 x 2
- 预制舱空心方矩管立柱 x 152
- 预制舱绝缘内壁面层 x 5
- 中置式高压开关柜 x 20
- 手提式干粉灭火器 x 38
- 预制舱三角复合山墙挡墙 x 12
- 屋面面层（分层做法+密封体系） x 19
- 预制舱外墙（三层复合墙） x 688
- 壁挂式终端配电箱 x 4
- 预制舱逃生门 x 19
- 预制舱屋面龙骨 x 19

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
