﻿# PrefabSubstation-AI Report

Status: failed

Scene: PrefabSubstation-AI

Module: not_selected

Dimension mode: adaptive

Component count: 0


## Failure

生成前约束检查未通过。
- {'code': 'equipment_collision', 'message': '检测到设备碰撞：中置柜-01 / 干式变压器-02、干式变压器-01 / 干式变压器-02。'}
- {'code': 'minimal_size_fit', 'message': '舱体尺寸不足：当前14000×5200mm，最小需要18598×4995mm。'}

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
