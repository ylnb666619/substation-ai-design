﻿# PrefabSubstation-AI Report

Status: failed

Scene: PrefabSubstation-AI

Module: not_selected

Dimension mode: adaptive

Component count: 0


## Failure

严格尺寸模式无法完成装配：舱体长度为10mm，超出允许范围6000~30000mm。；舱体宽度为1mm，超出允许范围2400~8000mm。；舱体高度为1000mm，超出允许范围2800~6000mm。
- 舱体长度为10mm，超出允许范围6000~30000mm。
- 舱体宽度为1mm，超出允许范围2400~8000mm。
- 舱体高度为1000mm，超出允许范围2800~6000mm。

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
