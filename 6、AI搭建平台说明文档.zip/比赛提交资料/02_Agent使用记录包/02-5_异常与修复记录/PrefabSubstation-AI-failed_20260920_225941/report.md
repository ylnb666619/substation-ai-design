﻿# PrefabSubstation-AI Report

Status: failed

Scene: PrefabSubstation-AI

Module: not_selected

Dimension mode: adaptive

Component count: 0


## Failure

生成前约束检查未通过。
- {'code': 'equipment_region_fit', 'message': '设备完整包络超出设备区：GCS低压柜-02、GCS低压柜-04。'}
- {'code': 'minimal_size_fit', 'message': '舱体尺寸不足：当前8100×4100mm，最小需要8435×2873mm。'}

## Warnings


## Assumptions

- 默认尺寸、通道净距、设备顺序和平面模组均来自程序侧内置数据，尚未经过工程侧复核。
- 方案包中的模型、BOM 和参数表用于程序联调和方案预演，不替代正式设计校审。
- 构件几何来自已注册的真实插件；缺失构件或参数校验失败时必须优先修复数据源。
