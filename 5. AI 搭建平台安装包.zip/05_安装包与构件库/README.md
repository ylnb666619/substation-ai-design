# 05_安装包与构件库

本目录是预制舱变电站自动建模项目的安装交付件、配电设备构件库源码副本及配套数据清单。安装包版本为 `1.2.1`，构建日期为 `2026-09-29`，整理日期为 `2026-09-29`。

## 一、交付内容

### 05-1_官方安装包

- `PrefabSubstation-AI-BIMBase-Setup-v1.2.1.exe`：正式 Windows 安装程序。
- `PrefabSubstation-AI-BIMBase-Installer-v1.2.1.zip`：安装包归档件。
- `安装说明.md`：面向安装人员的简要说明。
- `PACKAGE_MANIFEST.json`：安装包清单、版本与目标环境。
- `EXE.sha256`、`SHA256SUMS.txt`：安装文件校验值。

安装程序同时包含：

- `PrefabSubstation-AI 1.2.0`：自动建模 Agent 插件。
- `配电设备 1.2.1`：预制舱配电设备构件库插件。

安装程序会自动检测 BIMBase 的 Python 插件根目录，并改写两个 `.pyplugin` 入口中的部署路径。安装完成后无需手工复制插件目录。

### 05-2_配电设备构件库

- `README.md`：本目录的用途、路径占位符说明和手工部署步骤。
- `配电设备.pyplugin`：构件库插件入口。
- `配电设备\`：已部署验证版本的构件源码副本。
- `icons\`：构件库使用的图标资源。

本目录包含 `25` 个注册构件，覆盖设备、基础、围护、屋面、内装和支撑六类。基础类中的 `左右三段式底座`、`错缝拼接式底座`、`四区密格式底座` 分别对应 5000×2500mm、4000×3000mm 和 4500×3050mm 三种固定网格真实构件。构件内部稳定文件名保留图号，用户可见名称与提示词名称保持一致。构件库打包源取自本机 BIMBase 部署目录；打包前已逐文件比较，部署版与工程源码版的 `25` 个 `.py` 文件 SHA256 全部一致。

`配电设备.pyplugin` 的 `PluginModule` 字段统一写作 `[BIMBASE_PLUGIN_ROOT]\配电设备\` 占位符，由 `05-1_官方安装包` 的安装程序在安装时替换为实际路径；本交付目录不包含任何开发机固定路径。手工部署步骤见 `05-2_配电设备构件库\README.md`。

### 05-3_构件库数据与清单

- `component_registry.json`：`25` 个真实构件的注册表，定义参数、语义、放置属性和调用路径。
- `module_library.json`：`3` 个平面模组，包括标准单舱、双舱并联和单舱变体。
- `foundation_pattern_library.json`：`4` 类整舱槽钢底座方案，包括标准三段式底座、左右三段式底座、四区密格式底座和错缝拼接式底座。
- `构件库清单.csv`：从注册表生成的构件索引，便于比赛评审和工程复核。
- `版本与数据边界.md`：版本关系、数据用途和工程复核边界。

## 二、版本与环境

| 项目 | 版本或要求 |
| --- | --- |
| 安装包 | `1.2.1` |
| 自动建模 Agent 插件 | `1.2.0` |
| 配电设备构件库插件 | `1.2.1` |
| BIMBase | `2025 / Pro / V1.6` |
| Python 插件 SDK | `1.6.2` |
| 目标插件目录 | `[BIMBASE_PLUGIN_ROOT]`，由安装程序自动探测 |

## 三、安装与首次使用

1. 关闭 BIMBase。
2. 双击 `PrefabSubstation-AI-BIMBase-Setup-v1.2.1.exe`。
3. 安装程序检测到 BIMBase 后，将两个插件写入目标 `pythonplugin` 目录。
4. 启动 BIMBase，确认插件面板中出现“变电站自动建模 AI”和“配电设备”。
5. 首次使用 AI 生成功能时，打开“DeepSeek 配置”，填写 API 密钥并保存一次。

安装包不包含 API 密钥。密钥只保存在当前 Windows 用户的本机配置中，不进入本交付目录、不写入构件库，也不需要每次启动都重新填写。

## 四、校验方式

`05-1_官方安装包\SHA256SUMS.txt` 记录安装程序和 ZIP 的 SHA256。安装程序本身的基准值为：

```text
0652302447450F26F2CED89A049316C092D2575E7AB650A9C813A6DCC08DCF38
```

可在 PowerShell 中使用以下命令复核：

```powershell
Get-FileHash .\05-1_官方安装包\PrefabSubstation-AI-BIMBase-Setup-v1.2.1.exe -Algorithm SHA256
```

## 五、边界与提交口径

- 本项目 Agent 无 Skill 使用，不注册、不加载、不调用 Skill；安装包和构件库中也不包含 Skill 定义。
- 构件注册表、平面模组和底座方案中的部分尺寸、净距、设备顺序和默认数量属于程序侧内置假设，尚未替代工程规范审查；正式设计使用前必须进行工程复核。
- 安装包排除 `local.deepseek.json`、调试日志、运行导出方案包、`__pycache__`、`.vscode`、开发用 C++/CMake 构建目录和 Markdown 工作记录。
- 构件源码、注册表、模组库和底座方案库保持文件级独立，便于比赛评审、替换和后续维护。

## 六、目录结构

```text
05_安装包与构件库/
├─ README.md
├─ SHA256SUMS.txt
├─ 05-1_官方安装包/
│  ├─ PrefabSubstation-AI-BIMBase-Setup-v1.2.1.exe
│  ├─ PrefabSubstation-AI-BIMBase-Installer-v1.2.1.zip
│  ├─ 安装说明.md
│  ├─ PACKAGE_MANIFEST.json
│  ├─ EXE.sha256
│  └─ SHA256SUMS.txt
├─ 05-2_配电设备构件库/
│  ├─ README.md
│  ├─ 配电设备.pyplugin
│  └─ 配电设备/
│     ├─ 25 个构件 .py 文件
│     └─ icons/
└─ 05-3_构件库数据与清单/
   ├─ component_registry.json
   ├─ module_library.json
   ├─ foundation_pattern_library.json
   ├─ 构件库清单.csv
   └─ 版本与数据边界.md
```
