# -*- coding: utf-8 -*-
"""
手提式干粉灭火器 - 参数化构件 (MFZ/ABC4)
所有参数可调，构件细节完整
"""
from pyp3d import *


class 灭火器(Component):
    def __init__(self):
        Component.__init__(self)
        self['筒体半径']     = Attr(65,   obvious=True, group='筒体',   description='筒体外半径(mm)')
        self['筒体高度']     = Attr(380,  obvious=True, group='筒体',   description='筒体高度(mm)')
        self['可视窗高度']   = Attr(35,   obvious=True, group='筒体',   description='正面观察窗高度(mm)')
        self['可视窗宽度']   = Attr(22,   obvious=True, group='筒体',   description='正面观察窗宽度(mm)')
        self['底座高度']     = Attr(12,   obvious=True, group='底座',   description='底座环高度(mm)')
        self['底座外扩']     = Attr(5,    obvious=True, group='底座',   description='底座半径超出筒体的量(mm)')
        self['瓶颈高度']     = Attr(18,   obvious=True, group='瓶颈',   description='瓶颈锥形段高度(mm)')
        self['瓶颈顶半径']   = Attr(28,   obvious=True, group='瓶颈',   description='瓶颈顶部半径(mm)')
        self['阀体高度']     = Attr(55,   obvious=True, group='阀体',   description='阀体总高度(mm)')
        self['阀体宽度']     = Attr(80,   obvious=True, group='阀体',   description='阀体左右宽度(mm)')
        self['阀体进深']     = Attr(55,   obvious=True, group='阀体',   description='阀体前后进深(mm)')
        self['提把厚度']     = Attr(6,    obvious=True, group='提把',   description='提把截面厚度(mm)')
        self['提把拱高']     = Attr(50,   obvious=True, group='提把',   description='提把拱起高度(mm)')
        self['提把进深']     = Attr(5,    obvious=True, group='提把',   description='提把向前伸出距离(mm)')
        self['压把长度']     = Attr(95,   obvious=True, group='压把',   description='压把总长度(mm)')
        self['压把宽度']     = Attr(14,   obvious=True, group='压把',   description='压把宽度(mm)')
        self['压把厚度']     = Attr(5,    obvious=True, group='压把',   description='压把厚度(mm)')
        self['压力表半径']   = Attr(20,   obvious=True, group='压力表', description='表盘半径(mm)')
        self['压力表厚度']   = Attr(5,    obvious=True, group='压力表', description='表盘厚度(mm)')
        self['喷管半径']     = Attr(9,    obvious=True, group='喷管',   description='喷管截面半径(mm)')
        self['喷管水平长']   = Attr(75,   obvious=True, group='喷管',   description='水平段长度(mm)')
        self['喷管垂直长']   = Attr(280,  obvious=True, group='喷管',   description='垂直段长度(mm)')
        self['喷嘴长度']     = Attr(65,   obvious=True, group='喷嘴',   description='锥形段长度(mm)')
        self['喷嘴末端半径'] = Attr(5,    obvious=True, group='喷嘴',   description='出口半径(mm)')
        self['保险销环半径'] = Attr(12,   obvious=True, group='保险销', description='拉环半径(mm)')
        self['保险销杆粗']   = Attr(3,    obvious=True, group='保险销', description='销杆截面半径(mm)')
        self['灭火器']       = Attr(None, show=True)
        self["标称重量"] = Attr(6.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")
        self.replace()

    @export
    def replace(self):
        RED   = (0.85, 0.08, 0.08, 1)
        DRED  = (0.70, 0.09, 0.09, 1)
        BLK   = (0.12, 0.12, 0.12, 1)
        BRASS = (0.75, 0.60, 0.28, 1)
        WHT   = (0.95, 0.95, 0.95, 1)
        SILV  = (0.72, 0.72, 0.72, 1)

        R  = self['筒体半径'];     HB = self['筒体高度']
        Hb = self['底座高度'];     Rb = self['底座外扩']
        Hn = self['瓶颈高度'];     Rn = self['瓶颈顶半径']
        Hv = self['阀体高度'];     Wv = self['阀体宽度'];    Dv = self['阀体进深']
        Th = self['提把厚度'];     Hh = self['提把拱高'];    Dh = self['提把进深']
        Ll = self['压把长度'];     Wl = self['压把宽度'];    Tl = self['压把厚度']
        Rg = self['压力表半径'];   Tg = self['压力表厚度']
        Rh = self['喷管半径'];     Lh = self['喷管水平长'];  Lv = self['喷管垂直长']
        Ln = self['喷嘴长度'];     Re = self['喷嘴末端半径']
        Rp = self['保险销环半径']; Pr = self['保险销杆粗']
        Hs = self['可视窗高度'];   Ws = self['可视窗宽度']

        z0 = 0
        z1 = z0 + Hb
        z2 = z1 + HB
        z3 = z2 + Hn
        z4 = z3 + Hv

        # === 底座 - 黑色圆环 ===
        b_outer = Ellipse(Vec3(0, 0, z0), Vec3(R+Rb, 0, 0), Vec3(0, R+Rb, 0), 0, pi*2)
        b_inner = Ellipse(Vec3(0, 0, z0), Vec3(R-3, 0, 0), Vec3(0, R-3, 0), 0, pi*2)
        base = ExtrusionPlus([ContourLine([b_outer, b_inner])], Vec3(0, 0, Hb)).color(BLK)

        # === 筒体 - 红色圆柱 ===
        body = Cone(Vec3(0, 0, z1), Vec3(0, 0, z2), R, R).color(RED)

        # === 加强环 ===
        body_ring = TorusPipe(Vec3(0, 0, z1+HB*0.45), Vec3(1,0,0), Vec3(0,1,0), R+1, 3, pi*2).color(RED)

        # === 可视窗 ===
        wz = z1 + HB*0.65
        wy = R - 2
        sight = Box(Vec3(-Ws/2, wy, wz-Hs/2), Vec3(-Ws/2, wy+3, wz+Hs/2),
                    Vec3(1,0,0), Vec3(0,0,1), Ws, Hs, Ws, Hs).color((0.98, 0.98, 0.70, 0.55))

        # === 瓶颈 - 锥形过渡 ===
        neck = Cone(Vec3(0, 0, z2), Vec3(0, 0, z3), R, Rn).color(DRED)

        # === 阀体 - 黄铜色方块 ===
        valve = Box(Vec3(-Wv/2, -Dv/2, z3), Vec3(-Wv/2, -Dv/2, z4),
                    Vec3(1,0,0), Vec3(0,1,0), Wv, Dv, Wv, Dv).color(BRASS)

        # === 提把 - U形把手 ===
        hx = Wv/2 - Th/2
        hy = Dv/2 + Dh
        legL = Box(Vec3(-hx-Th/2, hy-Th/2, z4), Vec3(-hx-Th/2, hy-Th/2, z4+Hh),
                   Vec3(1,0,0), Vec3(0,1,0), Th, Th, Th, Th)
        legR = Box(Vec3(hx-Th/2, hy-Th/2, z4), Vec3(hx-Th/2, hy-Th/2, z4+Hh),
                   Vec3(1,0,0), Vec3(0,1,0), Th, Th, Th, Th)
        barT = Box(Vec3(-Wv/2, hy-Th/2, z4+Hh-Th), Vec3(-Wv/2, hy-Th/2, z4+Hh),
                   Vec3(1,0,0), Vec3(0,1,0), Wv, Th, Wv, Th)
        handle = unite(legL, legR, barT).color(BLK)

        # === 压把 - 黑色压杆 ===
        press = Box(Vec3(-Ll/2, Dv/2-Tl, z4+Hh*0.35-Tl/2),
                    Vec3(-Ll/2, Dv/2-Tl, z4+Hh*0.35+Tl/2),
                    Vec3(1,0,0), Vec3(0,1,0), Ll, Tl, Ll, Tl).color(BLK)

        # === 压力表 - 白盘+黑框+红指针 ===
        gz = z3 + Hv*0.55
        gy = Dv/2
        g_disk   = Cone(Vec3(0, gy, gz), Vec3(0, gy+Tg, gz), Rg, Rg).color(WHT)
        g_ring   = TorusPipe(Vec3(0, gy+Tg*0.5, gz), Vec3(0,1,0), Vec3(0,0,1), Rg+2, 2, pi*2).color(BLK)
        g_needle = Box(Vec3(-1, gy+Tg+1, gz), Vec3(-1, gy+Tg+1, gz+Rg*0.45),
                       Vec3(1,0,0), Vec3(0,1,0), 2, 1, 2, 1).color((0.95, 0.2, 0.2, 1))

        # === 保险销 + 拉环 - 银色 ===
        px = Wv/2 - 8
        pz = z3 + Hv*0.65
        pin_rod  = Cone(Vec3(px, -Dv/2-3, pz), Vec3(px, Dv/2+3, pz), Pr, Pr).color(SILV)
        pin_loop = TorusPipe(Vec3(px, Dv/2+8, pz), Vec3(0,1,0), Vec3(0,0,1), Rp, 2, pi*2).color(SILV)

        # === 喷管 + 喷嘴 ===
        hsx = Wv/2
        hsz = z3 + Hv*0.45
        hose_h  = Cone(Vec3(hsx, 0, hsz), Vec3(hsx+Lh, 0, hsz), Rh, Rh)
        hose_v  = Cone(Vec3(hsx+Lh, 0, hsz), Vec3(hsx+Lh, 0, hsz-Lv), Rh, Rh)
        hose    = unite(hose_h, hose_v).color(BLK)
        nz = hsz - Lv
        nozzle  = Cone(Vec3(hsx+Lh, 0, nz), Vec3(hsx+Lh, 0, nz-Ln), Rh, Re).color(BLK)

        # === 最终合并 ===
        self['灭火器'] = combine(
            base, body, body_ring, sight, neck, valve,
            handle, press, g_disk, g_ring, g_needle,
            pin_rod, pin_loop, hose, nozzle)


if __name__ == '__main__':
    FinalGeometry = 灭火器()
    place(FinalGeometry)
