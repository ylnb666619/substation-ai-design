# -*- coding: utf-8 -*-
"""
预制舱绝缘内壁面层

改为普通单击放置构件，不再使用四点勾画。
构件作用类似一块铺在地面的绝缘垫/地毯，支持保存 BIMBase 材质。
"""

from pyp3d import *


DEFAULT_LENGTH = 12000.0
DEFAULT_WIDTH = 3400.0
DEFAULT_THICKNESS = 8.0


def _着色(几何体, 预设材质, 保存材质):
    if 保存材质:
        return 几何体.material(保存材质)

    if 预设材质 == "橡胶":
        return 几何体.color(0.08, 0.08, 0.08, 1.0)

    return 几何体.color(0.82, 0.82, 0.82, 1.0)


class 预制舱绝缘内壁面层(Component):
    def __init__(self):
        Component.__init__(self)

        self["预制舱绝缘内壁面层"] = Attr(None, show=True)

        self["场布分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("面层", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("预制舱绝缘内壁面层", obvious=True, readonly=True, group="构件分类")

        self["长度"] = Attr(
            DEFAULT_LENGTH,
            obvious=True,
            group="主体尺寸",
            description="面层长度 X(mm)",
        )
        self["宽度"] = Attr(
            DEFAULT_WIDTH,
            obvious=True,
            group="主体尺寸",
            description="面层宽度 Y(mm)",
        )
        self["板厚"] = Attr(
            DEFAULT_THICKNESS,
            obvious=True,
            group="主体尺寸",
            description="面层厚度 Z(mm)",
        )

        self["材质"] = Attr(
            "橡胶",
            obvious=True,
            combo=["橡胶", "塑料"],
            group="材质",
            description="默认外观类型",
        )
        self["面层材质"] = Attr(
            "",
            obvious=True,
            material=True,
            group="材质",
            description="BIMBase 材质，设置后将随构件保存",
        )

        self["X"] = Attr(0.0, obvious=True, group="定位", description="插入点 X(mm)")
        self["Y"] = Attr(0.0, obvious=True, group="定位", description="插入点 Y(mm)")
        self["Z"] = Attr(0.0, obvious=True, group="定位", description="插入点 Z(mm)")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        length = max(float(self["长度"]), 10.0)
        width = max(float(self["宽度"]), 10.0)
        thickness = max(float(self["板厚"]), 2.0)

        self["长度"] = length
        self["宽度"] = width
        self["板厚"] = thickness

        x = float(self["X"])
        y = float(self["Y"])
        z = float(self["Z"])

        preset_material = str(self["材质"])
        saved_material = self["面层材质"]

        panel = scale(length, width, thickness) * Cube()
        panel = _着色(panel, preset_material, saved_material)

        # 以左下角底面为插入基点，单击放置后直接生成整块面层。
        self["预制舱绝缘内壁面层"] = translate(x, y, z) * panel

        # —— 自重：面积 × 板厚 × 材质密度 ——
        _rho = 950.0 if "塑料" in str(self["材质"]) else 1200.0
        self["自重_kg"] = round(length * width * thickness * _rho / 1e9, 2)


if __name__ == "__main__":
    FinalGeometry = 预制舱绝缘内壁面层()
    place(FinalGeometry)
