# -*- coding: utf-8 -*-
from pyp3d import *


class GGD低压柜(Component):
    """GGD 固定式低压柜。"""

    def __init__(self):
        Component.__init__(self)
        self["GGD低压柜"] = Attr(None, show=True)

        self["空间分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("GGD低压柜", obvious=True, readonly=True, group="构件分类")

        self["柜宽"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体宽度 X(mm)")
        self["柜深"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体深度 Y(mm)")
        self["柜高"] = Attr(2200.0, obvious=True, group="柜体尺寸", description="柜体总高 Z(mm)")
        self["回路数"] = Attr(4.0, obvious=True, group="柜体尺寸", description="回路分层数量")

        self["前面板外挑"] = Attr(12.0, obvious=True, group="细化参数", description="前部功能面板向外突出距离(mm)")

        self["柜名"] = Attr("GGD低压柜", obvious=True, group="标识", description="显示在正面的柜体名称")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["柜色"] = Attr("", obvious=True, material=True, group="自定义材质")

        self["标称重量"] = Attr(350.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["柜宽"]), 400.0)
        D = max(float(self["柜深"]), 300.0)
        H = max(float(self["柜高"]), 1200.0)
        circuit_count = max(int(round(float(self["回路数"]))), 2)
        front_out = max(min(float(self["前面板外挑"]), max(D * 0.18, 8.0)), 8.0)
        cabinet_name = str(self["柜名"])
        cabinet_material = self["柜色"]

        self["柜宽"] = W
        self["柜深"] = D
        self["柜高"] = H
        self["回路数"] = float(circuit_count)
        self["前面板外挑"] = front_out

        base_h = max(H * 0.042, 74.0)
        cap_h = max(H * 0.020, 34.0)
        top_zone_bottom = H * 0.90
        lower_zone_top = H * 0.24
        frame_w = max(W * 0.030, 22.0)
        panel_depth = front_out + 7.0
        trim_depth = max(front_out * 0.55, 8.0)
        plinth_out = max(front_out * 1.20, 16.0)

        c_body = (0.49, 0.55, 0.63, 1.0)
        c_light = (0.66, 0.71, 0.78, 1.0)
        c_dark = (0.26, 0.31, 0.38, 1.0)
        c_accent = (0.77, 0.81, 0.87, 1.0)
        c_handle = (0.79, 0.62, 0.31, 1.0)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = cabinet_material if use_cabinet_material else ""
            parts.append(self._finish(self._box(x, y, z, sx, sy, sz), color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_cabinet_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_cabinet_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_cabinet_material)

        append_box(0, 0, 0, W, D, H, c_body, use_cabinet_material=True)
        append_box(-W * 0.020, -plinth_out, 0, W * 1.040, max(D * 0.10, 62.0) + plinth_out, base_h, c_dark, use_cabinet_material=True)
        append_box(-W * 0.012, -front_out * 0.80, H - cap_h, W * 1.024, max(D * 0.08, 42.0) + front_out * 0.80, cap_h, c_light, use_cabinet_material=True)
        append_frame(frame_w * 0.55, -trim_depth, base_h, W - frame_w * 1.10, trim_depth + 2.0, H - base_h - cap_h * 0.35, frame_w * 0.55, c_dark)
        append_box(0, -4.0, top_zone_bottom, W, 4.0, 5.0, c_dark)
        append_box(0, -4.0, lower_zone_top, W, 4.0, 5.0, c_dark)

        header_w = W * 0.76
        header_h = max(H * 0.095, 160.0)
        header_x = (W - header_w) * 0.5
        header_z = top_zone_bottom + (H - top_zone_bottom - header_h) * 0.42
        append_box(header_x, -panel_depth, header_z, header_w, panel_depth + 5.0, header_h, c_light, use_cabinet_material=True)
        append_box(header_x + header_w * 0.14, -panel_depth - 5.0, header_z + header_h * 0.28, header_w * 0.40, 5.0, max(header_h * 0.10, 18.0), c_dark)
        append_box(header_x + header_w * 0.72, -panel_depth - 7.0, header_z + header_h * 0.22, max(W * 0.030, 20.0), 7.0, header_h * 0.42, c_handle)

        switch_zone_h = top_zone_bottom - lower_zone_top
        row_h = switch_zone_h / circuit_count
        append_box(W * 0.50 - 2.0, -4.0, lower_zone_top, 4.0, 4.0, switch_zone_h, c_dark)

        for row in range(circuit_count):
            row_z = lower_zone_top + row * row_h
            pad = max(row_h * 0.10, 8.0)
            face_h = max(row_h - pad * 2.0, 40.0)
            face_z = row_z + pad

            if row == 0:
                main_w = W * 0.78
                main_x = (W - main_w) * 0.5
                append_box(main_x, -panel_depth - 1.0, face_z, main_w, panel_depth + 8.0, face_h, c_body, use_cabinet_material=True)
                append_frame(
                    main_x + main_w * 0.08,
                    -panel_depth - 4.0,
                    face_z + face_h * 0.16,
                    main_w * 0.84,
                    panel_depth + 11.0,
                    face_h * 0.68,
                    max(main_w * 0.028, 12.0),
                    c_accent,
                )
                append_box(main_x + main_w * 0.18, -panel_depth - 6.0, face_z + face_h * 0.22, main_w * 0.20, panel_depth + 12.0, face_h * 0.46, c_handle)
                append_box(main_x + main_w * 0.44, -panel_depth - 7.0, face_z + face_h * 0.32, main_w * 0.18, panel_depth + 13.0, face_h * 0.20, c_handle)
                append_box(main_x + main_w * 0.15, -panel_depth - 5.0, face_z + face_h * 0.72, main_w * 0.26, 5.0, max(face_h * 0.08, 14.0), c_dark)
                append_box(main_x + main_w * 0.78, -panel_depth - 5.0, face_z + face_h * 0.62, max(W * 0.022, 12.0), 5.0, max(face_h * 0.14, 12.0), c_handle)
                append_box(main_x + main_w * 0.86, -panel_depth - 5.0, face_z + face_h * 0.62, max(W * 0.022, 12.0), 5.0, max(face_h * 0.14, 12.0), c_handle)
            else:
                left_w = W * 0.34
                left_x = W * 0.10
                append_box(left_x, -panel_depth - 1.0, face_z, left_w, panel_depth + 8.0, face_h, c_body, use_cabinet_material=True)
                append_frame(
                    left_x + left_w * 0.10,
                    -panel_depth - 4.0,
                    face_z + face_h * 0.16,
                    left_w * 0.80,
                    panel_depth + 11.0,
                    face_h * 0.68,
                    max(left_w * 0.040, 10.0),
                    c_accent,
                )
                append_box(left_x + left_w * 0.38, -panel_depth - 7.0, face_z + face_h * 0.22, left_w * 0.20, panel_depth + 13.0, face_h * 0.44, c_handle)
                append_box(left_x + left_w * 0.74, -panel_depth - 6.0, face_z + face_h * 0.24, max(left_w * 0.08, 12.0), 6.0, face_h * 0.36, c_dark)

                right_w = W * 0.34
                right_x = W * 0.56
                append_box(right_x, -panel_depth - 1.0, face_z, right_w, panel_depth + 8.0, face_h, c_light, use_cabinet_material=True)
                append_frame(
                    right_x + right_w * 0.08,
                    -panel_depth - 4.0,
                    face_z + face_h * 0.14,
                    right_w * 0.84,
                    panel_depth + 11.0,
                    face_h * 0.72,
                    max(right_w * 0.032, 10.0),
                    c_accent,
                )
                append_box(right_x + right_w * 0.18, -panel_depth - 5.0, face_z + face_h * 0.18, right_w * 0.46, 5.0, max(face_h * 0.10, 14.0), c_dark)
                vent_h = max(face_h * 0.10, 10.0)
                for i in range(3):
                    append_box(right_x + right_w * 0.18, -panel_depth - 6.0, face_z + face_h * 0.44 + i * vent_h * 1.45, right_w * 0.56, 6.0, vent_h, c_dark)

            if row < circuit_count - 1:
                append_box(W * 0.07, -4.0, row_z + row_h, W * 0.86, 4.0, 3.0, c_dark)

        lower_w = W * 0.82
        lower_h = max(lower_zone_top - H * 0.04, 130.0)
        lower_x = (W - lower_w) * 0.5
        lower_z = H * 0.04
        append_box(lower_x, -panel_depth, lower_z, lower_w, panel_depth + 7.0, lower_h, c_light, use_cabinet_material=True)
        append_frame(
            lower_x + lower_w * 0.07,
            -panel_depth - 3.0,
            lower_z + lower_h * 0.10,
            lower_w * 0.86,
            panel_depth + 10.0,
            lower_h * 0.80,
            max(lower_w * 0.026, 12.0),
            c_accent,
        )
        for i in range(4):
            append_box(lower_x + lower_w * 0.18, -panel_depth - 6.0, lower_z + lower_h * 0.20 + i * lower_h * 0.12, lower_w * 0.46, 6.0, max(lower_h * 0.06, 12.0), c_dark)
        append_box(lower_x + lower_w * 0.74, -panel_depth - 7.0, lower_z + lower_h * 0.22, max(W * 0.030, 22.0), panel_depth + 13.0, lower_h * 0.44, c_handle)
        append_box(lower_x + lower_w * 0.18, -panel_depth - 5.0, lower_z + lower_h * 0.70, lower_w * 0.30, 5.0, max(lower_h * 0.08, 16.0), c_dark)

        char_w = W * 0.11
        char_h = H * 0.066
        ascii_n = sum(1 for c in cabinet_name if ord(c) < 128)
        cjk_n = len(cabinet_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.0, 1.0)
        text_len = unit_count * char_w
        max_text_len = W * 0.78
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len
        name_band_h = max(H * 0.050, 20.0)
        name_band_z = H - cap_h - name_band_h * 1.25
        append_box(W * 0.12, -panel_depth - 10.0, name_band_z, W * 0.76, 6.0, name_band_h, c_light)
        text_z = name_band_z + name_band_h * 0.16
        text_sec = (
            translate((W - text_len) * 0.5, -panel_depth - 14.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(cabinet_name, char_w, char_h)
        )
        parts.append(Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -10, 0))).color(*c_text))

        self["GGD低压柜"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = GGD低压柜()
    place(FinalGeometry)
