# -*- coding: utf-8 -*-
from pyp3d import *


# ═══════════════════════════════════════════════════════════════
# 预制舱屋面龙骨（C型钢截面 + 三角桁架 + 檩条）
#
#   俯视: 12100×3500mm, X分格 1050+1100×8+1050, Y等分4行
#   截面: 150×100mm C型冷弯钢
#   结构: 每榀三角桁架 YZ平面, 沿X阵列, 纵向檩条连接
# ═══════════════════════════════════════════════════════════════

def _C型钢截面():
    """150×100mm C型冷弯钢实心截面，以路径为中心（路径穿过截面形心）。

    左→右 150mm (X), 下→上 100mm (Y)，形心在 (0,0)。
    """
    hw = 75.0   # 半宽
    hh = 50.0   # 半高
    return Section(
        Vec2(-hw, -hh),
        Vec2( hw, -hh),
        Vec2( hw,  hh),
        Vec2(-hw,  hh),
    )


def _扫掠杆(截面, 起点, 终点, 材质):
    """沿任意方向扫掠截面生成杆件。

    截面在 XOY 平面(法线∥Z)，扫掠结果沿 Z。
    rotation(Vec3(0,1,0), pi/2) 将 Z 转到 X，
    rotation_to 将 X 转到目标方向。
    """
    方向 = 终点 - 起点
    长度 = norm(方向)
    if 长度 < 1:
        return None

    path = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    solid = Sweep(截面, path)

    # Z → X (绕 Y 轴转 π/2)
    solid = rotation(Vec3(0, 1, 0), pi / 2) * solid
    # X → 方向
    solid = rotation_to(方向) * solid
    # 平移到起点
    solid = translation(起点) * solid

    if 材质:
        solid = solid.material(材质)
    return solid


# ═══════════════════════════════════════════════════════════════
# 参数化构件
# ═══════════════════════════════════════════════════════════════

class 预制舱屋面龙骨(Component):
    """预制舱屋面龙骨：C型钢三角桁架 + 网格檩条，鼠标一点放置。"""

    def __init__(self):
        Component.__init__(self)
        self["预制舱屋面龙骨"] = Attr(None, show=True)

        # 构件分类（只读）
        self["场布分类"] = Attr("建/构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("屋架/屋面", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("预制舱屋面龙骨", obvious=True, readonly=True, group="构件分类")

        # 全局参数
        self["整体长度"] = Attr(12100.0, obvious=True, group="全局参数", description="屋面总长 X(mm)")
        self["整体宽度"] = Attr(3500.0, obvious=True, group="全局参数", description="屋面总宽 Y(mm)")
        self["起坡高度"] = Attr(500.0, obvious=True, group="全局参数", description="屋脊高出檐口(mm)")
        self["端部分格"] = Attr(1050.0, obvious=True, group="全局参数", description="两端分区宽度(mm)")
        self["标准分格"] = Attr(1100.0, obvious=True, group="全局参数", description="中间标准跨宽度(mm)")
        self["横檩行数"] = Attr(4.0, obvious=True, group="全局参数", description="宽度方向等分行数")
        self["底部斜撑"] = Attr(False, obvious=True, group="全局参数", description="是否在底部平面加交叉斜撑")
        self["消除穿模"] = Attr(True, obvious=True, group="全局参数", description="布尔并集融合节点(慢但干净)")
        self["端部外伸"] = Attr(75.0, obvious=True, group="全局参数", description="横檩两端外伸量,填平缺口(mm)")

        # 型钢截面（可切换 C型钢 / 圆管）
        self["截面类型"] = Attr("C型钢", obvious=True, combo=["C型钢", "圆管"],
                            group="杆件截面", description="杆件截面类型")
        self["主杆管径"] = Attr(89.0, obvious=True, group="杆件截面", description="主杆外径(圆管模式)")
        self["次杆管径"] = Attr(60.0, obvious=True, group="杆件截面", description="檩条外径(圆管模式)")
        self["腹杆管径"] = Attr(48.0, obvious=True, group="杆件截面", description="斜撑外径(圆管模式)")

        # 定位
        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        # 自定义材质
        self["主杆颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["檩条颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["腹杆颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        L = self["整体长度"]
        W = self["整体宽度"]
        H_ridge = self["起坡高度"]
        L_end = self["端部分格"]
        L_std = self["标准分格"]
        N_y = int(self["横檩行数"])
        截面类型 = self["截面类型"]
        加斜撑 = self["底部斜撑"]
        融合节点 = self["消除穿模"]
        外伸 = self["端部外伸"]

        # ── 参数校验 ──
        if L < 500:
            L = 500; self["整体长度"] = L
        if W < 500:
            W = 500; self["整体宽度"] = W
        if H_ridge < 50:
            H_ridge = 50; self["起坡高度"] = H_ridge
        if L_end < 100:
            L_end = 100; self["端部分格"] = L_end
        if L_std < 200:
            L_std = 200; self["标准分格"] = L_std
        if N_y < 2:
            N_y = 2; self["横檩行数"] = float(N_y)
        if 2 * L_end >= L:
            L_end = L * 0.1; self["端部分格"] = L_end

        # ── 截面选择 ──
        主截面 = _C型钢截面()
        次截面 = _C型钢截面()
        腹截面 = _C型钢截面()

        # ── 节点计算 ──
        最小右端 = L_end * 0.5
        X_nodes = [0.0, L_end]
        while X_nodes[-1] + L_std + 最小右端 < L:
            X_nodes.append(X_nodes[-1] + L_std)
        X_nodes.append(L)

        # Y 节点（横龙骨 / 檩条位置）
        Y_nodes = [i * W / N_y for i in range(N_y + 1)]

        杆件列表 = []

        # ── 杆件生成 ──
        def 杆(起点, 终点, 管径, 材质):
            if 管径 <= 0:
                return
            d = norm(终点 - 起点)
            if d < 1:
                return
            p = Cone(起点, 终点, 管径 * 0.5, 管径 * 0.5)
            if 材质:
                p = p.material(材质)
            杆件列表.append(p)

        def 型钢杆(起点, 终点, sec, 材质):
            solid = _扫掠杆(sec, 起点, 终点, 材质)
            if solid is not None:
                杆件列表.append(solid)

        if 截面类型 == "C型钢":
            def 主杆(s, e):
                型钢杆(s, e, 主截面, self["主杆颜色"])
            def 次杆(s, e):
                型钢杆(s, e, 次截面, self["檩条颜色"])
            def 腹杆(s, e):
                型钢杆(s, e, 腹截面, self["腹杆颜色"])
        else:
            def 主杆(s, e):
                杆(s, e, self["主杆管径"], self["主杆颜色"])
            def 次杆(s, e):
                杆(s, e, self["次杆管径"], self["檩条颜色"])
            def 腹杆(s, e):
                杆(s, e, self["腹杆管径"], self["腹杆颜色"])

        # ══════════════════════════════════════════════════════
        # 1. 三角桁架框架
        # ══════════════════════════════════════════════════════
        屋脊Y = W * 0.5
        for xi in X_nodes:
            主杆(Vec3(xi, 0, 0), Vec3(xi, W, 0))              # 底弦
            主杆(Vec3(xi, 0, 0), Vec3(xi, 屋脊Y, H_ridge))    # 左坡杆
            主杆(Vec3(xi, 屋脊Y, H_ridge), Vec3(xi, W, 0))    # 右坡杆

        # ══════════════════════════════════════════════════════
        # 2. 纵向檩条
        # ══════════════════════════════════════════════════════
        for yj in Y_nodes:
            zj = H_ridge * (1.0 - abs(yj - 屋脊Y) / 屋脊Y)
            次杆(Vec3(0 - 外伸, yj, zj),
                 Vec3(L + 外伸, yj, zj))

        # ══════════════════════════════════════════════════════
        # 3. 底部斜撑
        # ══════════════════════════════════════════════════════
        if 加斜撑:
            for k in range(len(X_nodes) - 1):
                x0 = X_nodes[k]
                x1 = X_nodes[k + 1]
                if k % 2 == 0:
                    腹杆(Vec3(x0, 0, 0), Vec3(x1, W, 0))
                else:
                    腹杆(Vec3(x0, W, 0), Vec3(x1, 0, 0))

        # ── 输出 ──
        if 融合节点 and 杆件列表:
            result = 杆件列表[0]
            for g in 杆件列表[1:]:
                result = result + g
        else:
            result = combine(*杆件列表) if 杆件列表 else Graphics()
        self["预制舱屋面龙骨"] = translate(self["X"], self["Y"], self["Z"]) * result

        # —— 自重：桁架杆件 + 檩条 ——
        _L = float(self["整体长度"]); _W = float(self["整体宽度"])
        _h = float(self["起坡高度"]); _bay = float(self["标准分格"])
        _rows = float(self["横檩行数"])
        _n = max(int(_L / _bay) if _bay > 0 else 1, 1)
        _diag = ((_W / 2.0) ** 2 + _h ** 2) ** 0.5
        _per = (2.0 * _diag + _W) * 1.15
        if "圆管" in str(self["截面类型"]):
            _d1 = float(self["主杆管径"]); _d2 = float(self["次杆管径"])
            _k1 = 3.14159 / 4.0 * (_d1 ** 2 - (_d1 - 6.0) ** 2) * 7850.0 / 1e6
            _k2 = 3.14159 / 4.0 * (_d2 ** 2 - (_d2 - 6.0) ** 2) * 7850.0 / 1e6
        else:
            _k1 = 5.0; _k2 = 4.0
        self["自重_kg"] = round(_n * _per / 1000.0 * _k1 + _rows * _L / 1000.0 * _k2, 2)


if __name__ == "__main__":
    FinalGeometry = 预制舱屋面龙骨()
    place(FinalGeometry)
