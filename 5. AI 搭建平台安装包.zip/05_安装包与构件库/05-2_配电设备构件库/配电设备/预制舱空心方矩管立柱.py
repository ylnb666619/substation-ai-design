# -*- coding: utf-8 -*-
"""
================================================================================
 BIMBase PyP3d 参数化 预制舱空心方矩管立柱

 构件说明：
   · 空心方矩管立柱，外尺寸 100×100，壁厚 4，高度 2850
   · 四块壁板 Box 拼接（左/右/前/后），不用布尔运算
   · 底面 Z=0，单一构件
   · 钢材型号下拉可选：Q235B、Q355B（仅切换材质颜色，几何不变）

 坐标系：底面中心在 Z=0
          X = 宽度方向，Y = 深度方向，Z = 高度方向
================================================================================
"""

from pyp3d import *


# ============================================================================
# 【1】默认几何参数
# ============================================================================

COLUMN_WIDTH    = 100.0      # 外截面宽度 (mm) — X 方向
COLUMN_DEPTH    = 100.0      # 外截面深度 (mm) — Y 方向
WALL_THICKNESS  = 4.0        # 壁厚 (mm)
COLUMN_HEIGHT   = 2850.0     # 柱高度 (mm)     — Z 方向


# ============================================================================
# 【2】BIMBase 参数化组件类
# ============================================================================

class 预制舱空心方矩管立柱(Component):
    """预制舱空心方矩管立柱 — 单一参数化构件

    外尺寸 100×100，壁厚 4，高度 2850，底面 Z=0。
    四块壁板 Box 拼接。钢材型号：Q235B / Q355B。
    """

    def __init__(self):
        Component.__init__(self)

        # 输出几何体
        self['预制舱空心方矩管立柱'] = Attr(None, show=True)

        # 构件分类信息
        self['场布分类'] = Attr('建/构筑物', obvious=True, readonly=True, group='构件分类')
        self['构件类型'] = Attr('柱', obvious=True, readonly=True, group='构件分类')
        self['构件名称'] = Attr('预制舱空心方矩管立柱', obvious=True, readonly=True, group='构件分类')

        # 主尺寸参数
        self['外截面宽'] = Attr(COLUMN_WIDTH, obvious=True, group='主尺寸',
                                description='外截面宽度 X (mm)')
        self['外截面深'] = Attr(COLUMN_DEPTH, obvious=True, group='主尺寸',
                                description='外截面深度 Y (mm)')
        self['壁厚'] = Attr(WALL_THICKNESS, obvious=True, group='主尺寸',
                            description='管壁厚度 (mm)')
        self['高度'] = Attr(COLUMN_HEIGHT, obvious=True, group='主尺寸',
                            description='立柱高度 Z (mm)')

        # 钢材型号下拉选择
        self['钢材型号'] = Attr('Q235B', obvious=True, combo=['Q235B', 'Q355B'],
                               group='材料', description='切换钢材型号仅改变材质颜色')

        # 定位参数
        self['X'] = Attr(0.0, obvious=True, group='定位')
        self['Y'] = Attr(0.0, obvious=True, group='定位')

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        """参数变更时重建几何体"""
        W = float(self['外截面宽'])      # 外宽
        D = float(self['外截面深'])      # 外深
        t = float(self['壁厚'])          # 壁厚
        H = float(self['高度'])          # 柱高
        steel = str(self['钢材型号'])

        # 参数校验
        if W < 30:
            W = 30; self['外截面宽'] = W
        if D < 30:
            D = 30; self['外截面深'] = D
        if t < 1.0:
            t = 1.0; self['壁厚'] = t
        if t > W / 2.0 - 1:
            t = W / 2.0 - 1; self['壁厚'] = t
        if t > D / 2.0 - 1:
            t = D / 2.0 - 1; self['壁厚'] = t
        if H < 100:
            H = 100; self['高度'] = H

        # 钢材型号 → 颜色
        if steel == 'Q235B':
            col = (0.55, 0.58, 0.62, 1.0)    # 普通钢蓝灰
        else:
            col = (0.45, 0.48, 0.55, 1.0)    # 高强钢深灰蓝

        # 内空尺寸
        inner_W = W - 2.0 * t
        inner_D = D - 2.0 * t

        half_W = W / 2.0
        half_D = D / 2.0
        half_H = H / 2.0

        # 四块壁板 Box 拼接（底面 Z=0，中心在 XOY 平面）
        # 前壁：y = +half_D - t/2，X = W，Z = H
        front = Box(
            Vec3(-half_W, half_D - t, 0.0),
            Vec3(-half_W, half_D - t, H),
            Vec3(1, 0, 0), Vec3(0, 1, 0),
            W, t, W, t
        ).color(*col)

        # 后壁：y = -half_D，X = W，Z = H
        back = Box(
            Vec3(-half_W, -half_D, 0.0),
            Vec3(-half_W, -half_D, H),
            Vec3(1, 0, 0), Vec3(0, 1, 0),
            W, t, W, t
        ).color(*col)

        # 左壁：x = -half_W，Y = inner_D，Z = H
        left = Box(
            Vec3(-half_W, -half_D + t, 0.0),
            Vec3(-half_W, -half_D + t, H),
            Vec3(1, 0, 0), Vec3(0, 1, 0),
            t, inner_D, t, inner_D
        ).color(*col)

        # 右壁：x = +half_W - t，Y = inner_D，Z = H
        right = Box(
            Vec3(half_W - t, -half_D + t, 0.0),
            Vec3(half_W - t, -half_D + t, H),
            Vec3(1, 0, 0), Vec3(0, 1, 0),
            t, inner_D, t, inner_D
        ).color(*col)

        # 组合四块壁板（无布尔运算，无拼缝线）
        column = combine(front, back, left, right)

        # 定位
        dx = float(self['X'])
        dy = float(self['Y'])
        self['预制舱空心方矩管立柱'] = translate(dx, dy, 0.0) * column

        # —— 自重：净截面 × 高 × 钢 ——
        _w = float(self["外截面宽"]); _d = float(self["外截面深"])
        _t = float(self["壁厚"]); _h = float(self["高度"])
        _area = _w * _d - max(_w - 2.0 * _t, 0.0) * max(_d - 2.0 * _t, 0.0)
        self["自重_kg"] = round(_area * _h * 7850.0 / 1e9, 2)


# ============================================================================
# 【3】插件执行入口
# ============================================================================

if __name__ == "__main__":
    FinalGeometry = 预制舱空心方矩管立柱()
    place(FinalGeometry)
