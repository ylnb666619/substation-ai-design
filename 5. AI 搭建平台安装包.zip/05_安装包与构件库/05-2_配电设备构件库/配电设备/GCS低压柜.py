# -*- coding: utf-8 -*-
from pyp3d import *


class GCS低压柜(Component):
    """GCS 抽屉式低压柜。"""

    def __init__(self):
        Component.__init__(self)
        self["GCS低压柜"] = Attr(None, show=True)

        self["空间分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("GCS低压柜", obvious=True, readonly=True, group="构件分类")

        self["柜宽"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体宽度 X(mm)")
        self["柜深"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体深度 Y(mm)")
        self["柜高"] = Attr(2200.0, obvious=True, group="柜体尺寸", description="柜体总高 Z(mm)")
        self["抽屉数"] = Attr(8.0, obvious=True, group="柜体尺寸", description="抽屉单元数量")

        self["前面板外挑"] = Attr(14.0, obvious=True, group="细化参数", description="前部面板向外突出距离(mm)")

        self["柜名"] = Attr("GCS低压柜", obvious=True, group="标识", description="显示在正面的柜体名称")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["柜色"] = Attr("", obvious=True, material=True, group="自定义材质")

        self["标称重量"] = Attr(400.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["柜宽"]), 400.0)
        D = max(float(self["柜深"]), 300.0)
        H = max(float(self["柜高"]), 1200.0)
        drawer_count = max(int(round(float(self["抽屉数"]))), 2)
        front_out = max(min(float(self["前面板外挑"]), max(D * 0.20, 8.0)), 8.0)
        cabinet_name = str(self["柜名"])
        cabinet_material = self["柜色"]

        self["柜宽"] = W
        self["柜深"] = D
        self["柜高"] = H
        self["抽屉数"] = float(drawer_count)
        self["前面板外挑"] = front_out

        base_h = max(H * 0.045, 78.0)
        cap_h = max(H * 0.020, 34.0)
        top_zone_bottom = H * 0.88
        lower_zone_top = H * 0.22
        frame_w = max(W * 0.032, 24.0)
        panel_depth = front_out + 8.0
        trim_depth = max(front_out * 0.60, 8.0)
        plinth_out = max(front_out * 1.35, 18.0)

        c_body = (0.50, 0.55, 0.63, 1.0)
        c_light = (0.65, 0.70, 0.77, 1.0)
        c_dark = (0.27, 0.31, 0.38, 1.0)
        c_accent = (0.77, 0.81, 0.87, 1.0)
        c_handle = (0.79, 0.62, 0.31, 1.0)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = cabinet_material if use_cabinet_material else ""
            parts.append(self._finish(self._box(x, y, z, sx, sy, sz), color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_cabinet_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_cabinet_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_cabinet_material)

        append_box(0, 0, 0, W, D, H, c_body, use_cabinet_material=True)
        append_box(-W * 0.020, -plinth_out, 0, W * 1.040, max(D * 0.10, 64.0) + plinth_out, base_h, c_dark, use_cabinet_material=True)
        append_box(W * 0.08, -plinth_out - 4.0, base_h * 0.18, W * 0.84, 6.0, max(base_h * 0.24, 16.0), c_dark)
        append_box(-W * 0.012, -front_out * 0.85, H - cap_h, W * 1.024, max(D * 0.08, 44.0) + front_out * 0.85, cap_h, c_light, use_cabinet_material=True)

        append_frame(frame_w * 0.55, -trim_depth, base_h, W - frame_w * 1.10, trim_depth + 2.0, H - base_h - cap_h * 0.35, frame_w * 0.55, c_dark)
        guard_w = max(W * 0.018, 12.0)
        append_box(-guard_w * 0.12, -front_out * 0.50, base_h, guard_w, front_out * 0.50 + 4.0, H - base_h - cap_h * 0.25, c_dark)
        append_box(W - guard_w * 0.88, -front_out * 0.50, base_h, guard_w, front_out * 0.50 + 4.0, H - base_h - cap_h * 0.25, c_dark)

        append_box(0, -4.0, top_zone_bottom, W, 4.0, 5.0, c_dark)
        append_box(0, -4.0, lower_zone_top, W, 4.0, 5.0, c_dark)

        bus_w = W * 0.76
        bus_h = max(H * 0.100, 170.0)
        bus_x = (W - bus_w) * 0.5
        bus_z = top_zone_bottom + (H - top_zone_bottom - bus_h) * 0.46
        append_box(bus_x, -panel_depth, bus_z, bus_w, panel_depth + 6.0, bus_h, c_light, use_cabinet_material=True)
        append_frame(bus_x + bus_w * 0.08, -panel_depth - 4.0, bus_z + bus_h * 0.20, bus_w * 0.84, panel_depth + 10.0, bus_h * 0.58, max(bus_w * 0.030, 16.0), c_accent)
        append_box(bus_x + bus_w * 0.18, -panel_depth - 5.0, bus_z + bus_h * 0.30, bus_w * 0.44, 5.0, max(bus_h * 0.10, 20.0), c_dark)
        for ratio in (0.72, 0.82, 0.92):
            append_box(bus_x + bus_w * ratio, -panel_depth - 6.0, bus_z + bus_h * 0.34, max(W * 0.018, 10.0), 6.0, max(bus_h * 0.18, 18.0), c_handle)

        drawer_zone_h = top_zone_bottom - lower_zone_top
        ratios = []
        for i in range(drawer_count):
            if i == 0 or i == drawer_count - 1:
                ratios.append(1.30)
            elif i % 3 == 1:
                ratios.append(0.82)
            else:
                ratios.append(0.60)
        unit_h = drawer_zone_h / max(sum(ratios), 1.0)

        drawer_w = W * 0.80
        drawer_x = (W - drawer_w) * 0.5
        current_z = lower_zone_top
        for index, ratio in enumerate(ratios):
            drawer_h = unit_h * ratio
            pad_z = max(drawer_h * 0.08, 6.0)
            face_h = max(drawer_h - pad_z * 2.0, 24.0)
            face_z = current_z + pad_z
            append_box(drawer_x, -panel_depth - 1.0, face_z, drawer_w, panel_depth + 8.0, face_h, c_body, use_cabinet_material=True)

            margin_x = max(drawer_w * 0.07, 18.0)
            margin_z = min(max(face_h * 0.18, 10.0), face_h * 0.30)
            border = min(max(drawer_w * 0.024, 10.0), margin_x * 0.65, margin_z * 0.65)
            append_frame(
                drawer_x + margin_x,
                -panel_depth - 4.0,
                face_z + margin_z,
                drawer_w - margin_x * 2.0,
                panel_depth + 11.0,
                face_h - margin_z * 2.0,
                border,
                c_accent,
            )

            append_box(drawer_x + drawer_w * 0.20, -panel_depth - 7.0, face_z + face_h * 0.28, drawer_w * 0.48, panel_depth + 13.0, max(face_h * 0.10, 14.0), c_handle)
            append_box(drawer_x + drawer_w * 0.18, -panel_depth - 5.0, face_z + face_h * 0.68, drawer_w * 0.28, 5.0, max(face_h * 0.08, 12.0), c_dark)
            append_box(drawer_x + drawer_w * 0.80, -panel_depth - 6.0, face_z + face_h * 0.68, max(drawer_w * 0.032, 14.0), 6.0, max(face_h * 0.16, 14.0), c_handle)

            if index < drawer_count - 1:
                append_box(W * 0.07, -4.0, current_z + drawer_h, W * 0.86, 4.0, 3.0, c_dark)
            current_z += drawer_h

        lower_w = W * 0.82
        lower_h = max(lower_zone_top - H * 0.04, 120.0)
        lower_x = (W - lower_w) * 0.5
        lower_z = H * 0.04
        append_box(lower_x, -panel_depth, lower_z, lower_w, panel_depth + 7.0, lower_h, c_light, use_cabinet_material=True)
        append_frame(
            lower_x + lower_w * 0.07,
            -panel_depth - 3.0,
            lower_z + lower_h * 0.10,
            lower_w * 0.86,
            panel_depth + 10.0,
            lower_h * 0.80,
            max(lower_w * 0.026, 12.0),
            c_accent,
        )
        louver_w = lower_w * 0.44
        louver_h = max(lower_h * 0.060, 12.0)
        louver_x = lower_x + lower_w * 0.18
        for i in range(4):
            louver_z = lower_z + lower_h * 0.20 + i * louver_h * 1.75
            append_box(louver_x, -panel_depth - 7.0, louver_z, louver_w, 6.0, louver_h, c_dark)
        append_box(lower_x + lower_w * 0.77, -panel_depth - 7.0, lower_z + lower_h * 0.22, max(W * 0.032, 22.0), panel_depth + 13.0, lower_h * 0.42, c_handle)
        append_box(lower_x + lower_w * 0.22, -panel_depth - 5.0, lower_z + lower_h * 0.70, lower_w * 0.42, 5.0, max(lower_h * 0.08, 16.0), c_dark)

        char_w = W * 0.11
        char_h = H * 0.066
        ascii_n = sum(1 for c in cabinet_name if ord(c) < 128)
        cjk_n = len(cabinet_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.0, 1.0)
        text_len = unit_count * char_w
        max_text_len = W * 0.78
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len
        name_band_h = max(H * 0.050, 20.0)
        name_band_z = H - cap_h - name_band_h * 1.25
        append_box(W * 0.12, -panel_depth - 10.0, name_band_z, W * 0.76, 6.0, name_band_h, c_light)
        text_z = name_band_z + name_band_h * 0.16
        text_sec = (
            translate((W - text_len) * 0.5, -panel_depth - 14.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(cabinet_name, char_w, char_h)
        )
        parts.append(Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -10, 0))).color(*c_text))

        self["GCS低压柜"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = GCS低压柜()
    place(FinalGeometry)
