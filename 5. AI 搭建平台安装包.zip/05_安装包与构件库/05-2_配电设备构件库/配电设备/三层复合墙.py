# -*- coding: utf-8 -*-
from pyp3d import *

# ═══════════════════════════════════════════════════════════════
# 辅助函数（保持不变）
# ═══════════════════════════════════════════════════════════════

def _波纹截面(spc, dep, thk, 顶宽比=0.35):
    """构建单个梯形波纹的 2D 闭合截面"""
    顶半宽 = spc * 顶宽比 * 0.5
    坡起 = spc * 0.5 - 顶半宽
    坡止 = spc * 0.5 + 顶半宽

    return Section(
        Vec2(0, 0),
        Vec2(坡起, dep),
        Vec2(坡止, dep),
        Vec2(spc, 0),
        Vec2(spc, -thk),
        Vec2(0, -thk),
    )

def _平板(L, T, H):
    """构建平板几何体，厚度 T 作为 Y 轴负方向偏移"""
    return trans(0, -T, 0) * scale(L, T, H) * Cube()


# 常见材料关键词 → 密度(kg/m3)；按顺序匹配，先具体后一般（如"镀铝锌"须在"铝"之前）
材料密度表 = [
    ("岩棉", 100.0), ("玻璃棉", 80.0), ("保温棉", 100.0), ("保温", 100.0),
    ("挤塑", 30.0), ("聚苯", 20.0), ("聚氨酯", 40.0),
    ("镀铝锌", 7850.0), ("镀锌", 7850.0), ("彩钢", 7850.0), ("彩涂", 7850.0),
    ("不锈钢", 7930.0),
    ("铝", 2700.0),
    ("钢", 7850.0),
    ("玻璃", 2500.0),
    ("木", 500.0),
    ("水泥", 2400.0), ("混凝土", 2400.0),
]


def 材料密度查找(材质, 默认密度):
    """按材质名称关键词匹配密度(kg/m3)；未选材质或未识别时返回默认密度。"""
    try:
        名称 = str(材质 or "")
    except Exception:
        名称 = ""
    try:
        默认 = max(float(默认密度), 1.0)
    except Exception:
        默认 = 7850.0
    for 关键词, 密度 in 材料密度表:
        if 关键词 in 名称:
            return 密度
    return 默认

# ═══════════════════════════════════════════════════════════════
# 完全参数化的三层复合墙族
# ═══════════════════════════════════════════════════════════════

class 三层复合墙(Component):
    def __init__(self):
        Component.__init__(self)
        self["三层复合墙"] = Attr(None, show=True)

        # 1. 构件分类信息
        self["场布分类"] = Attr("建/构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("墙、板", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("预制舱外墙(波纹板+保温+内板)", obvious=True, readonly=True, group="构件分类")

        # 2. 全局尺寸（实际工程常用值 6m 长）
        self["墙长度"] = Attr(6000.0, obvious=True, group="全局尺寸", description="墙体长度(mm)")
        self["墙高度"] = Attr(2800.0, obvious=True, group="全局尺寸", description="墙体高度(mm)")

        # 组合总厚度（只读，由下面三层的厚度自动求和得出）
        self["总厚度"] = Attr(0.0, obvious=False, readonly=True, group="全局尺寸", description="三层总厚度(mm)")

        # 3. 外层：波纹金属板 (按 GB/T 12755 规范默认 0.6mm)
        self["外层厚度"] = Attr(0.6, obvious=True, group="外层波纹板", description="基板厚度(mm)")
        self["波纹间距"] = Attr(210.0, obvious=True, group="外层波纹板", description="单个波纹宽度(mm)")
        self["波纹深度"] = Attr(35.0, obvious=True, group="外层波纹板", description="波纹凸起高度(mm)")
        self["波峰宽比"] = Attr(0.35, obvious=True, group="外层波纹板", description="波峰平台宽/波距比例(0.1~0.8)")
        # 材质下拉选择（构件创建后可在UI直接选）
        self["外板材质"] = Attr("", obvious=True, material=True, group="外层波纹板", description="推荐镀铝锌AZ150或氟碳彩涂")

        # 4. 中层：保温层 (按 GB 8624 A级不燃标准，默认 100mm 岩棉)
        self["保温厚度"] = Attr(100.0, obvious=True, group="中层保温", description="岩棉/玻璃棉厚度(mm)")
        self["保温材质"] = Attr("", obvious=True, material=True, group="中层保温", description="推荐A级不燃岩棉")

        # 5. 内层：内护板 (按 GB 50210 洁净平整标准，默认 0.6mm)
        self["内层厚度"] = Attr(0.6, obvious=True, group="内墙板", description="内侧护板厚度(mm)")
        self["内板材质"] = Attr("", obvious=True, material=True, group="内墙板", description="推荐哑光白聚酯彩涂板")

        # 6. 力学信息：重量 = 体积 × 密度；选择材质后自动按材质匹配密度
        self["钢材密度kg/m3"] = Attr(7850.0, obvious=True, group="力学信息", description="默认钢材密度(kg/m3)，未选材质或材质未识别时使用")
        self["保温密度kg/m3"] = Attr(100.0, obvious=True, group="力学信息", description="默认保温层密度(kg/m3)，未选材质或材质未识别时使用")
        self["外层采用密度kg/m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="外层当前采用的密度(kg/m3)，随外板材质自动匹配")
        self["保温采用密度kg/m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="保温层当前采用的密度(kg/m3)，随保温材质自动匹配")
        self["内板采用密度kg/m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="内板当前采用的密度(kg/m3)，随内板材质自动匹配")
        self["外层板体积m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="外层波纹板体积(m3)")
        self["保温层体积m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="保温层体积(m3)")
        self["内板体积m3"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="内护板体积(m3)")
        self["外层板重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="外层波纹板重量(kg)=体积×采用密度")
        self["保温层重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="保温层重量(kg)=体积×采用密度")
        self["内板重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="内护板重量(kg)=体积×采用密度")
        self["理论总重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="三层重量合计(kg)，随材质与尺寸自动更新，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        # 从 UI 参数面板读取所有数值
        L = self["墙长度"]
        H = self["墙高度"]
        t_out = self["外层厚度"]
        spc = self["波纹间距"]
        dep = self["波纹深度"]
        ratio = self["波峰宽比"]
        t_ins = self["保温厚度"]
        t_in = self["内层厚度"]

        # 自动计算并回写"总厚度"
        self["总厚度"] = t_out + t_ins + t_in

        # 参数边界值校验（避免生成失败）
        if spc < 20: spc = 20; self["波纹间距"] = spc
        if dep < 5: dep = 5; self["波纹深度"] = dep

        # ─── 1. 生成外层波纹板 ───
        n = int(L / spc)
        rem = L - n * spc
        outer = combine()

        if n > 0:
            wave_unit = Sweep(_波纹截面(spc, dep, t_out, ratio), Line(Vec3(0, 0, 0), Vec3(0, 0, H)))
            if self["外板材质"]:
                wave_unit = wave_unit.material(self["外板材质"])
            for i in range(n):
                outer.append(trans(i * spc, 0, 0) * wave_unit)

        # 尾部剩余平板补齐
        if rem > 1:
            tail = _平板(rem, t_out, H)
            if self["外板材质"]:
                tail = tail.material(self["外板材质"])
            outer.append(trans(n * spc, 0, 0) * tail)

        # ─── 2. 生成中层保温板 ───
        # 保温层紧贴外层板背面（Y负方向偏移）
        insulation = trans(0, -t_out, 0) * _平板(L, t_ins, H)
        if self["保温材质"]:
            insulation = insulation.material(self["保温材质"])

        # ─── 3. 生成内墙板 ───
        # 内墙板紧贴保温层背面
        inner = trans(0, -t_out - t_ins, 0) * _平板(L, t_in, H)
        if self["内板材质"]:
            inner = inner.material(self["内板材质"])

        # ─── 4. 重量计算：体积 × 密度（换材质时按材质密度自动重算）───
        # 外层波纹板截面面积 = 梯形波(周宽spc、顶宽spc·ratio、高dep) + 基板(spc×t_out)
        波纹截面 = spc * dep * (1.0 + ratio) * 0.5 + spc * t_out      # mm2/周期
        尾板宽 = rem if rem > 1 else 0.0
        外层体积 = (n * 波纹截面 + 尾板宽 * t_out) * H * 1.0e-9        # m3
        保温体积 = L * t_ins * H * 1.0e-9
        内板体积 = L * t_in * H * 1.0e-9
        外层密度 = 材料密度查找(self["外板材质"], self["钢材密度kg/m3"])
        保温采用 = 材料密度查找(self["保温材质"], self["保温密度kg/m3"])
        内板密度 = 材料密度查找(self["内板材质"], self["钢材密度kg/m3"])
        外层重量 = 外层体积 * 外层密度
        保温重量 = 保温体积 * 保温采用
        内板重量 = 内板体积 * 内板密度

        self["外层采用密度kg/m3"] = round(外层密度, 3)
        self["保温采用密度kg/m3"] = round(保温采用, 3)
        self["内板采用密度kg/m3"] = round(内板密度, 3)
        self["外层板体积m3"] = round(外层体积, 6)
        self["保温层体积m3"] = round(保温体积, 6)
        self["内板体积m3"] = round(内板体积, 6)
        self["外层板重量kg"] = round(外层重量, 3)
        self["保温层重量kg"] = round(保温重量, 3)
        self["内板重量kg"] = round(内板重量, 3)
        self["理论总重量kg"] = round(外层重量 + 保温重量 + 内板重量, 3)

        # 组合输出到模型空间
        self["三层复合墙"] = combine(outer, insulation, inner)

if __name__ == "__main__":
    FinalGeometry = 三层复合墙()
    # 设为双向拉伸放置方式 (在场景中点击两点拉出长度)
    TwoPointPlace.linearize(FinalGeometry, '墙长度')
    place(FinalGeometry)
