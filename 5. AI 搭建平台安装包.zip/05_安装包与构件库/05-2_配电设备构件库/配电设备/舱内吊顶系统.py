# -*- coding: utf-8 -*-
"""
舱内吊顶系统 - 参数化构件
白色纵向次龙骨框包围黑色横向百叶格栅 + 白色主钢梁
"""
from pyp3d import *


class 舱内吊顶系统(Component):
    def __init__(self):
        Component.__init__(self)
        self['国标编码'] = '14-11.10.00'
        self['构件类别'] = '吊顶'
        self['纵向长']   = Attr(2400, obvious=True)   # Y方向
        self['横向宽']   = Attr(1200, obvious=True)   # X方向
        self['百叶条数'] = Attr(18,   obvious=True)   # 黑色格栅条数
        self['百叶宽']   = Attr(45,   obvious=True)   # 单条格栅宽
        self['叶厚']     = Attr(2,    obvious=True)   # 格栅叶片厚
        self['间隙']     = Attr(8,    obvious=True)   # 百叶间缝隙
        self['次龙骨高'] = Attr(30,   obvious=True)
        self['次龙骨宽'] = Attr(20,   obvious=True)
        self['主梁高']   = Attr(40,   obvious=True)
        self['主梁宽']   = Attr(30,   obvious=True)
        self['舱内吊顶系统'] = Attr(None, show=True)
        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")
        self.replace()

    @export
    def replace(self):
        LY = self['纵向长']
        WX = self['横向宽']
        NS = int(self['百叶条数'])
        SW = self['百叶宽']
        ST = self['叶厚']
        GAP = self['间隙']
        KH = self['次龙骨高']
        KW = self['次龙骨宽']

        BLACK  = (0.06, 0.06, 0.08, 1)
        WHITE  = (0.94, 0.94, 0.95, 1)

        def bar(x, y, z, sx, sy, sz):
            return translate(x, y, z) * scale(sx, sy, sz) * Cube()

        parts = []

        # ---- Z 分层 ----
        z0 = 0
        keel_z = z0                     # 次龙骨底面
        grille_z = keel_z + KH          # 格栅 = 次龙骨顶面
        beam_z = grille_z + 8 + KH      # 主梁 = 格栅上方

        # ============================================================
        # 1. 白色纵向次龙骨框 — 四边包围
        #    前/后两条沿X方向, 左/右两条沿Y方向
        # ============================================================
        # 前边 (Y=0)
        parts.append(bar(0, 0, keel_z, WX, KW, KH).color(*WHITE))
        # 后边 (Y=LY-KW)
        parts.append(bar(0, LY - KW, keel_z, WX, KW, KH).color(*WHITE))
        # 左边 (X=0)
        parts.append(bar(0, 0, keel_z, KW, LY, KH).color(*WHITE))
        # 右边 (X=WX-KW)
        parts.append(bar(WX - KW, 0, keel_z, KW, LY, KH).color(*WHITE))

        # ============================================================
        # 2. 中间白色纵向次龙骨 (等距分布)
        # ============================================================
        inner_count = 2  # 中间两根
        inner_zone = WX - 2*KW   # 去掉边框后的宽度
        for i in range(1, inner_count + 1):
            xc = KW + i * inner_zone / (inner_count + 1) - KW/2
            parts.append(bar(xc, 0, keel_z, KW, LY, KH).color(*WHITE))

        # ============================================================
        # 3. 黑色横向百叶格栅 — 嵌在白色龙骨框内
        # ============================================================
        inner_w = WX - 2*KW   # 格栅有效宽度(两边让出龙骨)
        inner_h = LY - 2*KW   # 格栅有效长度
        blade_h = 8
        pitch = (inner_h - GAP) / NS

        for i in range(NS):
            yc = KW + GAP/2 + i * pitch
            parts.append(bar(KW, yc, grille_z, inner_w, ST, blade_h).color(*BLACK))

        self['舱内吊顶系统'] = combine(*parts)

        # —— 自重：百叶 + 次龙骨 + 主梁 ——
        _L = float(self["纵向长"])
        _n = float(self["百叶条数"]); _bw = float(self["百叶宽"]); _bt = float(self["叶厚"])
        _sh = float(self["次龙骨高"]); _sw = float(self["次龙骨宽"])
        _mh = float(self["主梁高"]); _mw = float(self["主梁宽"])
        self["自重_kg"] = round((_n * _bw * _bt * _L + 2.0 * _sw * _sh * _L + 2.0 * _mw * _mh * _L) * 7850.0 / 1e9, 2)


if __name__ == '__main__':
    FinalGeometry = 舱内吊顶系统()
    place(FinalGeometry)
