# -*- coding: utf-8 -*-
"""
槽钢底座_图3（按 底座0904.p3d 图示固定网格，功能体系与 槽钢底座.py 一致）

图示特征：
1. 外框四道通长槽钢（外层槽钢型号），开口统一朝内。
2. 内部竖向槽钢按图示位置布置（槽钢型号），两端搭入外框。
3. 内部横向槽钢按图示位置布置（槽钢型号），两端搭入外框。
4. 两侧(左列与右部两列)按500分密格，中部为大格通高区。
坐标约定：
- 原点在左下角
- X 向右
- Y 向上
- Z 为槽钢厚度方向

固定外形：总长 4000 × 总宽 3000 mm（网格尺寸按图示固定，避免比例失真）。
"""

import json

from pyp3d import *


# ── 图示固定网格（mm，原点在左下角）──
底座总长X = 4000.0
底座总宽Y = 3000.0

# 通高竖向槽钢 X 位置（上下贯通）
竖向贯通X = [900, 1800, 2700, 3125]

# 局部竖向槽钢（x, y起点, y终点）
竖向局部 = []

# 通长横向槽钢 Y 位置（左右贯通）
横向贯通Y = [1000, 2000]

# 局部横向槽钢（y, x起点, x终点）
横向局部 = [(500, 0, 900), (500, 2700, 4000), (1500, 0, 900), (1500, 2700, 4000), (2500, 0, 900), (2500, 2700, 4000)]


槽钢规格表 = {
    "5#": (50, 37, 4.5, 7.0),
    "6.3#": (63, 40, 4.8, 7.5),
    "8#": (80, 43, 5.0, 8.0),
    "10#": (100, 48, 5.3, 8.5),
    "12#": (120, 53, 5.5, 9.0),
    "14#": (140, 60, 6.0, 9.5),
    "16#": (160, 65, 8.5, 10.0),
    "18#": (180, 70, 9.0, 10.5),
    "20#": (200, 75, 9.0, 11.0),
    "22#": (220, 80, 9.5, 11.5),
    "25#": (250, 82, 11.0, 12.0),
    "28#": (280, 82, 7.5, 12.5),
    "32#": (320, 88, 8.0, 14.0),
    "36#": (360, 96, 9.0, 16.0),
    "40#": (400, 100, 10.5, 18.0),
}

钢材密度_KG_PER_M3 = 7850.0
钢材密度_KG_PER_MM3 = 钢材密度_KG_PER_M3 * 1.0e-9

钢材抗弯强度表_MPA = {
    "Q235B": 215.0,
    "Q355B": 305.0,
}
重力加速度_M_S2 = 9.8


def 点字符串(x, y, z):
    return "({0:.1f}, {1:.1f}, {2:.1f})".format(float(x), float(y), float(z))


def 槽钢截面面积平方毫米(型号):
    """按当前建模截面计算理论截面面积(mm2)。"""
    h, b, d, t = 槽钢规格表[型号]
    有效腹板厚 = max(min(float(d), float(b)), 0.0)
    有效翼缘厚 = max(min(float(t), float(h) * 0.5), 0.0)
    开口净宽 = max(float(b) - 有效腹板厚, 0.0)
    开口净高 = max(float(h) - 有效翼缘厚 * 2.0, 0.0)
    return float(b) * float(h) - 开口净宽 * 开口净高


def 槽钢理论线密度千克每米(型号):
    """按钢材密度 7850kg/m3 计算理论线密度(kg/m)。"""
    return 槽钢截面面积平方毫米(型号) * 0.00785


def 槽钢理论重量千克(型号, 长度毫米):
    """按钢材密度 7850kg/m3 计算理论重量(kg)。"""
    return 槽钢截面面积平方毫米(型号) * max(float(长度毫米), 0.0) * 钢材密度_KG_PER_MM3


def 槽钢截面抵抗矩立方毫米(型号):
    """按当前建模截面计算绕强轴(平行翼缘)的截面抵抗矩 Wx(mm3)。"""
    h, b, d, t = 槽钢规格表[型号]
    有效腹板厚 = max(min(float(d), float(b)), 0.0)
    有效翼缘厚 = max(min(float(t), float(h) * 0.5), 0.0)
    开口净宽 = max(float(b) - 有效腹板厚, 0.0)
    开口净高 = max(float(h) - 有效翼缘厚 * 2.0, 0.0)
    惯性矩 = (float(b) * float(h) ** 3 - 开口净宽 * 开口净高 ** 3) / 12.0
    return 惯性矩 / (float(h) * 0.5)


def 钢材抗弯强度兆帕(牌号):
    """钢材抗弯强度设计值(N/mm2)：Q235B=215，Q355B=305，未知牌号按 Q235B。"""
    return 钢材抗弯强度表_MPA.get(str(牌号), 钢材抗弯强度表_MPA["Q235B"])


def 槽钢容许弯矩千牛米(型号, 牌号):
    """弯曲容许弯矩 Mu = f·Wx (kN·m)。"""
    return 钢材抗弯强度兆帕(牌号) * 槽钢截面抵抗矩立方毫米(型号) * 1.0e-6


def 槽钢均布承重千克(型号, 牌号, 长度毫米):
    """简支均布承载估算：满跨总承重 P = 8·f·Wx / (g·L) (kg)。"""
    L = max(float(长度毫米), 1.0)
    return 8.0 * 钢材抗弯强度兆帕(牌号) * 槽钢截面抵抗矩立方毫米(型号) / (重力加速度_M_S2 * L)


def 线段长度毫米(起点, 终点):
    dx = float(终点[0]) - float(起点[0])
    dy = float(终点[1]) - float(起点[1])
    dz = float(终点[2]) - float(起点[2])
    return (dx * dx + dy * dy + dz * dz) ** 0.5


def 槽钢记录字典(
    构件编号,
    构件名称,
    构件类别,
    型号,
    开口方向,
    起点,
    终点,
    几何体,
    钢材牌号="Q235B",
    是否开孔=False,
    孔数=0,
    孔径=0.0,
    孔间距=0.0,
    孔组中心Y=None,
):
    """为单根槽钢生成可追踪的力学计算元数据（含自重与承重量）。"""
    长度毫米 = 线段长度毫米(起点, 终点)
    截面面积 = 槽钢截面面积平方毫米(型号)
    理论重量 = 槽钢理论重量千克(型号, 长度毫米)
    容许弯矩 = 槽钢容许弯矩千牛米(型号, 钢材牌号)
    承重量 = 槽钢均布承重千克(型号, 钢材牌号, 长度毫米)
    return {
        "id": str(构件编号),
        "name": str(构件名称),
        "category": str(构件类别),
        "profile": str(型号),
        "section_area_mm2": round(截面面积, 3),
        "unit_weight_kg_per_m": round(槽钢理论线密度千克每米(型号), 6),
        "length_mm": round(长度毫米, 3),
        "weight_kg": round(理论重量, 6),
        "steel_grade": str(钢材牌号),
        "allowable_moment_kNm": round(容许弯矩, 3),
        "capacity_kg": round(承重量, 3),
        "opening_direction": str(开口方向),
        "start_point": [round(float(v), 3) for v in 起点],
        "end_point": [round(float(v), 3) for v in 终点],
        "start_point_text": 点字符串(*起点),
        "end_point_text": 点字符串(*终点),
        "has_holes": bool(是否开孔),
        "hole_count": int(孔数),
        "hole_diameter_mm": round(float(孔径), 3),
        "hole_spacing_mm": round(float(孔间距), 3),
        "hole_group_center_y_mm": None if 孔组中心Y is None else round(float(孔组中心Y), 3),
        "geometry": 几何体,
    }


def 槽钢截面(型号):
    """生成真实 C 形槽钢截面，截面形心居中，开口朝 +X。"""
    h, b, d, t = 槽钢规格表[型号]
    半高 = h * 0.5
    半宽 = b * 0.5
    return Section(
        Vec2(-半宽, -半高),
        Vec2(半宽, -半高),
        Vec2(半宽, -半高 + t),
        Vec2(-半宽 + d, -半高 + t),
        Vec2(-半宽 + d, 半高 - t),
        Vec2(半宽, 半高 - t),
        Vec2(半宽, 半高),
        Vec2(-半宽, 半高),
    )


def 水平槽钢_开向上(型号, x1, x2, y, z, 材质=None):
    """沿 X 方向布置，槽口朝 +Y。"""
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(0, 1, 0), pi / 2) * 构件
    构件 = rotation(Vec3(1, 0, 0), pi / 2) * 构件
    构件 = translate(x1, y, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 水平槽钢_开向下(型号, x1, x2, y, z, 材质=None):
    """沿 X 方向布置，槽口朝 -Y。"""
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(0, 1, 0), pi / 2) * 构件
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = translate(x1, y, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 竖向槽钢_开向右(型号, x, y1, y2, z, 材质=None):
    """沿 Y 方向布置，槽口朝 +X。"""
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = translate(x, y1, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 竖向槽钢_开向左(型号, x, y1, y2, z, 材质=None):
    """沿 Y 方向布置，槽口朝 -X。"""
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = rotation(Vec3(0, 1, 0), pi) * 构件
    构件 = translate(x, y1, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 差集(a, b):
    """兼容不同运行环境的布尔差集。"""
    try:
        return Cut(a, b)
    except Exception:
        if "substract" in globals():
            return substract(a, b)
        return a


def 双孔竖向槽钢(
    型号,
    x,
    y1,
    y2,
    z,
    开向右=True,
    孔径=60.0,
    孔间距=120.0,
    孔组偏移=0.0,
    孔组中心Y=None,
    材质=None,
):
    """沿 Y 方向的槽钢，在腹板指定高度开两个穿线圆孔。"""
    if 开向右:
        构件 = 竖向槽钢_开向右(型号, x, y1, y2, z, 材质)
    else:
        构件 = 竖向槽钢_开向左(型号, x, y1, y2, z, 材质)
    if 构件 is None:
        return None

    h, b, d, t = 槽钢规格表[型号]
    孔半径 = max(float(孔径) * 0.5, 0.1)
    孔距 = max(float(孔间距), 孔半径 * 2.5)
    if 孔组中心Y is None:
        孔组中心Y = (y1 + y2) * 0.5
    孔组中心Y = float(孔组中心Y) + float(孔组偏移)
    孔组中心Y = min(max(孔组中心Y, y1 + 孔距 * 0.5 + 孔半径), y2 - 孔距 * 0.5 - 孔半径)
    腹板中心X = x - b * 0.5 + d * 0.5 if 开向右 else x + b * 0.5 - d * 0.5
    切割超长 = max(b, d) + 20.0

    for 孔中心Y in (孔组中心Y - 孔距 * 0.5, 孔组中心Y + 孔距 * 0.5):
        切割体 = Cone(
            Vec3(腹板中心X - 切割超长, 孔中心Y, z),
            Vec3(腹板中心X + 切割超长, 孔中心Y, z),
            孔半径,
            孔半径,
        )
        构件 = 差集(构件, 切割体)
    return 构件


class 槽钢底座_图3(Component):
    def __init__(self):
        Component.__init__(self)
        self["输出模型"] = Attr(None, show=True)

        型号列表 = ["5#", "6.3#", "8#", "10#", "12#", "14#", "16#", "18#", "20#", "22#", "25#", "28#", "32#", "36#", "40#"]
        self["槽钢型号"] = Attr(
            "20#",
            obvious=True,
            combo=型号列表,
            group="型材",
            description="GB/T 706 标准槽钢型号(5#~40#)，用于内部杆件",
        )
        self["外层槽钢型号"] = Attr(
            "22#",
            obvious=True,
            combo=型号列表,
            group="型材",
            description="最外层边框使用的槽钢型号",
        )

        self["总长X"] = Attr(4000.0, obvious=True, readonly=True, group="尺寸", description="底座总长(mm)，按图示固定")
        self["总宽Y"] = Attr(3000.0, obvious=True, readonly=True, group="尺寸", description="底座总宽(mm)，按图示固定")

        self["开孔范围"] = Attr(
            "仅通高竖向槽钢",
            obvious=True,
            combo=["全部竖向槽钢", "仅通高竖向槽钢", "仅局部竖向槽钢"],
            group="开孔",
            description="选择需要开穿线孔的竖向槽钢范围",
        )
        self["中间孔径"] = Attr(60.0, obvious=True, group="开孔", description="中间双孔孔径(mm)")
        self["中间孔间距"] = Attr(120.0, obvious=True, group="开孔", description="中间双孔中心距(mm)")
        self["中间孔组偏移"] = Attr(0.0, obvious=True, group="开孔", description="孔组相对中点的偏移(mm)")

        self["钢材型号"] = Attr("Q235B", obvious=True, combo=["Q235B", "Q355B"], group="材质", description="结构钢材牌号（供承重验算读取）")

        self["材质颜色"] = Attr("", obvious=True, material=True, group="材质")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["槽钢总数"] = Attr(0, obvious=True, readonly=True, group="力学信息", description="当前底座包含的槽钢根数")
        self["理论总重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="按钢材密度7850kg/m3估算的理论总重量")
        self["内层槽钢承重合计kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="槽钢型号(内层)各杆简支均布承重合计")
        self["外层槽钢承重合计kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="外层槽钢型号各杆简支均布承重合计")
        self["总承重kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="总承重 = 槽钢型号承重合计 + 外层槽钢型号承重合计")
        self["槽钢ID汇总"] = Attr("", obvious=True, readonly=True, group="力学信息", description="当前所有槽钢的唯一编号汇总")
        self["槽钢明细JSON"] = Attr("", obvious=False, readonly=True, group="力学信息", description="每根槽钢的编号、型号、长度、理论重量、容许弯矩、承重量与坐标信息")
        self["槽钢明细属性容量"] = Attr(0, obvious=False, readonly=True, group="力学信息")

        self.replace()

    @export
    def replace(self):
        try:
            self._build()
        except Exception:
            self["输出模型"] = translate(0, 0, 0) * scale(100, 100, 100) * Cube()

    def _build(self):
        型号 = self["槽钢型号"]
        外层型号 = self["外层槽钢型号"]
        牌号 = self["钢材型号"]
        材质 = self["材质颜色"]
        开孔范围 = self["开孔范围"]
        中间孔径 = max(float(self["中间孔径"]), 0.0)
        中间孔间距 = max(float(self["中间孔间距"]), 0.0)
        中间孔组偏移 = float(self["中间孔组偏移"])
        W = 底座总长X
        H = 底座总宽Y
        self["总长X"] = W
        self["总宽Y"] = H

        构件记录 = []

        # ── 外框四道（外层槽钢型号，开口朝内，两端搭接）──
        外框参数 = [
            ("CG-H-01", "底边框横梁", 0.0, 水平槽钢_开向上, "向上", (0.0, 0.0, 0.0), (W, 0.0, 0.0)),
            ("CG-H-02", "顶边框横梁", H, 水平槽钢_开向下, "向下", (0.0, H, 0.0), (W, H, 0.0)),
            ("CG-V-01", "左边框立柱", 0.0, 竖向槽钢_开向右, "向右", (0.0, 0.0, 0.0), (0.0, H, 0.0)),
            ("CG-V-02", "右边框立柱", W, 竖向槽钢_开向左, "向左", (W, 0.0, 0.0), (W, H, 0.0)),
        ]
        for 编号, 名称, 位置, 工厂, 开口, 起点, 终点 in 外框参数:
            if 工厂 in (水平槽钢_开向上, 水平槽钢_开向下):
                几何 = 工厂(外层型号, 起点[0], 终点[0], 位置, 0.0, 材质)
            else:
                几何 = 工厂(外层型号, 位置, 起点[1], 终点[1], 0.0, 材质)
            if 几何:
                构件记录.append(
                    槽钢记录字典(编号, 名称, "外框槽钢", 外层型号, 开口, 起点, 终点, 几何, 牌号)
                )

        # ── 通高竖向槽钢（内部，交替开口）──
        序号 = 0
        for x in 竖向贯通X:
            序号 += 1
            开向右 = (序号 % 2 == 1)
            是否开孔 = 开孔范围 in ("全部竖向槽钢", "仅通高竖向槽钢") and 中间孔径 > 0
            if 是否开孔:
                几何 = 双孔竖向槽钢(
                    型号, x, 0.0, H, 0.0,
                    开向右=开向右,
                    孔径=中间孔径,
                    孔间距=中间孔间距,
                    孔组偏移=中间孔组偏移,
                    孔组中心Y=H * 0.5,
                    材质=材质,
                )
            else:
                工厂 = 竖向槽钢_开向右 if 开向右 else 竖向槽钢_开向左
                几何 = 工厂(型号, x, 0.0, H, 0.0, 材质)
            if 几何:
                构件记录.append(
                    槽钢记录字典(
                        "CG-V-{0:02d}".format(序号 + 2),
                        "竖向槽钢{0:02d}".format(序号),
                        "通高竖向槽钢", 型号,
                        "向右" if 开向右 else "向左",
                        (x, 0.0, 0.0), (x, H, 0.0), 几何, 牌号,
                        是否开孔=是否开孔,
                        孔数=2 if 是否开孔 else 0,
                        孔径=中间孔径 if 是否开孔 else 0.0,
                        孔间距=中间孔间距 if 是否开孔 else 0.0,
                        孔组中心Y=H * 0.5 + 中间孔组偏移 if 是否开孔 else None,
                    )
                )

        # ── 局部竖向槽钢 ──
        for x, y1, y2 in 竖向局部:
            序号 += 1
            开向右 = (序号 % 2 == 1)
            工厂 = 竖向槽钢_开向右 if 开向右 else 竖向槽钢_开向左
            是否开孔 = 开孔范围 in ("全部竖向槽钢", "仅局部竖向槽钢") and 中间孔径 > 0
            if 是否开孔:
                几何 = 双孔竖向槽钢(
                    型号, x, y1, y2, 0.0,
                    开向右=开向右,
                    孔径=中间孔径,
                    孔间距=中间孔间距,
                    孔组偏移=中间孔组偏移,
                    孔组中心Y=(y1 + y2) * 0.5,
                    材质=材质,
                )
            else:
                工厂 = 竖向槽钢_开向右 if 开向右 else 竖向槽钢_开向左
                几何 = 工厂(型号, x, y1, y2, 0.0, 材质)
            if 几何:
                构件记录.append(
                    槽钢记录字典(
                        "CG-V-{0:02d}".format(序号 + 2),
                        "竖向槽钢{0:02d}".format(序号),
                        "局部竖向槽钢", 型号,
                        "向右" if 开向右 else "向左",
                        (x, y1, 0.0), (x, y2, 0.0), 几何, 牌号,
                        是否开孔=是否开孔,
                        孔数=2 if 是否开孔 else 0,
                        孔径=中间孔径 if 是否开孔 else 0.0,
                        孔间距=中间孔间距 if 是否开孔 else 0.0,
                        孔组中心Y=(y1 + y2) * 0.5 + 中间孔组偏移 if 是否开孔 else None,
                    )
                )

        # ── 通长横向槽钢（内部，交替开口）──
        序号H = 0
        for y in 横向贯通Y:
            序号H += 1
            开向上 = (序号H % 2 == 1)
            工厂 = 水平槽钢_开向上 if 开向上 else 水平槽钢_开向下
            几何 = 工厂(型号, 0.0, W, y, 0.0, 材质)
            if 几何:
                构件记录.append(
                    槽钢记录字典(
                        "CG-H-{0:02d}".format(序号H + 2),
                        "横向槽钢{0:02d}".format(序号H),
                        "通长横向槽钢", 型号,
                        "向上" if 开向上 else "向下",
                        (0.0, y, 0.0), (W, y, 0.0), 几何, 牌号,
                    )
                )

        # ── 局部横向槽钢 ──
        for y, x1, x2 in 横向局部:
            序号H += 1
            开向上 = (序号H % 2 == 1)
            工厂 = 水平槽钢_开向上 if 开向上 else 水平槽钢_开向下
            起点x = x1
            终点x = x2
            几何 = 工厂(型号, 起点x, 终点x, y, 0.0, 材质)
            if 几何:
                构件记录.append(
                    槽钢记录字典(
                        "CG-H-{0:02d}".format(序号H + 2),
                        "横向槽钢{0:02d}".format(序号H),
                        "局部横向槽钢", 型号,
                        "向上" if 开向上 else "向下",
                        (起点x, y, 0.0), (终点x, y, 0.0), 几何, 牌号,
                    )
                )

        if not 构件记录:
            self._写入槽钢属性([], 型号, 外层型号)
            self["输出模型"] = translate(0, 0, 0) * scale(100, 100, 100) * Cube()
            return

        self._写入槽钢属性(构件记录, 型号, 外层型号)

        部件 = [记录["geometry"] for 记录 in 构件记录]
        结果 = 部件[0] if len(部件) == 1 else combine(*部件)

        self["输出模型"] = translate(self["X"], self["Y"], self["Z"]) * 结果

    def _确保槽钢明细属性(self, 目标数量):
        当前容量 = int(self["槽钢明细属性容量"]) if self["槽钢明细属性容量"] else 0
        if 当前容量 >= 目标数量:
            return 当前容量

        for i in range(当前容量 + 1, 目标数量 + 1):
            前缀 = "槽钢{0:02d}".format(i)
            self[前缀 + "_ID"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_名称"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_类别"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_型号"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_长度mm"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_截面面积mm2"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_理论重量kg"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_容许弯矩kN·m"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_承重kg"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_开口方向"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_起点"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_终点"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_开孔数"] = Attr(0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_孔径mm"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")

        self["槽钢明细属性容量"] = 目标数量
        return 目标数量

    def _清空槽钢槽位(self, 索引):
        前缀 = "槽钢{0:02d}".format(索引)
        self[前缀 + "_ID"] = ""
        self[前缀 + "_名称"] = ""
        self[前缀 + "_类别"] = ""
        self[前缀 + "_型号"] = ""
        self[前缀 + "_长度mm"] = 0.0
        self[前缀 + "_截面面积mm2"] = 0.0
        self[前缀 + "_理论重量kg"] = 0.0
        self[前缀 + "_容许弯矩kN·m"] = 0.0
        self[前缀 + "_承重kg"] = 0.0
        self[前缀 + "_开口方向"] = ""
        self[前缀 + "_起点"] = ""
        self[前缀 + "_终点"] = ""
        self[前缀 + "_开孔数"] = 0
        self[前缀 + "_孔径mm"] = 0.0

    def _写入槽钢属性(self, 构件记录, 型号, 外层型号):
        数量 = len(构件记录)
        容量 = self._确保槽钢明细属性(数量)
        总重量 = 0.0
        内层承重合计 = 0.0
        外层承重合计 = 0.0
        可序列化记录 = []

        for i, 记录 in enumerate(构件记录, start=1):
            前缀 = "槽钢{0:02d}".format(i)
            self[前缀 + "_ID"] = 记录["id"]
            self[前缀 + "_名称"] = 记录["name"]
            self[前缀 + "_类别"] = 记录["category"]
            self[前缀 + "_型号"] = 记录["profile"]
            self[前缀 + "_长度mm"] = 记录["length_mm"]
            self[前缀 + "_截面面积mm2"] = 记录["section_area_mm2"]
            self[前缀 + "_理论重量kg"] = 记录["weight_kg"]
            self[前缀 + "_容许弯矩kN·m"] = 记录["allowable_moment_kNm"]
            self[前缀 + "_承重kg"] = 记录["capacity_kg"]
            self[前缀 + "_开口方向"] = 记录["opening_direction"]
            self[前缀 + "_起点"] = 记录["start_point_text"]
            self[前缀 + "_终点"] = 记录["end_point_text"]
            self[前缀 + "_开孔数"] = 记录["hole_count"]
            self[前缀 + "_孔径mm"] = 记录["hole_diameter_mm"]
            总重量 += float(记录["weight_kg"])
            if 记录["profile"] == 外层型号 and 记录["profile"] != 型号:
                外层承重合计 += float(记录["capacity_kg"])
            else:
                内层承重合计 += float(记录["capacity_kg"])

            单根记录 = dict(记录)
            单根记录.pop("geometry", None)
            可序列化记录.append(单根记录)

        for i in range(数量 + 1, 容量 + 1):
            self._清空槽钢槽位(i)

        self["槽钢总数"] = 数量
        self["理论总重量kg"] = round(总重量, 6)
        self["内层槽钢承重合计kg"] = round(内层承重合计, 3)
        self["外层槽钢承重合计kg"] = round(外层承重合计, 3)
        self["总承重kg"] = round(内层承重合计 + 外层承重合计, 3)
        self["槽钢ID汇总"] = ", ".join([记录["id"] for 记录 in 构件记录])
        self["槽钢明细JSON"] = json.dumps(可序列化记录, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    FinalGeometry = 槽钢底座_图3()
    place(FinalGeometry)
