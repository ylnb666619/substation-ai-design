# -*- coding: utf-8 -*-
from pyp3d import *
import math


# ═══════════════════════════════════════════════════════════════
# 屋面面层（双坡普通平板）
#   覆盖在预制舱屋面龙骨上方，整体宽度+起坡高度与龙骨同名参数一致
#   → 坡角 = atan2(起坡高度, 整体宽度/2) 自动匹配龙骨
#   一点放置
# ═══════════════════════════════════════════════════════════════

class 屋面面层简单版(Component):
    """双坡普通屋面板，整体宽度+起坡高度匹配预制舱屋面龙骨。"""

    def __init__(self):
        Component.__init__(self)
        self["输出模型"] = Attr(None, show=True)

        # 构件分类（只读）
        self["场布分类"] = Attr("建/构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("屋架/屋面", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("屋面面层(简)", obvious=True, readonly=True, group="构件分类")

        # 屋面尺寸（整体宽度+起坡高度 与预制舱屋面龙骨同名，设相同值即坡角一致）
        self["整体长度"] = Attr(12100.0, obvious=True, group="屋面尺寸", description="屋面总长 X(mm)")
        self["整体宽度"] = Attr(3500.0, obvious=True, group="屋面尺寸", description="屋面总宽 Y(mm)，与龙骨整体宽度一致")
        self["起坡高度"] = Attr(500.0, obvious=True, group="屋面尺寸", description="屋脊高出檐口(mm)，与龙骨起坡高度一致")
        self["端部外伸"] = Attr(100.0, obvious=True, group="屋面尺寸", description="面板两端 X 向伸出(mm)")
        self["檐口外伸"] = Attr(100.0, obvious=True, group="屋面尺寸", description="面板檐口 Y 向伸出(mm)")

        # 面板
        self["面板厚"] = Attr(1.0, obvious=True, group="面板", description="面板厚度(mm)")

        # 定位
        self["X"] = Attr(0.0, obvious=True, group="定位", description="插入点 X 坐标(mm)")
        self["Y"] = Attr(0.0, obvious=True, group="定位", description="插入点 Y 坐标(mm)")
        self["Z"] = Attr(0.0, obvious=True, group="定位", description="插入点 Z 坐标(mm)")

        # 自定义材质
        self["面板颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        # ── 参数读取与校验 ──
        L = self["整体长度"]
        W = self["整体宽度"]
        H = self["起坡高度"]
        if L < 500:
            L = 500; self["整体长度"] = L
        if W < 500:
            W = 500; self["整体宽度"] = W
        if H < 50:
            H = 50; self["起坡高度"] = H

        面板厚 = max(self["面板厚"], 1.0); self["面板厚"] = 面板厚

        overhang_x = max(self["端部外伸"], 0)
        overhang_y = max(self["檐口外伸"], 0)
        面板色 = self["面板颜色"]

        def 着色(geom, color):
            return geom.material(color) if color else geom

        # ── 坡度几何（坡角 = atan2(H, W/2)，与龙骨侧坡一致） ──
        半宽 = W * 0.5
        坡角 = math.atan2(H, 半宽)
        坡长 = math.sqrt(半宽 ** 2 + H ** 2)
        外伸斜面 = overhang_y / math.cos(坡角)
        坡面斜长 = 坡长 + 外伸斜面
        板长X = L + overhang_x * 2

        def 构建单侧(起点X, 起点Y, 起点Z, 坡角值):
            """构建一侧坡面平板。"""
            plate = 着色(
                translate(0, 0, 0) * scale(板长X, 坡面斜长, 面板厚) * Cube(),
                面板色
            )
            return translate(起点X, 起点Y, 起点Z) \
                 * rotation(Vec3(1, 0, 0), 坡角值) \
                 * plate

        # ── 左坡（檐口 → 屋脊） ──
        左侧 = 构建单侧(起点X=-overhang_x, 起点Y=-overhang_y, 起点Z=0, 坡角值=坡角)

        # ── 右坡（屋脊 → 檐口，反向起坡） ──
        右侧 = 构建单侧(起点X=-overhang_x, 起点Y=半宽, 起点Z=H + overhang_y * math.tan(坡角), 坡角值=-坡角)

        # ── 输出 ──
        self["输出模型"] = translate(self["X"], self["Y"], self["Z"]) * combine(左侧, 右侧)

        # —— 自重：双坡展开面积 × 面板厚 × 钢 ——
        _L = float(self["整体长度"]); _W = float(self["整体宽度"])
        _h = float(self["起坡高度"]); _t = float(self["面板厚"])
        _slope = ((_W / 2.0) ** 2 + _h ** 2) ** 0.5 if _h > 0 else _W / 2.0
        _area = _L * (2.0 * _slope if _h > 0 else _W)
        self["自重_kg"] = round(_area * _t * 7850.0 / 1e9, 2)


if __name__ == "__main__":
    FinalGeometry = 屋面面层简单版()
    place(FinalGeometry)
