# -*- coding: utf-8 -*-
from pyp3d import *


class 钢底板(Component):
    """钢底板（纵横交错钢梁框架）— 对应 钢.ifc 中的钢框架结构"""
    def __init__(self):
        Component.__init__(self)

        # ---- 整体尺寸 ----
        self['总长'] = Attr(12000.00, obvious=True)       # X方向总长度
        self['总宽'] = Attr(3400.00, obvious=True)        # Y方向总宽度
        self['梁高'] = Attr(200.00, obvious=True)          # 梁截面高度
        self['梁宽'] = Attr(73.00, obvious=True)           # 梁截面宽度

        # ---- 网格划分 ----
        self['X方向格数'] = Attr(6, obvious=True)          # X方向分格数
        self['Y方向格数'] = Attr(4, obvious=True)          # Y方向分格数

        # ---- 位置调整 ----
        self['水平X偏移'] = Attr(0.00, obvious=True)
        self['水平Y偏移'] = Attr(0.00, obvious=True)
        self['旋转角度'] = Attr(0.00, obvious=True)

        # ---- 输出几何 ----
        self['钢底板'] = Attr(None, show=True)

        self.replace()

    @export
    def replace(self):
        L = self['总长']
        W = self['总宽']
        H = self['梁高']
        B = self['梁宽']
        nx = int(self['X方向格数'])
        ny = int(self['Y方向格数'])
        offX = self['水平X偏移']
        offY = self['水平Y偏移']
        Angle = self['旋转角度']

        # X方向梁间距 和 Y方向梁间距
        dx = L / nx
        dy = W / ny

        # ---- 先构建所有梁，用 combine 组合 ----
        frame = None

        # ---- X方向梁（沿Y方向排布）----
        for i in range(0, ny + 1):
            y = i * dy
            beam = trans(0, y, 0) * scale(L, B, H) * Cube()
            if frame is None:
                frame = beam
            else:
                frame = combine(frame, beam)

        # ---- Y方向梁（沿X方向排布）----
        for i in range(0, nx + 1):
            x = i * dx
            beam = trans(x, 0, 0) * scale(B, W, H) * Cube()
            if frame is None:
                frame = beam
            else:
                frame = combine(frame, beam)

        # ---- 整体偏移和旋转 ----
        result = trans(offX, offY, 0) * rotation(math.pi / 180 * Angle) * frame

        self['钢底板'] = result


if __name__ == "__main__":
    FinalGeometry = 钢底板()
    place(FinalGeometry)
