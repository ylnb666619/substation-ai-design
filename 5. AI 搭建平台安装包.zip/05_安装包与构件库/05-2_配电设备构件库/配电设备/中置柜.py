# -*- coding: utf-8 -*-
from pyp3d import *


class 中置柜(Component):
    """KYN28-12 中置式高压开关柜。"""

    def __init__(self):
        Component.__init__(self)
        self["中置柜"] = Attr(None, show=True)

        self["场布分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("中置柜", obvious=True, readonly=True, group="构件分类")

        self["柜宽"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体宽度 X(mm)")
        self["柜深"] = Attr(800.0, obvious=True, group="柜体尺寸", description="柜体深度 Y(mm)")
        self["柜高"] = Attr(2300.0, obvious=True, group="柜体尺寸", description="柜体总高 Z(mm)")

        self["前面板外挑"] = Attr(12.0, obvious=True, group="细化参数", description="前脸层次向外突出距离(mm)")

        self["柜名"] = Attr("中置柜", obvious=True, group="标识", description="柜体编号，显示在正面")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["柜色"] = Attr("", obvious=True, material=True, group="自定义材质项")

        self["标称重量"] = Attr(800.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["柜宽"]), 200.0)
        D = max(float(self["柜深"]), 200.0)
        H = max(float(self["柜高"]), 500.0)
        front_out = max(min(float(self["前面板外挑"]), max(D * 0.18, 8.0)), 8.0)
        cabinet_name = str(self["柜名"])
        cabinet_material = self["柜色"]

        self["柜宽"] = W
        self["柜深"] = D
        self["柜高"] = H
        self["前面板外挑"] = front_out

        base_h = max(H * 0.040, 72.0)
        cap_h = max(H * 0.020, 34.0)
        frame_w = max(W * 0.032, 24.0)
        h_top = H * 0.75
        h_bot = H * 0.22
        panel_depth = front_out + 6.0
        trim_depth = max(front_out * 0.55, 8.0)
        plinth_out = max(front_out * 1.25, 16.0)

        c_body = (0.48, 0.54, 0.62, 1.0)
        c_light = (0.61, 0.67, 0.75, 1.0)
        c_dark = (0.27, 0.31, 0.38, 1.0)
        c_accent = (0.74, 0.78, 0.84, 1.0)
        c_handle = (0.76, 0.61, 0.30, 1.0)
        c_glass = (0.48, 0.86, 0.96, 0.28)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = cabinet_material if use_cabinet_material else ""
            geom = self._box(x, y, z, sx, sy, sz)
            parts.append(self._finish(geom, color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_cabinet_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_cabinet_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_cabinet_material)

        # 柜体主体
        append_box(0, 0, 0, W, D, H, c_body, use_cabinet_material=True)

        # 底座与顶帽，先做出前后层次
        append_box(-W * 0.020, -plinth_out, 0, W * 1.040, max(D * 0.10, 60.0) + plinth_out, base_h, c_dark, use_cabinet_material=True)
        append_box(W * 0.10, -plinth_out - 4.0, base_h * 0.18, W * 0.80, 6.0, max(base_h * 0.22, 14.0), c_dark)
        append_box(-W * 0.012, -front_out * 0.85, H - cap_h, W * 1.024, max(D * 0.08, 42.0) + front_out * 0.85, cap_h, c_light, use_cabinet_material=True)

        # 前脸外围压边和护角
        append_frame(frame_w * 0.55, -trim_depth, base_h, W - frame_w * 1.10, trim_depth + 2.0, H - base_h - cap_h * 0.35, frame_w * 0.55, c_dark)
        guard_w = max(W * 0.018, 12.0)
        append_box(-guard_w * 0.15, -front_out * 0.45, base_h, guard_w, front_out * 0.45 + 3.0, H - base_h - cap_h * 0.30, c_dark)
        append_box(W - guard_w * 0.85, -front_out * 0.45, base_h, guard_w, front_out * 0.45 + 3.0, H - base_h - cap_h * 0.30, c_dark)

        # 分区横向压条
        append_box(0, -4.0, h_top, W, 4.0, 5.0, c_dark)
        append_box(0, -4.0, h_bot, W, 4.0, 5.0, c_dark)

        # 顶部仪表小门
        meter_w = W * 0.50
        meter_h = max(H * 0.12, 230.0)
        meter_x = (W - meter_w) * 0.5
        meter_z = h_top + H * 0.02
        append_box(meter_x, -panel_depth, meter_z, meter_w, panel_depth + 5.0, meter_h, c_light, use_cabinet_material=True)

        bezel_w = meter_w * 0.68
        bezel_h = meter_h * 0.42
        bezel_x = (W - bezel_w) * 0.5
        bezel_z = meter_z + meter_h * 0.30
        bezel_t = min(max(bezel_w * 0.09, 14.0), bezel_h * 0.25)
        append_frame(bezel_x, -panel_depth - 4.0, bezel_z, bezel_w, panel_depth + 8.0, bezel_h, bezel_t, c_accent)
        append_box(
            bezel_x + bezel_t * 0.60,
            -panel_depth - 6.0,
            bezel_z + bezel_t * 0.50,
            bezel_w - bezel_t * 1.20,
            6.0,
            bezel_h - bezel_t * 1.00,
            c_glass,
        )
        append_box(meter_x + meter_w * 0.18, -panel_depth - 5.0, meter_z + meter_h * 0.12, meter_w * 0.42, 5.0, meter_h * 0.08, c_dark)
        append_box(meter_x + meter_w * 0.82, -panel_depth - 7.0, meter_z + meter_h * 0.18, W * 0.032, 7.0, meter_h * 0.48, c_handle)

        # 中部断路器室大门
        main_w = W * 0.74
        main_h = (h_top - h_bot) * 0.80
        main_x = (W - main_w) * 0.5
        main_z = h_bot + (h_top - h_bot - main_h) * 0.5
        append_box(main_x, -panel_depth - 2.0, main_z, main_w, panel_depth + 8.0, main_h, c_body, use_cabinet_material=True)

        inner_margin_x = max(main_w * 0.065, 24.0)
        inner_margin_z = max(main_h * 0.09, 28.0)
        inner_border = min(max(main_w * 0.028, 14.0), inner_margin_x * 0.75, inner_margin_z * 0.75)
        append_frame(
            main_x + inner_margin_x,
            -panel_depth - 5.0,
            main_z + inner_margin_z,
            main_w - inner_margin_x * 2.0,
            panel_depth + 11.0,
            main_h - inner_margin_z * 2.0,
            inner_border,
            c_accent,
        )

        window_w = main_w * 0.34
        window_h = main_h * 0.24
        window_x = (W - window_w) * 0.5
        window_z = main_z + main_h * 0.54
        window_border = min(max(window_w * 0.10, 14.0), window_h * 0.28)
        append_frame(window_x, -panel_depth - 7.0, window_z, window_w, panel_depth + 13.0, window_h, window_border, c_dark)
        append_box(
            window_x + window_border * 0.60,
            -panel_depth - 9.0,
            window_z + window_border * 0.50,
            window_w - window_border * 1.20,
            6.0,
            window_h - window_border * 1.00,
            c_glass,
        )

        append_box(main_x + main_w * 0.79, -panel_depth - 8.0, main_z + main_h * 0.22, max(W * 0.035, 24.0), panel_depth + 14.0, main_h * 0.46, c_handle)
        append_box(main_x + main_w * 0.15, -panel_depth - 6.0, main_z + main_h * 0.18, main_w * 0.24, panel_depth + 10.0, max(main_h * 0.085, 24.0), c_dark)
        append_box(main_x + main_w * 0.20, -panel_depth - 7.0, main_z + main_h * 0.66, main_w * 0.18, panel_depth + 11.0, max(main_h * 0.060, 18.0), c_accent)

        hinge_h = max(main_h * 0.08, 34.0)
        hinge_w = max(W * 0.022, 18.0)
        for ratio in (0.18, 0.50, 0.82):
            hz = main_z + main_h * ratio - hinge_h * 0.5
            append_box(main_x + 8.0, -panel_depth - 5.0, hz, hinge_w, panel_depth + 11.0, hinge_h, c_dark)

        # 下部电缆室门板
        lower_w = W * 0.74
        lower_h = h_bot * 0.72
        lower_x = (W - lower_w) * 0.5
        lower_z = H * 0.04
        append_box(lower_x, -panel_depth, lower_z, lower_w, panel_depth + 6.0, lower_h, c_light, use_cabinet_material=True)
        append_frame(
            lower_x + lower_w * 0.06,
            -panel_depth - 3.0,
            lower_z + lower_h * 0.10,
            lower_w * 0.88,
            panel_depth + 9.0,
            lower_h * 0.80,
            max(lower_w * 0.026, 12.0),
            c_accent,
        )

        louver_w = lower_w * 0.46
        louver_h = max(lower_h * 0.055, 12.0)
        louver_x = lower_x + lower_w * 0.18
        for i in range(4):
            louver_z = lower_z + lower_h * 0.23 + i * louver_h * 1.85
            append_box(louver_x, -panel_depth - 7.0, louver_z, louver_w, 6.0, louver_h, c_dark)

        append_box(lower_x + lower_w * 0.80, -panel_depth - 6.0, lower_z + lower_h * 0.20, max(W * 0.030, 22.0), panel_depth + 12.0, lower_h * 0.44, c_handle)
        append_box(lower_x + lower_w * 0.22, -panel_depth - 5.0, lower_z + lower_h * 0.74, lower_w * 0.40, 5.0, max(lower_h * 0.08, 16.0), c_dark)

        # 柜名三维文字
        char_w = W * 0.11
        char_h = H * 0.070
        ascii_n = sum(1 for c in cabinet_name if c.isascii())
        cjk_n = len(cabinet_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.0, 1.0)
        text_len = unit_count * char_w
        max_text_len = W * 0.78
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len

        text_z = min(H * 0.89, H - cap_h - char_h * 1.15)

        text_sec = (
            translate((W - text_len) * 0.5, 1.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(cabinet_name, char_w, char_h)
        )
        text_3d = Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -10, 0))).color(*c_text)
        parts.append(text_3d)

        self["中置柜"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = 中置柜()
    place(FinalGeometry)
