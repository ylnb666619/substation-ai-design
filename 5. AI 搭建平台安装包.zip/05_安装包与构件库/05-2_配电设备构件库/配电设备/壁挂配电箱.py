# -*- coding: utf-8 -*-
from pyp3d import *


class 壁挂配电箱(Component):
    """壁挂式配电箱。"""

    def __init__(self):
        Component.__init__(self)
        self["壁挂配电箱"] = Attr(None, show=True)

        self["空间分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("壁挂配电箱", obvious=True, readonly=True, group="构件分类")

        self["箱宽"] = Attr(500.0, obvious=True, group="箱体尺寸", description="箱体宽度 X(mm)")
        self["箱深"] = Attr(250.0, obvious=True, group="箱体尺寸", description="箱体进深 Y(mm)")
        self["箱高"] = Attr(300.0, obvious=True, group="箱体尺寸", description="箱体高度 Z(mm)")

        self["门板外挑"] = Attr(12.0, obvious=True, group="细化参数", description="门板向外突出距离(mm)")

        self["箱名"] = Attr("壁挂配电箱", obvious=True, group="标识", description="显示在门板上的名称")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["箱色"] = Attr("", obvious=True, material=True, group="自定义材质")

        self["标称重量"] = Attr(30.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["箱宽"]), 220.0)
        D = max(float(self["箱深"]), 120.0)
        H = max(float(self["箱高"]), 220.0)
        door_out = max(min(float(self["门板外挑"]), max(D * 0.30, 8.0)), 8.0)
        box_name = str(self["箱名"])
        box_material = self["箱色"]

        self["箱宽"] = W
        self["箱深"] = D
        self["箱高"] = H
        self["门板外挑"] = door_out

        rim_w = max(W * 0.045, 18.0)
        panel_depth = door_out + 7.0
        frame_depth = max(door_out * 0.65, 8.0)
        ear_w = max(W * 0.055, 18.0)
        ear_d = max(D * 0.16, 18.0)
        rain_h = max(H * 0.08, 18.0)

        c_body = (0.58, 0.62, 0.68, 1.0)
        c_light = (0.72, 0.76, 0.82, 1.0)
        c_dark = (0.28, 0.32, 0.39, 1.0)
        c_accent = (0.80, 0.84, 0.88, 1.0)
        c_handle = (0.79, 0.62, 0.31, 1.0)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_box_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = box_material if use_box_material else ""
            parts.append(self._finish(self._box(x, y, z, sx, sy, sz), color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_box_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_box_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_box_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_box_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_box_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_box_material)

        append_box(0, 0, 0, W, D, H, c_body, use_box_material=True)
        append_box(0, D * 0.84, 0, W, max(D * 0.16, 14.0), H, c_dark)

        ear_h = H * 0.42
        ear_z = (H - ear_h) * 0.5
        for ear_x in (-ear_w, W):
            append_box(ear_x, D * 0.56, ear_z, ear_w, ear_d, ear_h, c_dark)
            hole = max(ear_w * 0.36, 6.0)
            append_box(ear_x + (0 if ear_x < 0 else ear_w - hole), D * 0.60, ear_z + ear_h * 0.18, hole, 4.0, hole, c_accent)
            append_box(ear_x + (0 if ear_x < 0 else ear_w - hole), D * 0.60, ear_z + ear_h * 0.66, hole, 4.0, hole, c_accent)

        append_box(-W * 0.020, -door_out * 0.95, H - rain_h, W * 1.040, door_out * 0.70 + 6.0, rain_h, c_light, use_box_material=True)
        append_box(W * 0.06, -door_out * 0.55, H - rain_h * 0.45, W * 0.88, 5.0, max(rain_h * 0.22, 6.0), c_dark)

        append_frame(rim_w * 0.55, -frame_depth, rim_w * 0.55, W - rim_w * 1.10, frame_depth + 2.0, H - rim_w * 1.10, rim_w * 0.55, c_dark)

        door_x = rim_w
        door_z = rim_w
        door_w = W - rim_w * 2.0
        door_h = H - rim_w * 2.0
        append_box(door_x, -panel_depth, door_z, door_w, panel_depth + 8.0, door_h, c_body, use_box_material=True)
        append_frame(
            door_x + door_w * 0.08,
            -panel_depth - 4.0,
            door_z + door_h * 0.10,
            door_w * 0.84,
            panel_depth + 11.0,
            door_h * 0.80,
            max(door_w * 0.030, 10.0),
            c_accent,
        )
        append_box(door_x + door_w * 0.18, -panel_depth - 5.0, door_z + door_h * 0.70, door_w * 0.44, 5.0, max(door_h * 0.08, 14.0), c_dark)
        append_box(door_x + door_w * 0.16, -panel_depth - 3.0, door_z + door_h * 0.20, door_w * 0.68, 3.0, max(door_h * 0.14, 18.0), c_light)

        hinge_w = max(W * 0.030, 12.0)
        hinge_h = max(H * 0.10, 24.0)
        for ratio in (0.18, 0.50, 0.82):
            hz = door_z + door_h * ratio - hinge_h * 0.5
            append_box(door_x - hinge_w * 0.35, -panel_depth - 6.0, hz, hinge_w, panel_depth + 13.0, hinge_h, c_dark)
            append_box(door_x - hinge_w * 0.10, -panel_depth - 10.0, hz + hinge_h * 0.18, hinge_w * 0.45, 4.0, hinge_h * 0.64, c_handle)

        lock_w = max(W * 0.055, 16.0)
        lock_h = max(H * 0.16, 34.0)
        lock_x = door_x + door_w * 0.82
        lock_z = door_z + door_h * 0.36
        append_box(lock_x, -panel_depth - 8.0, lock_z, lock_w, panel_depth + 15.0, lock_h, c_handle)
        append_box(lock_x - lock_w * 0.55, -panel_depth - 5.0, lock_z + lock_h * 0.36, lock_w * 0.70, 5.0, lock_h * 0.22, c_dark)

        gland_plate_w = W * 0.62
        gland_plate_x = (W - gland_plate_w) * 0.5
        append_box(gland_plate_x, D * 0.05, 0, gland_plate_w, max(D * 0.08, 12.0), max(H * 0.05, 12.0), c_dark)
        hole_count = 4
        hole_r = max(W * 0.032, 8.0)
        hole_h = max(D * 0.16, 18.0)
        hole_gap = gland_plate_w / (hole_count + 1)
        for i in range(hole_count):
            hx = gland_plate_x + hole_gap * (i + 1)
            parts.append(self._finish(Cone(Vec3(hx, D * 0.08, 0), Vec3(hx, D * 0.08, -hole_h), hole_r, hole_r), c_dark))

        char_w = min(W * 0.060, door_w * 0.12)
        char_h = H * 0.12
        ascii_n = sum(1 for c in box_name if ord(c) < 128)
        cjk_n = len(box_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.2, 1.0)
        text_len = unit_count * char_w
        max_text_len = door_w * 0.76
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len
        text_x = door_x + (door_w - text_len) * 0.5
        name_band_h = max(H * 0.10, 20.0)
        name_band_z = door_z + door_h * 0.76
        append_box(door_x + door_w * 0.12, -panel_depth - 10.0, name_band_z, door_w * 0.76, 6.0, name_band_h, c_light)
        text_z = name_band_z + name_band_h * 0.12
        text_sec = (
            translate(text_x, -panel_depth - 14.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(box_name, char_w, char_h)
        )
        parts.append(Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -8, 0))).color(*c_text))

        self["壁挂配电箱"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = 壁挂配电箱()
    place(FinalGeometry)
