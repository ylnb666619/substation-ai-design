# -*- coding: utf-8 -*-
from pyp3d import *


class 干式变压器(Component):
    """SCB 干式变压器。"""

    def __init__(self):
        Component.__init__(self)
        self["干式变压器"] = Attr(None, show=True)

        self["空间分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("干式变压器", obvious=True, readonly=True, group="构件分类")

        self["柜宽"] = Attr(2000.0, obvious=True, group="柜体尺寸", description="变压器宽度 X(mm)")
        self["柜深"] = Attr(1600.0, obvious=True, group="柜体尺寸", description="变压器深度 Y(mm)")
        self["柜高"] = Attr(1800.0, obvious=True, group="柜体尺寸", description="变压器总高 Z(mm)")

        self["前面板外挑"] = Attr(18.0, obvious=True, group="细化参数", description="正面铭牌和检修面板向外突出距离(mm)")
        self["侧散热外挑"] = Attr(120.0, obvious=True, group="细化参数", description="两侧散热片向外突出距离(mm)")

        self["柜名"] = Attr("干式变压器", obvious=True, group="标识", description="显示在正面的设备名称")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["柜色"] = Attr("", obvious=True, material=True, group="自定义材质")

        self["标称重量"] = Attr(2800.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["柜宽"]), 800.0)
        D = max(float(self["柜深"]), 600.0)
        H = max(float(self["柜高"]), 1200.0)
        front_out = max(min(float(self["前面板外挑"]), max(D * 0.10, 10.0)), 10.0)
        fin_out = max(min(float(self["侧散热外挑"]), max(W * 0.12, 60.0)), max(W * 0.03, 24.0))
        cabinet_name = str(self["柜名"])
        cabinet_material = self["柜色"]

        self["柜宽"] = W
        self["柜深"] = D
        self["柜高"] = H
        self["前面板外挑"] = front_out
        self["侧散热外挑"] = fin_out

        base_h = max(H * 0.075, 90.0)
        cap_h = max(H * 0.060, 78.0)
        body_z = base_h
        body_h = H - base_h - cap_h
        frame_w = max(W * 0.028, 24.0)
        panel_depth = front_out + 8.0
        plinth_out = max(front_out * 1.35, 24.0)
        fin_y0 = D * 0.10
        fin_span = D * 0.78

        c_body = (0.50, 0.55, 0.63, 1.0)
        c_light = (0.67, 0.72, 0.78, 1.0)
        c_dark = (0.26, 0.31, 0.38, 1.0)
        c_accent = (0.79, 0.83, 0.88, 1.0)
        c_handle = (0.80, 0.63, 0.32, 1.0)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = cabinet_material if use_cabinet_material else ""
            parts.append(self._finish(self._box(x, y, z, sx, sy, sz), color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_cabinet_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_cabinet_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_cabinet_material)

        # 主体、底座、顶帽
        append_box(0, 0, body_z, W, D, body_h, c_body, use_cabinet_material=True)
        append_box(-W * 0.030, -plinth_out, 0, W * 1.060, max(D * 0.12, 80.0) + plinth_out, base_h, c_dark, use_cabinet_material=True)
        append_box(W * 0.08, -plinth_out - 4.0, base_h * 0.18, W * 0.26, 6.0, max(base_h * 0.24, 16.0), c_dark)
        append_box(W * 0.66, -plinth_out - 4.0, base_h * 0.18, W * 0.26, 6.0, max(base_h * 0.24, 16.0), c_dark)
        append_box(-W * 0.018, -front_out * 0.85, H - cap_h, W * 1.036, max(D * 0.08, 56.0) + front_out * 0.85, cap_h, c_light, use_cabinet_material=True)
        append_box(W * 0.12, -front_out * 0.55, H - cap_h * 0.35, W * 0.76, 5.0, max(cap_h * 0.20, 12.0), c_dark)

        # 正面外框和分区
        append_frame(frame_w * 0.55, -panel_depth * 0.55, body_z, W - frame_w * 1.10, panel_depth * 0.55 + 4.0, body_h, frame_w * 0.55, c_dark)
        split_top = body_z + body_h * 0.72
        split_bottom = body_z + body_h * 0.28
        append_box(W * 0.03, -4.0, split_top, W * 0.94, 4.0, 5.0, c_dark)
        append_box(W * 0.03, -4.0, split_bottom, W * 0.94, 4.0, 5.0, c_dark)

        # 正面铭牌和信息面板
        label_w = W * 0.56
        label_h = max(H * 0.085, 64.0)
        label_x = (W - label_w) * 0.5
        label_z = split_top + body_h * 0.06
        append_box(label_x, -panel_depth - 8.0, label_z, label_w, panel_depth + 14.0, label_h, c_light)
        append_frame(
            label_x + label_w * 0.06,
            -panel_depth - 11.0,
            label_z + label_h * 0.12,
            label_w * 0.88,
            panel_depth + 17.0,
            label_h * 0.76,
            max(label_w * 0.022, 14.0),
            c_accent,
        )
        append_box(label_x + label_w * 0.76, -panel_depth - 12.0, label_z + label_h * 0.24, max(W * 0.028, 18.0), panel_depth + 18.0, label_h * 0.42, c_handle)
        append_box(label_x + label_w * 0.18, -panel_depth - 10.0, label_z + label_h * 0.68, label_w * 0.22, 6.0, max(label_h * 0.10, 12.0), c_dark)

        info_w = W * 0.72
        info_h = max(body_h * 0.22, 180.0)
        info_x = (W - info_w) * 0.5
        info_z = split_bottom + (split_top - split_bottom - info_h) * 0.42
        append_box(info_x, -panel_depth - 2.0, info_z, info_w, panel_depth + 10.0, info_h, c_body, use_cabinet_material=True)
        append_frame(
            info_x + info_w * 0.07,
            -panel_depth - 6.0,
            info_z + info_h * 0.10,
            info_w * 0.86,
            panel_depth + 14.0,
            info_h * 0.80,
            max(info_w * 0.024, 12.0),
            c_accent,
        )
        append_box(info_x + info_w * 0.20, -panel_depth - 9.0, info_z + info_h * 0.20, max(W * 0.028, 18.0), panel_depth + 17.0, info_h * 0.44, c_handle)
        append_box(info_x + info_w * 0.76, -panel_depth - 9.0, info_z + info_h * 0.20, max(W * 0.028, 18.0), panel_depth + 17.0, info_h * 0.44, c_handle)
        append_box(info_x + info_w * 0.24, -panel_depth - 7.0, info_z + info_h * 0.72, info_w * 0.22, 7.0, max(info_h * 0.10, 16.0), c_dark)
        append_box(info_x + info_w * 0.54, -panel_depth - 7.0, info_z + info_h * 0.72, info_w * 0.22, 7.0, max(info_h * 0.10, 16.0), c_dark)
        append_box(W * 0.50 - 3.0, -4.0, info_z, 6.0, 4.0, info_h, c_dark)

        lower_box_w = W * 0.46
        lower_box_h = max(body_h * 0.18, 120.0)
        lower_box_x = (W - lower_box_w) * 0.5
        lower_box_z = body_z + body_h * 0.08
        append_box(lower_box_x, -panel_depth, lower_box_z, lower_box_w, panel_depth + 8.0, lower_box_h, c_light, use_cabinet_material=True)
        append_frame(
            lower_box_x + lower_box_w * 0.08,
            -panel_depth - 4.0,
            lower_box_z + lower_box_h * 0.12,
            lower_box_w * 0.84,
            panel_depth + 12.0,
            lower_box_h * 0.76,
            max(lower_box_w * 0.024, 10.0),
            c_accent,
        )
        port_w = lower_box_w * 0.14
        port_h = lower_box_h * 0.28
        for ratio in (0.18, 0.43, 0.68):
            append_box(lower_box_x + lower_box_w * ratio, -panel_depth - 7.0, lower_box_z + lower_box_h * 0.24, port_w, panel_depth + 15.0, port_h, c_dark)

        # 两侧散热片
        fin_count = 9
        fin_depth = min(max(fin_span / (fin_count + 1) * 0.62, 42.0), D * 0.09)
        fin_height = body_h * 0.74
        fin_z = body_z + body_h * 0.12
        fin_gap = fin_span / max(fin_count - 1, 1)
        for i in range(fin_count):
            fin_y = fin_y0 + i * fin_gap
            append_box(-fin_out, fin_y, fin_z, fin_out, fin_depth, fin_height, c_dark)
            append_box(W, fin_y, fin_z, fin_out, fin_depth, fin_height, c_dark)
            append_box(-fin_out * 0.72, fin_y + fin_depth * 0.18, fin_z + fin_height * 0.08, fin_out * 0.32, fin_depth * 0.64, fin_height * 0.84, c_accent)
            append_box(W + fin_out * 0.40, fin_y + fin_depth * 0.18, fin_z + fin_height * 0.08, fin_out * 0.32, fin_depth * 0.64, fin_height * 0.84, c_accent)

        # 顶部套管和吊耳
        post_base_z = H - cap_h * 0.10
        post_h = max(H * 0.10, 120.0)
        post_r = max(W * 0.018, 20.0)
        for px in (W * 0.22, W * 0.50, W * 0.78):
            py = D * 0.34
            parts.append(self._finish(Cone(Vec3(px, py, post_base_z), Vec3(px, py, post_base_z + post_h), post_r, post_r * 0.78), c_handle))
            append_box(px - post_r * 1.10, py - post_r * 1.10, post_base_z - 16.0, post_r * 2.20, post_r * 2.20, 16.0, c_dark)

        lug_w = max(W * 0.050, 40.0)
        lug_d = max(D * 0.050, 34.0)
        lug_h = max(H * 0.040, 36.0)
        for x0 in (W * 0.08, W * 0.86):
            for y0 in (D * 0.14, D * 0.80):
                append_box(x0, y0, H - lug_h, lug_w, lug_d, lug_h, c_dark)
                append_box(x0 + lug_w * 0.22, y0 + lug_d * 0.22, H - lug_h * 0.35, lug_w * 0.56, lug_d * 0.56, lug_h * 0.18, c_accent)

        # 正面文字，单独前置，避免被挡
        char_w = W * 0.075
        char_h = H * 0.070
        ascii_n = sum(1 for c in cabinet_name if ord(c) < 128)
        cjk_n = len(cabinet_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.0, 1.0)
        text_len = unit_count * char_w
        max_text_len = label_w * 0.74
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len
        text_x = label_x + (label_w - text_len) * 0.5
        text_z = label_z + label_h * 0.18
        text_sec = (
            translate(text_x, -panel_depth - 14.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(cabinet_name, char_w, char_h)
        )
        parts.append(Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -10, 0))).color(*c_text))

        self["干式变压器"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = 干式变压器()
    place(FinalGeometry)
