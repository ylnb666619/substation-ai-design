# -*- coding: utf-8 -*-
"""
BIMBase 预制舱逃生门 - 完整参数化构件

优化内容：
1. 合页改为预制双层对开门同款大尺寸外挑铰链，每扇 3 个。
2. 门扇改成更厚实的夹芯门效果，增加压边、内板、踢脚板细节。
3. 保留门框、锁盒、天地锁杆、密封条和预设记忆功能，方便 BIMBase 复用。

坐标系：
- X = 宽度方向
- Y = 厚度方向
- Z = 高度方向
"""

from pyp3d import *
import json
import os


_MEMORY_FILE = os.path.join(os.path.dirname(__file__), "params_memory.json")


def _load_presets():
    if os.path.exists(_MEMORY_FILE):
        try:
            with open(_MEMORY_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(data, dict):
                return data
        except Exception:
            pass
    return {}


def _save_presets(presets):
    try:
        with open(_MEMORY_FILE, "w", encoding="utf-8") as f:
            json.dump(presets, f, ensure_ascii=False, indent=2)
    except Exception:
        pass


def _build_preset_combo():
    presets = _load_presets()
    combo = [k for k in presets.keys() if k]
    if "默认" not in combo:
        combo.insert(0, "默认")
    combo += ["——————", "● 保存为预设...", "● 删除预设..."]
    return combo


class 预制舱逃生门(Component):
    def __init__(self):
        Component.__init__(self)

        self["预制舱逃生门"] = Attr(None, show=True)

        self["场布分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("门", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("预制舱逃生门", obvious=True, readonly=True, group="构件分类")

        self["净宽"] = Attr(980.0, obvious=True, group="门洞尺寸", combo=[800, 900, 980, 1000, 1200])
        self["净高"] = Attr(1980.0, obvious=True, group="门洞尺寸", combo=[1800, 1980, 2000, 2100, 2400])
        self["门框进深"] = Attr(50.0, obvious=True, group="门洞尺寸")

        self["边框宽度"] = Attr(20.0, obvious=True, group="门扇参数", combo=[15, 20, 25, 30, 40, 50])
        self["板厚"] = Attr(2.0, obvious=True, group="门扇参数", combo=[1.5, 2.0, 2.5, 3.0, 4.0, 5.0])

        self["记忆预设"] = Attr("默认", obvious=True, combo=_build_preset_combo(), group="参数记忆")
        self["预设名称"] = Attr("", obvious=True, group="参数记忆")

        self["X偏移"] = Attr(0.0, obvious=True, group="定位")
        self["Y偏移"] = Attr(0.0, obvious=True, group="定位")
        self["Z偏移"] = Attr(0.0, obvious=True, group="定位")

        self["门框颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["门扇颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    def _apply_preset(self, name):
        presets = _load_presets()
        if name not in presets:
            return

        preset = presets[name]
        for key in ["净宽", "净高", "边框宽度", "板厚"]:
            if key in preset:
                self[key] = preset[key]

    def _save_current_as_preset(self, name):
        presets = _load_presets()
        presets[name] = {
            "净宽": self["净宽"],
            "净高": self["净高"],
            "边框宽度": self["边框宽度"],
            "板厚": self["板厚"],
        }
        _save_presets(presets)
        self["记忆预设"] = name

    def _delete_named_preset(self, name):
        presets = _load_presets()
        if name in presets:
            del presets[name]
            _save_presets(presets)
        self["记忆预设"] = "默认"

    def _box(self, cx, cy, cz, sx, sy, sz, color_value):
        return Box(
            Vec3(cx - sx / 2, cy - sy / 2, cz - sz / 2),
            Vec3(cx - sx / 2, cy - sy / 2, cz + sz / 2),
            Vec3(1, 0, 0),
            Vec3(0, 1, 0),
            sx,
            sy,
            sx,
            sy,
        ).color(*color_value)

    def _paint(self, geom, material_name):
        if material_name:
            return geom.material(material_name)
        return geom

    def _hinge(self, x_edge, cz, hinge_w, hinge_h, frame_depth, col_plate, col_barrel, col_pin, is_left):
        plate_w = hinge_w / 2.0
        plate_t = 10.0
        plate_h = hinge_h

        barrel_w = max(24.0, hinge_w * 0.10)
        barrel_t = 22.0
        barrel_h = hinge_h + 18.0

        pin_w = max(8.0, barrel_w * 0.32)
        pin_t = 10.0
        pin_h = hinge_h + 34.0

        screw_w = max(10.0, hinge_w * 0.04)
        screw_t = 6.0
        screw_h = max(10.0, hinge_h * 0.05)
        screw_dz = hinge_h * 0.28

        plate_y = max(frame_depth * 0.60, plate_t * 0.5)
        barrel_y = frame_depth - barrel_t * 0.5 + max(frame_depth * 0.06, 2.0)
        pin_y = frame_depth - pin_t * 0.5 + max(frame_depth * 0.10, 4.0)
        half_plate_w = plate_w * 0.5

        if is_left:
            frame_x = x_edge - half_plate_w
            leaf_x = x_edge + half_plate_w
            barrel_x = x_edge - 1.0
        else:
            frame_x = x_edge + half_plate_w
            leaf_x = x_edge - half_plate_w
            barrel_x = x_edge + 1.0

        return combine(
            self._box(frame_x, plate_y, cz, plate_w, plate_t, plate_h, col_plate),
            self._box(leaf_x, plate_y, cz, plate_w, plate_t, plate_h, col_plate),
            self._box(barrel_x, barrel_y, cz, barrel_w, barrel_t, barrel_h, col_barrel),
            self._box(barrel_x, pin_y, cz, pin_w, pin_t, pin_h, col_pin),
            self._box(frame_x, pin_y, cz - screw_dz, screw_w, screw_t, screw_h, col_pin),
            self._box(frame_x, pin_y, cz + screw_dz, screw_w, screw_t, screw_h, col_pin),
            self._box(leaf_x, pin_y, cz - screw_dz, screw_w, screw_t, screw_h, col_pin),
            self._box(leaf_x, pin_y, cz + screw_dz, screw_w, screw_t, screw_h, col_pin),
        )

    @export
    def replace(self):
        preset_action = self["记忆预设"]
        preset_name = str(self["预设名称"]).strip()

        if preset_action == "● 保存为预设..." and preset_name:
            self._save_current_as_preset(preset_name)
        elif preset_action == "● 删除预设..." and preset_name:
            self._delete_named_preset(preset_name)
        else:
            presets = _load_presets()
            if preset_action in presets:
                self._apply_preset(preset_action)

        clear_w = max(float(self["净宽"]), 100.0)
        clear_h = max(float(self["净高"]), 100.0)
        frame_depth = max(float(self["门框进深"]), 30.0)
        border_w = max(float(self["边框宽度"]), 5.0)
        panel_t = max(float(self["板厚"]), 0.5)

        self["净宽"] = clear_w
        self["净高"] = clear_h
        self["门框进深"] = frame_depth
        self["边框宽度"] = border_w
        self["板厚"] = panel_t

        frame_material = self["门框颜色"]
        leaf_material = self["门扇颜色"]

        c_frame = (0.35, 0.40, 0.48, 1.0)
        c_leaf = (0.50, 0.58, 0.68, 1.0)
        c_leaf_light = (0.58, 0.65, 0.74, 1.0)
        c_leaf_dark = (0.40, 0.47, 0.57, 1.0)
        c_dark = (0.25, 0.28, 0.35, 1.0)
        c_seal = (0.10, 0.10, 0.10, 1.0)
        c_silver = (0.72, 0.72, 0.72, 1.0)
        c_gold = (0.75, 0.60, 0.28, 1.0)

        outer_w = clear_w + 2.0 * border_w
        outer_h = clear_h + 2.0 * border_w
        half_outer_w = outer_w * 0.5
        half_outer_h = outer_h * 0.5
        half_clear_w = clear_w * 0.5
        half_clear_h = clear_h * 0.5

        leaf_w = max(clear_w - 2.0, 120.0)
        leaf_h = max(clear_h - 2.0, 240.0)
        leaf_total_t = min(max(panel_t * 3.5, 8.0), frame_depth * 0.60)
        leaf_y = frame_depth * 0.5 - leaf_total_t * 0.5

        # 门框主体
        corner_size = min(max(border_w * 1.8, 18.0), min(outer_w, outer_h) * 0.16)
        frame_parts = [
            self._box(-half_outer_w + border_w * 0.5, frame_depth * 0.5, 0, border_w, frame_depth, outer_h, c_frame),
            self._box(half_outer_w - border_w * 0.5, frame_depth * 0.5, 0, border_w, frame_depth, outer_h, c_frame),
            self._box(0, frame_depth * 0.5, half_outer_h - border_w * 0.5, outer_w, frame_depth, border_w, c_frame),
            self._box(0, frame_depth * 0.5, -half_outer_h + border_w * 0.5, outer_w, frame_depth, border_w, c_frame),
            self._box(-half_outer_w + corner_size * 0.5, frame_depth * 0.5, -half_outer_h + corner_size * 0.5, corner_size, frame_depth, corner_size, c_dark),
            self._box(-half_outer_w + corner_size * 0.5, frame_depth * 0.5, half_outer_h - corner_size * 0.5, corner_size, frame_depth, corner_size, c_dark),
            self._box(half_outer_w - corner_size * 0.5, frame_depth * 0.5, -half_outer_h + corner_size * 0.5, corner_size, frame_depth, corner_size, c_dark),
            self._box(half_outer_w - corner_size * 0.5, frame_depth * 0.5, half_outer_h - corner_size * 0.5, corner_size, frame_depth, corner_size, c_dark),
        ]

        # 内止口和压边，让门框更立体
        stop_t = min(max(border_w * 0.35, 4.0), max(border_w - 2.0, 4.0))
        stop_d = min(max(frame_depth * 0.20, 8.0), frame_depth * 0.42)
        stop_y = frame_depth - stop_d * 0.5 - 1.0
        frame_parts.extend(
            [
                self._box(-half_clear_w + stop_t * 0.5, stop_y, 0, stop_t, stop_d, clear_h + 4.0, c_leaf_dark),
                self._box(half_clear_w - stop_t * 0.5, stop_y, 0, stop_t, stop_d, clear_h + 4.0, c_leaf_dark),
                self._box(0, stop_y, half_clear_h - stop_t * 0.5, clear_w - 2.0, stop_d, stop_t, c_leaf_dark),
                self._box(0, stop_y, -half_clear_h + stop_t * 0.5, clear_w - 2.0, stop_d, stop_t, c_leaf_dark),
            ]
        )
        frame = self._paint(combine(*frame_parts), frame_material)

        # 门扇主体与压边细节
        trim_w = min(max(border_w * 0.55, 16.0), leaf_w * 0.10, leaf_h * 0.10)
        trim_t = max(panel_t * 1.25, 2.0)
        trim_y = leaf_y + leaf_total_t * 0.28
        center_panel_w = max(leaf_w - 2.0 * (trim_w + 24.0), leaf_w * 0.42)
        center_panel_h = max(leaf_h - 2.0 * (trim_w + 36.0), leaf_h * 0.42)
        kick_h = min(max(clear_h * 0.18, 220.0), leaf_h * 0.28)
        kick_z = -leaf_h * 0.5 + kick_h * 0.5 + 70.0
        back_panel_margin = max(trim_w + 10.0, 26.0)
        back_panel_y = leaf_y - leaf_total_t * 0.24

        leaf_parts = [
            self._box(0, leaf_y, 0, leaf_w, leaf_total_t, leaf_h, c_leaf),
            self._box(-leaf_w * 0.5 + trim_w * 0.5, trim_y, 0, trim_w, trim_t, leaf_h - trim_w * 2.0, c_leaf_light),
            self._box(leaf_w * 0.5 - trim_w * 0.5, trim_y, 0, trim_w, trim_t, leaf_h - trim_w * 2.0, c_leaf_light),
            self._box(0, trim_y, leaf_h * 0.5 - trim_w * 0.5, leaf_w - trim_w * 2.0, trim_t, trim_w, c_leaf_light),
            self._box(0, trim_y, -leaf_h * 0.5 + trim_w * 0.5, leaf_w - trim_w * 2.0, trim_t, trim_w, c_leaf_light),
            self._box(0, trim_y + 0.8, 0, center_panel_w, max(trim_t * 0.85, 1.5), center_panel_h, c_leaf_dark),
            self._box(0, trim_y + 1.2, kick_z, max(leaf_w - 140.0, leaf_w * 0.55), max(trim_t * 0.9, 1.5), kick_h, c_dark),
            self._box(0, back_panel_y, 0, max(leaf_w - back_panel_margin * 2.0, 120.0), max(panel_t, 1.5), max(leaf_h - back_panel_margin * 2.0, 220.0), c_leaf_light),
        ]
        leaf = self._paint(combine(*leaf_parts), leaf_material)

        # 合页：沿用双层对开门那种外挑大铰链，左侧三只
        hinge_w = leaf_w / 4.0
        hinge_h = leaf_h / 8.0
        hinge_gap = max((leaf_h - hinge_h * 3.0) / 4.0, 20.0)
        hinge_zs = (
            -leaf_h * 0.5 + hinge_gap + hinge_h * 0.5,
            0.0,
            leaf_h * 0.5 - hinge_gap - hinge_h * 0.5,
        )
        hinge_edge_x = -leaf_w * 0.5
        hinges = combine(
            self._hinge(hinge_edge_x, hinge_zs[0], hinge_w, hinge_h, frame_depth, c_silver, c_dark, c_gold, True),
            self._hinge(hinge_edge_x, hinge_zs[1], hinge_w, hinge_h, frame_depth, c_silver, c_dark, c_gold, True),
            self._hinge(hinge_edge_x, hinge_zs[2], hinge_w, hinge_h, frame_depth, c_silver, c_dark, c_gold, True),
        )

        # 五金：锁盒、推杆、天地锁杆
        hardware_x = half_clear_w - max(border_w * 0.6, 38.0)
        hardware_z = -half_clear_h + min(1050.0, clear_h * 0.58)
        hardware_y = frame_depth - 8.0
        push_bar_len = min(max(leaf_w * 0.52, 340.0), leaf_w - 120.0)

        lock_parts = [
            self._box(hardware_x, hardware_y, hardware_z, 34.0, 18.0, 92.0, c_gold),
            self._box(hardware_x - 10.0, hardware_y - 2.0, hardware_z, 12.0, 10.0, 56.0, c_dark),
            self._box(0, hardware_y + 4.0, hardware_z, push_bar_len, 8.0, 16.0, c_silver),
            self._box(-push_bar_len * 0.5 + 24.0, hardware_y + 1.5, hardware_z, 12.0, 10.0, 28.0, c_dark),
            self._box(push_bar_len * 0.5 - 24.0, hardware_y + 1.5, hardware_z, 12.0, 10.0, 28.0, c_dark),
            self._box(hardware_x, hardware_y - 3.0, 0, 6.0, 6.0, leaf_h - 150.0, c_dark),
            self._box(hardware_x, hardware_y, leaf_h * 0.5 - 44.0, 10.0, 8.0, 26.0, c_silver),
            self._box(hardware_x, hardware_y, -leaf_h * 0.5 + 44.0, 10.0, 8.0, 26.0, c_silver),
        ]
        hardware = combine(*lock_parts)

        # 密封条
        seal_t = 2.5
        seal_d = frame_depth * 0.55
        seal_y = seal_d * 0.5
        seal = combine(
            self._box(-half_clear_w, seal_y, 0, seal_t, seal_d, leaf_h + 4.0, c_seal),
            self._box(half_clear_w, seal_y, 0, seal_t, seal_d, leaf_h + 4.0, c_seal),
            self._box(0, seal_y, half_clear_h, leaf_w - 2.0, seal_d, seal_t, c_seal),
            self._box(0, seal_y, -half_clear_h, leaf_w - 2.0, seal_d, seal_t, c_seal),
        )

        door = combine(frame, leaf, hinges, hardware, seal)

        dx = float(self["X偏移"])
        dy = float(self["Y偏移"])
        dz = float(self["Z偏移"])
        self["预制舱逃生门"] = translate(dx, dy, dz) * door

        # —— 自重：门扇 + 门框 ——
        _W = float(self["净宽"]); _H = float(self["净高"]); _t = float(self["板厚"])
        _fd = float(self["门框进深"]); _fw = float(self["边框宽度"])
        self["自重_kg"] = round((_W * _H * _t * 7850.0 + (2.0 * _H + _W) * _fw * _fd * 7850.0) / 1e9, 2)


if __name__ == "__main__":
    FinalGeometry = 预制舱逃生门()
    place(FinalGeometry)
