# -*- coding: utf-8 -*-
"""
玻璃窗 - 参数化铝合金玻璃窗

优化点：
1. 保留原有基础参数名，兼容现有调用。
2. 增加窗扇边框、双面压条、可选分格和外窗台，更适合 BIMBase 中查看。
3. 增加材质与定位参数，方便后续复用。

坐标系：
- 原点位于窗外框左下前角
- X 为宽度方向
- Y 为进深方向
- Z 为高度方向
"""

from pyp3d import *


def _着色(几何体, 颜色=None, 材质=""):
    if 几何体 is None:
        return None
    if 材质:
        return 几何体.material(材质)
    if 颜色:
        return 几何体.color(*颜色)
    return 几何体


def _块(x, y, z, sx, sy, sz, 颜色=None, 材质=""):
    if sx <= 0 or sy <= 0 or sz <= 0:
        return None
    几何体 = translate(x, y, z) * scale(sx, sy, sz) * Cube()
    return _着色(几何体, 颜色, 材质)


def _矩形框(x, y, z, w, d, h, t, 颜色=None, 材质=""):
    if w <= 0 or d <= 0 or h <= 0 or t <= 0:
        return []
    if w <= 2 * t or h <= 2 * t:
        return [_块(x, y, z, w, d, h, 颜色, 材质)]
    return [
        _块(x, y, z, w, d, t, 颜色, 材质),
        _块(x, y, z + h - t, w, d, t, 颜色, 材质),
        _块(x, y, z + t, t, d, h - 2 * t, 颜色, 材质),
        _块(x + w - t, y, z + t, t, d, h - 2 * t, 颜色, 材质),
    ]


def _压条框(x, y, z, w, d, h, 宽度, 颜色=None, 材质=""):
    if w <= 2 * 宽度 or h <= 2 * 宽度:
        return []
    return _矩形框(x, y, z, w, d, h, 宽度, 颜色, 材质)


class 玻璃窗(Component):
    def __init__(self):
        Component.__init__(self)

        self["玻璃窗"] = Attr(None, show=True)

        self["场布分类"] = Attr("建筑构件", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("窗户", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("玻璃窗", obvious=True, readonly=True, group="构件分类")

        self["窗宽"] = Attr(630.0, obvious=True, group="主体尺寸", description="窗外框总宽")
        self["窗高"] = Attr(1360.0, obvious=True, group="主体尺寸", description="窗外框总高")
        self["框厚"] = Attr(50.0, obvious=True, group="主体尺寸", description="外框可见宽度")
        self["框深"] = Attr(60.0, obvious=True, group="主体尺寸", description="窗框进深")
        self["玻璃厚"] = Attr(8.0, obvious=True, group="主体尺寸", description="玻璃厚度")

        self["窗扇边宽"] = Attr(26.0, obvious=True, group="细化参数", description="内扇边框宽度")
        self["压条宽"] = Attr(12.0, obvious=True, group="细化参数", description="玻璃压条可见宽度")
        self["中挺宽"] = Attr(24.0, obvious=True, group="细化参数", description="分格中挺宽度")
        self["外窗台外挑"] = Attr(18.0, obvious=True, group="细化参数", description="外窗台向外挑出尺寸")
        self["窗台厚"] = Attr(12.0, obvious=True, group="细化参数", description="外窗台厚度")
        self["分格模式"] = Attr(
            "整块玻璃",
            obvious=True,
            combo=["整块玻璃", "左右双扇", "田字分格"],
            group="细化参数",
            description="窗扇分格方式",
        )

        self["框材质"] = Attr("", obvious=True, material=True, group="材质")
        self["玻璃材质"] = Attr("", obvious=True, material=True, group="材质")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        W = max(float(self["窗宽"]), 240.0)
        H = max(float(self["窗高"]), 320.0)
        FD = max(float(self["框深"]), 30.0)
        FT = max(float(self["框厚"]), 18.0)
        FT = min(FT, min(W, H) * 0.25)
        GT = max(float(self["玻璃厚"]), 4.0)
        GT = min(GT, FD - 4.0)

        扇边宽 = max(float(self["窗扇边宽"]), 12.0)
        压条宽 = max(float(self["压条宽"]), 6.0)
        中挺宽 = max(float(self["中挺宽"]), 12.0)
        外挑 = max(float(self["外窗台外挑"]), 0.0)
        窗台厚 = max(float(self["窗台厚"]), 6.0)
        分格模式 = self["分格模式"]

        内洞宽 = max(W - 2 * FT, 80.0)
        内洞高 = max(H - 2 * FT, 120.0)

        扇进深 = max(FD * 0.58, 26.0)
        扇进深 = min(扇进深, FD - 6.0)
        扇Y = (FD - 扇进深) * 0.5
        扇X = FT + 6.0
        扇Z = FT + 6.0
        扇宽 = max(W - 2 * 扇X, 80.0)
        扇高 = max(H - 2 * 扇Z, 140.0)

        扇边宽 = min(扇边宽, 扇宽 * 0.25, 扇高 * 0.25)
        压条宽 = min(压条宽, 扇边宽 * 0.85)
        中挺宽 = min(中挺宽, max((扇宽 - 2 * 扇边宽) * 0.35, 12.0))

        玻璃Y = (FD - GT) * 0.5
        压条进深 = max((扇进深 - GT) * 0.5, 3.0)
        压条前Y = 扇Y + 1.0
        压条后Y = 扇Y + 扇进深 - 压条进深 - 1.0

        框材质 = self["框材质"]
        玻璃材质 = self["玻璃材质"]

        铝框深色 = (0.34, 0.38, 0.44, 1.0)
        铝框浅色 = (0.57, 0.61, 0.67, 1.0)
        玻璃色 = (0.52, 0.84, 0.94, 0.24)
        胶条色 = (0.12, 0.12, 0.13, 1.0)

        parts = []

        # 外框主体
        parts.extend(_矩形框(0, 0, 0, W, FD, H, FT, 铝框深色, 框材质))

        # 内外装饰压边，让轮廓更清晰
        装饰宽 = min(max(FT * 0.34, 8.0), FT - 4.0)
        parts.extend(_矩形框(装饰宽 * 0.5, -1.0, 装饰宽 * 0.5, W - 装饰宽, min(FD * 0.22, 12.0) + 2.0, H - 装饰宽, 装饰宽, 铝框浅色, 框材质))
        parts.extend(_矩形框(装饰宽 * 0.5, FD - min(FD * 0.22, 12.0) - 1.0, 装饰宽 * 0.5, W - 装饰宽, min(FD * 0.22, 12.0) + 2.0, H - 装饰宽, 装饰宽, 铝框浅色, 框材质))

        # 内扇框
        parts.extend(_矩形框(扇X, 扇Y, 扇Z, 扇宽, 扇进深, 扇高, 扇边宽, 铝框浅色, 框材质))

        玻璃格列表 = []
        内净宽 = 扇宽 - 2 * 扇边宽
        内净高 = 扇高 - 2 * 扇边宽
        内净X = 扇X + 扇边宽
        内净Z = 扇Z + 扇边宽

        if 分格模式 == "整块玻璃":
            玻璃格列表.append((内净X, 内净Z, 内净宽, 内净高))
        elif 分格模式 == "左右双扇":
            左右单格宽 = max((内净宽 - 中挺宽) * 0.5, 40.0)
            中挺X = 扇X + (扇宽 - 中挺宽) * 0.5
            parts.append(_块(中挺X, 扇Y, 内净Z, 中挺宽, 扇进深, 内净高, 铝框浅色, 框材质))
            玻璃格列表.append((内净X, 内净Z, 左右单格宽, 内净高))
            玻璃格列表.append((中挺X + 中挺宽, 内净Z, 左右单格宽, 内净高))
        else:
            左右单格宽 = max((内净宽 - 中挺宽) * 0.5, 40.0)
            上下单格高 = max((内净高 - 中挺宽) * 0.5, 60.0)
            中挺X = 扇X + (扇宽 - 中挺宽) * 0.5
            横挺Z = 扇Z + (扇高 - 中挺宽) * 0.5
            parts.append(_块(中挺X, 扇Y, 内净Z, 中挺宽, 扇进深, 内净高, 铝框浅色, 框材质))
            parts.append(_块(内净X, 扇Y, 横挺Z, 内净宽, 扇进深, 中挺宽, 铝框浅色, 框材质))
            玻璃格列表.append((内净X, 内净Z, 左右单格宽, 上下单格高))
            玻璃格列表.append((中挺X + 中挺宽, 内净Z, 左右单格宽, 上下单格高))
            玻璃格列表.append((内净X, 横挺Z + 中挺宽, 左右单格宽, 上下单格高))
            玻璃格列表.append((中挺X + 中挺宽, 横挺Z + 中挺宽, 左右单格宽, 上下单格高))

        # 玻璃与双面压条
        for gx, gz, gw, gh in 玻璃格列表:
            if gw <= 20 or gh <= 20:
                continue

            glass = _块(gx, 玻璃Y, gz, gw, GT, gh, 玻璃色, 玻璃材质)
            parts.append(glass)

            bead_front = _压条框(gx, 压条前Y, gz, gw, 压条进深, gh, 压条宽, 铝框浅色, 框材质)
            bead_back = _压条框(gx, 压条后Y, gz, gw, 压条进深, gh, 压条宽, 铝框浅色, 框材质)
            parts.extend(bead_front)
            parts.extend(bead_back)

            # 玻璃四周胶条
            胶条厚 = max(min(GT * 0.35, 3.0), 1.5)
            胶条前Y = 玻璃Y - 胶条厚
            胶条后Y = 玻璃Y + GT
            parts.extend(_压条框(gx, 胶条前Y, gz, gw, 胶条厚, gh, max(压条宽 * 0.35, 3.0), 胶条色, ""))
            parts.extend(_压条框(gx, 胶条后Y, gz, gw, 胶条厚, gh, max(压条宽 * 0.35, 3.0), 胶条色, ""))

        # 外窗台和滴水小压板
        parts.append(_块(-8.0, -外挑, -窗台厚, W + 16.0, FD + 外挑, 窗台厚, 铝框深色, 框材质))
        parts.append(_块(-4.0, -6.0, H, W + 8.0, min(FD * 0.24, 12.0), 8.0, 铝框浅色, 框材质))

        有效件 = [p for p in parts if p]
        if not 有效件:
            self["玻璃窗"] = translate(self["X"], self["Y"], self["Z"]) * scale(100, 100, 100) * Cube()
            return

        self["玻璃窗"] = translate(self["X"], self["Y"], self["Z"]) * combine(*有效件)

        # —— 自重：玻璃 + 铝框（空心折减 0.5）——
        _W = float(self["窗宽"]); _H = float(self["窗高"])
        _tg = float(self["玻璃厚"]); _tf = float(self["框厚"]); _df = float(self["框深"])
        self["自重_kg"] = round((_W * _H * _tg * 2500.0 + (_W + _H) * 2.0 * _tf * _df * 2700.0 * 0.5) / 1e9, 2)


if __name__ == "__main__":
    FinalGeometry = 玻璃窗()
    place(FinalGeometry)
