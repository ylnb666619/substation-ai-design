# -*- coding: utf-8 -*-
"""
变电设备槽钢焊接底座 — 参数化建模
  全部构件使用 C 型槽钢真实截面（Sweep 扫掠）
  7根槽钢相互延伸搭接，布尔合并为单个实体
  坐标系原点左下角(0,0)，X向右，Y向上，Z高度参数输入
"""

from pyp3d import *

# =====================================================================
# 标准槽钢截面尺寸表 (GB/T 706)
# =====================================================================
规格表 = {
    '10#': (100, 48,  5.3, 8.5),
    '12#': (120, 53,  5.5, 9.0),
    '14#': (140, 60,  6.0, 9.5),
    '16#': (160, 65,  8.5, 10.0),
    '18#': (180, 70,  9.0, 10.5),
    '20#': (200, 75,  9.0, 11.0),
    '22#': (220, 80,  9.5, 11.5),
    '25#': (250, 82, 11.0, 12.0),
}


def 槽钢截面(型号):
    """生成槽钢真实 C 形截面，形心居中，开口朝 +X"""
    h, b, d, t = 规格表[型号]
    hh = h * 0.5
    hw = b * 0.5
    return Section(
        Vec2(-hw, -hh),         # ① 腹板背面、下端
        Vec2( hw, -hh),         # ② 下翼缘尖、下
        Vec2( hw, -hh + t),     # ③ 下翼缘尖、上
        Vec2(-hw + d, -hh + t), # ④ 腹板前面、下端
        Vec2(-hw + d,  hh - t), # ⑤ 腹板前面、上端
        Vec2( hw,  hh - t),     # ⑥ 上翼缘尖、下
        Vec2( hw,  hh),         # ⑦ 上翼缘尖、上
        Vec2(-hw,  hh),         # ⑧ 腹板背面、上端
    )


# =====================================================================
# 四种开口方向的槽钢生成函数
# =====================================================================

def 水平槽钢_开向上(型号, x1, x2, y, z, 材质=None):
    """水平槽钢，开口朝 +Y（向上）"""
    截面 = 槽钢截面(型号)
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    path = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    solid = Sweep(截面, path)
    solid = rotation(Vec3(0, 1, 0), pi / 2) * solid      # Z→X
    solid = rotation(Vec3(1, 0, 0), pi / 2) * solid      # X→Y（开口向上）
    solid = translate(x1, y, z) * solid
    if 材质:
        solid = solid.material(材质)
    return solid


def 水平槽钢_开向下(型号, x1, x2, y, z, 材质=None):
    """水平槽钢，开口朝 -Y（向下）"""
    截面 = 槽钢截面(型号)
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    path = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    solid = Sweep(截面, path)
    solid = rotation(Vec3(0, 1, 0), pi / 2) * solid      # Z→X
    solid = rotation(Vec3(1, 0, 0), -pi / 2) * solid     # X→-Y（开口向下）
    solid = translate(x1, y, z) * solid
    if 材质:
        solid = solid.material(材质)
    return solid


def 竖向槽钢_开向右(型号, x, y1, y2, z, 材质=None):
    """竖向槽钢，开口朝 +X（向右）"""
    截面 = 槽钢截面(型号)
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    path = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    solid = Sweep(截面, path)
    solid = rotation(Vec3(1, 0, 0), -pi / 2) * solid     # Z→Y
    solid = translate(x, y1, z) * solid
    if 材质:
        solid = solid.material(材质)
    return solid


def 竖向槽钢_开向左(型号, x, y1, y2, z, 材质=None):
    """竖向槽钢，开口朝 -X（向左）"""
    截面 = 槽钢截面(型号)
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    path = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    solid = Sweep(截面, path)
    solid = rotation(Vec3(1, 0, 0), -pi / 2) * solid     # Z→Y
    solid = rotation(Vec3(0, 1, 0), pi) * solid          # X→-X（开口向左）
    solid = translate(x, y1, z) * solid
    if 材质:
        solid = solid.material(材质)
    return solid


# =====================================================================
# 主构件：变电设备槽钢焊接底座
# =====================================================================

class 变电设备底座(Component):
    """
    变电设备槽钢焊接底座
    外框：X总宽1677 × Y总高1540
    7根C型槽钢相互延伸搭接 → 布尔合并为单实体
    """

    def __init__(self):
        Component.__init__(self)
        self["底座"] = Attr(None, show=True)

        # ── 参数 ──
        self["槽钢型号"] = Attr('20#', obvious=True,
                              combo=['10#', '12#', '14#', '16#', '18#', '20#', '22#', '25#'],
                              group="规格参数", description="GB/T 706 标准槽钢型号")
        self["底座高度Z"] = Attr(300.0, obvious=True, group="规格参数",
                                description="底座底面距地面高度(mm)")

        self["X总宽"] = Attr(1677.0, obvious=True, group="外形尺寸",
                            description="底座外框X方向总宽度(mm)")
        self["Y总高"] = Attr(1540.0, obvious=True, group="外形尺寸",
                            description="底座外框Y方向总高度(mm)")
        self["内横梁右端X"] = Attr(1420.0, obvious=True, group="外形尺寸",
                                   description="内部水平横梁右端X坐标(mm)")
        self["内横梁下Y"] = Attr(870.0, obvious=True, group="外形尺寸",
                                description="内部下横梁Y坐标(mm)")
        self["内横梁上Y"] = Attr(1235.0, obvious=True, group="外形尺寸",
                                description="内部上横梁Y坐标(mm)")

        self["杆件搭接伸量"] = Attr(50.0, obvious=True, group="搭接构造",
                                    description="槽钢端部伸出外框轴线的搭接长度(mm)，四角闭合用")

        self["构件模式"] = Attr('完整底座(7根)', obvious=True,
                              combo=['完整底座(7根)', '仅外框(4根)'],
                              group="构件模式", description="切换显示完整底座或仅外框")

        self["材质颜色"] = Attr("", obvious=True, material=True, group="材质")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        型号 = self["槽钢型号"]
        Z座 = self["底座高度Z"]

        X总 = self["X总宽"]
        Y总 = self["Y总高"]
        X内右 = self["内横梁右端X"]
        Y内下 = self["内横梁下Y"]
        Y内上 = self["内横梁上Y"]
        延伸量 = self["杆件搭接伸量"]
        模式 = self["构件模式"]
        材质 = self["材质颜色"]

        # 参数校验
        if X内右 > X总:
            X内右 = X总
            self["内横梁右端X"] = X内右
        if Y内上 > Y总:
            Y内上 = Y总
            self["内横梁上Y"] = Y内上

        # ── 截面尺寸 ──
        h, b, d, t = 规格表[型号]

        # 水平横梁（4根）—— 两端各延伸 延伸量
        beam1 = 水平槽钢_开向上(型号, -延伸量, X总 + 延伸量, 0, Z座, 材质)          # Y=0
        beam2 = 水平槽钢_开向下(型号, -延伸量, X总 + 延伸量, Y总, Z座, 材质)        # Y=1540
        beam3 = 水平槽钢_开向上(型号, -延伸量, X内右 + 延伸量, Y内下, Z座, 材质)    # Y=870
        beam4 = 水平槽钢_开向下(型号, -延伸量, X内右 + 延伸量, Y内上, Z座, 材质)    # Y=1235

        # 竖向槽钢（3根通长）—— 两端各延伸 延伸量
        beam5 = 竖向槽钢_开向右(型号, 0, -延伸量, Y总 + 延伸量, Z座, 材质)          # X=0
        beam6 = 竖向槽钢_开向左(型号, X内右, -延伸量, Y总 + 延伸量, Z座, 材质)      # X=1420
        beam7 = 竖向槽钢_开向左(型号, X总, -延伸量, Y总 + 延伸量, Z座, 材质)        # X=1677

        # ── 按构件模式选择 ──
        if 模式 == '仅外框(4根)':
            选中的梁 = [beam1, beam2, beam5, beam7]
        else:
            选中的梁 = [beam1, beam2, beam3, beam4, beam5, beam6, beam7]

        # ── 收集非空 ──
        all_beams = [b for b in 选中的梁 if b]
        if not all_beams:
            self["底座"] = translate(self["X"], self["Y"], self["Z"]) * scale(100, 100, 100) * Cube()
            return

        # ── 布尔并集合并 ──
        result = all_beams[0]
        for b in all_beams[1:]:
            result = result + b

        dx = self["X"]; dy = self["Y"]; dz = self["Z"]
        self["底座"] = translate(dx, dy, dz) * result

        # —— 自重：梁格总长 × 槽钢线密度 ——
        _槽钢线密度 = {"10#": 10.007, "12#": 12.059, "14#": 14.535, "16#": 17.240,
                      "18#": 20.174, "20#": 22.637, "22#": 24.999, "25#": 27.410}
        _kgm = _槽钢线密度.get(str(self["槽钢型号"]), 22.637)
        _X = float(self["X总宽"]); _Y = float(self["Y总高"])
        _inner = 0.0 if "仅外框" in str(self["构件模式"]) else 3.0
        self["自重_kg"] = round((2.0 * (_X + _Y) + _inner * _X) / 1000.0 * _kgm, 2)


if __name__ == "__main__":
    FinalGeometry = 变电设备底座()
    place(FinalGeometry)
