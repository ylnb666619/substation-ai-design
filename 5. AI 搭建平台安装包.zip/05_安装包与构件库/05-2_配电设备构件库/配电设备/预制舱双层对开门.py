# -*- coding: utf-8 -*-
from pyp3d import *

class 预制舱对开双层逃生门(Component):
    def __init__(self):
        Component.__init__(self)
        self['对开双层逃生门']=Attr(None,show=True)
        self['场布分类']=Attr('建/构筑物',obvious=True,readonly=True,group='构件分类')
        self['构件类型']=Attr('门',obvious=True,readonly=True,group='构件分类')
        self['构件名称']=Attr('预制舱对开双层逃生门',obvious=True,readonly=True,group='构件分类')
        self['门扇宽度']=Attr(970.0,obvious=True,group='门体参数')
        self['门洞高度']=Attr(2300.0,obvious=True,group='门体参数')
        self['外板厚']=Attr(2.0,obvious=True,group='板厚参数')
        self['内板厚']=Attr(1.5,obvious=True,group='板厚参数')
        self['X']=Attr(0.0,obvious=True,group='定位')
        self['Y']=Attr(0.0,obvious=True,group='定位')
        self['Z']=Attr(0.0,obvious=True,group='定位')
        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")
        self.replace()

    def _box(self,cx,cy,cz,sx,sy,sz,col):
        return Box(Vec3(cx-sx/2,cy-sy/2,cz-sz/2),Vec3(cx-sx/2,cy-sy/2,cz+sz/2),Vec3(1,0,0),Vec3(0,1,0),sx,sy,sx,sy).color(*col)

    def _hinge(self,x_edge,cz,hinge_w,hinge_h,col_plate,col_barrel,col_pin,is_left):
        b=self._box
        plate_w=hinge_w/2; plate_t=10; plate_h=hinge_h
        barrel_w=24; barrel_t=22; barrel_h=hinge_h+18
        pin_w=8; pin_t=10; pin_h=hinge_h+34
        screw_w=10; screw_t=6; screw_h=10
        screw_dz=hinge_h*0.28
        plate_y=30
        barrel_y=38
        pin_y=43
        half_plate_w=plate_w/2

        if is_left:
            frame_x=x_edge-half_plate_w
            leaf_x=x_edge+half_plate_w
            barrel_x=x_edge-1
        else:
            frame_x=x_edge+half_plate_w
            leaf_x=x_edge-half_plate_w
            barrel_x=x_edge+1

        return combine(
            b(frame_x,plate_y,cz,plate_w,plate_t,plate_h,col_plate),
            b(leaf_x,plate_y,cz,plate_w,plate_t,plate_h,col_plate),
            b(barrel_x,barrel_y,cz,barrel_w,barrel_t,barrel_h,col_barrel),
            b(barrel_x,pin_y,cz,pin_w,pin_t,pin_h,col_pin),
            b(frame_x,pin_y,cz-screw_dz,screw_w,screw_t,screw_h,col_pin),
            b(frame_x,pin_y,cz+screw_dz,screw_w,screw_t,screw_h,col_pin),
            b(leaf_x,pin_y,cz-screw_dz,screw_w,screw_t,screw_h,col_pin),
            b(leaf_x,pin_y,cz+screw_dz,screw_w,screw_t,screw_h,col_pin))

    @export
    def replace(self):
        Dh=self['门洞高度']
        C_F=(0.35,0.40,0.48,1); C_O=(0.50,0.58,0.68,1); C_I=(0.55,0.62,0.72,1)
        C_S=(0.72,0.72,0.72,1); C_D=(0.25,0.28,0.35,1); C_K=(0.10,0.10,0.10,1); C_G=(0.75,0.60,0.28,1)

        hh=Dh/2; zb=-hh; zt=hh; FD=50; BH=120; FS=30; xl=-972; xr=2
        yOb=FD/2-self['外板厚']/2
        yIb=FD/2+self['外板厚']
        zrb=zb+BH+20; zrt=zt-BH-20; ht=zrt-zrb
        sd=FD*0.45

        b=self._box

        # 门框(6)+门板(4) → 10个，分2组
        g1=combine(
            b(-1002+FS/2,FD/2,0,FS,FD,Dh,C_F),
            b(1002-FS/2,FD/2,0,FS,FD,Dh,C_F),
            b(0,FD/2,zb+BH/2,2004,FD,BH,C_F),
            b(0,FD/2,zt-BH/2,2004,FD,BH,C_F),
            b(-1002+FS+2,FD*0.65,0,6,FD*0.4,Dh-BH*2,C_D),
            b(0,-5,zb+BH/2,2004,10,BH+5,C_D))
        g2=combine(
            b(xl+485,yOb,0,970,self['外板厚'],Dh-BH*2,C_O),
            b(xr+485,yOb,0,970,self['外板厚'],Dh-BH*2,C_O),
            b(xl+485+1,yIb,0,968,self['内板厚'],Dh-BH*2-2,C_I),
            b(xr+485+1,yIb,0,968,self['内板厚'],Dh-BH*2-2,C_I))

        # 加强筋2条（靠近中缝左右各一，便于开门操作）
        g3=combine(
            b(xl+810,FD/2+4,0,18,6,ht,C_O),
            b(xr+162,FD/2+4,0,18,6,ht,C_O))

        # 合页横向按门扇宽度的四分之一，竖向按门扇高度的八分之一
        leaf_w=self['门扇宽度']
        leaf_h=Dh-BH*2
        hinge_w=leaf_w/4
        hinge_h=leaf_h/8
        hinge_gap=(leaf_h-hinge_h*3)/4
        hinge_zs=(
            -leaf_h/2+hinge_gap+hinge_h/2,
            0,
            leaf_h/2-hinge_gap-hinge_h/2)
        g5=combine(
            self._hinge(xl,hinge_zs[0],hinge_w,hinge_h,C_S,C_D,C_G,True),
            self._hinge(xl,hinge_zs[1],hinge_w,hinge_h,C_S,C_D,C_G,True),
            self._hinge(xl,hinge_zs[2],hinge_w,hinge_h,C_S,C_D,C_G,True))
        g6=combine(
            self._hinge(xr+970,hinge_zs[0],hinge_w,hinge_h,C_S,C_D,C_G,False),
            self._hinge(xr+970,hinge_zs[1],hinge_w,hinge_h,C_S,C_D,C_G,False),
            self._hinge(xr+970,hinge_zs[2],hinge_w,hinge_h,C_S,C_D,C_G,False))

        # 锁杆(3)+盖板(1)+锁盒(2)+把手(4)+密封条(2)=12个，分2组
        g9=combine(
            b(-4,22,0,4,4,Dh-BH*2-20,C_D),
            b(-4,22,zt-BH-5,6,4,BH+10,C_S),
            b(-4,22,zb+BH-5,6,4,BH+10,C_S),
            b(-6,FD/2+self['外板厚']+self['内板厚']+1,0,8,3,Dh-BH*2-4,C_O),
            b(-35,22,900,38,20,55,C_G),
            b(35,22,900,38,20,55,C_G))
        g10=combine(
            b(-70,24,900,55,4,10,C_S),
            b(70,24,900,55,4,10,C_S),
            b(-99,24,900,8,6,12,C_D),
            b(99,24,900,8,6,12,C_D),
            b(-970,11,0,3,sd,Dh-BH*2,C_K),
            b(970,11,0,3,sd,Dh-BH*2,C_K))

        # 逐级unite合并
        r=g1; r=unite(r,g2); r=unite(r,g3)
        r=unite(r,g5); r=unite(r,g6)
        r=unite(r,g9); r=unite(r,g10)

        self['对开双层逃生门']=translate(self['X'],self['Y'],self['Z'])*r

        # —— 自重：两扇门扇（外板 + 内板）——
        _W = float(self["门扇宽度"]); _H = float(self["门洞高度"])
        _to = float(self["外板厚"]); _ti = float(self["内板厚"])
        self["自重_kg"] = round(2.0 * _W * _H * (_to + _ti) * 7850.0 / 1e9, 2)

if __name__=='__main__':
    FinalGeometry=预制舱对开双层逃生门()
    place(FinalGeometry)
