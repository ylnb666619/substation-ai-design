# -*- coding: utf-8 -*-
from pyp3d import *
import math


class 预制舱轴流风机通风口(Component):
    def __init__(self):
        Component.__init__(self)
        self['预制舱轴流风机通风口'] = Attr(None, show=True)
        self['场布分类'] = Attr('建筑构筑物', obvious=True, readonly=True, group='构件分类')
        self['构件类型'] = Attr('通风设备', obvious=True, readonly=True, group='构件分类')
        self['构件名称'] = Attr('预制舱轴流风机通风口', obvious=True, readonly=True, group='构件分类')
        self["标称重量"] = Attr(15.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")
        self.replace()

    @export
    def replace(self):
        # 全部硬编码，不做参数化
        # 正面通风板
        outer_box = Box(
            Vec3(-200, -200, -10), Vec3(-200, -200, 10),
            Vec3(1, 0, 0), Vec3(0, 1, 0), 400, 400, 400, 400
        )
        inner_box = Box(
            Vec3(-150, -150, -11), Vec3(-150, -150, 11),
            Vec3(1, 0, 0), Vec3(0, 1, 0), 300, 300, 300, 300
        )
        frame = (outer_box - inner_box).color(0.55, 0.55, 0.55, 1)

        # 顶面格栅保持原来的样子
        grille = None
        for idx in range(7):
            center_x = -150 + 300 / 8 * (idx + 1)
            bar = Box(
                Vec3(center_x - 5, -150, 2), Vec3(center_x - 5, 150, 2),
                Vec3(1, 0, 0), Vec3(0, 0, 1), 10, 8, 10, 8
            ).color(0.60, 0.60, 0.60, 1)
            grille = bar if grille is None else unite(grille, bar)

        # 盒体外壳，与正面通风板共同组成 400x400x180 的长方体
        body_front_z = 10
        body_back_z = -170
        body_half = 200
        wall_t = 18
        body_color = (0.49, 0.50, 0.53, 1)

        shell = []
        shell.append(Box(
            Vec3(-body_half, -body_half, body_back_z),
            Vec3(-body_half, -body_half, body_back_z + wall_t),
            Vec3(1, 0, 0), Vec3(0, 1, 0), body_half * 2, body_half * 2, body_half * 2, body_half * 2
        ).color(*body_color))
        shell.append(Box(
            Vec3(-body_half, -body_half, body_back_z + wall_t),
            Vec3(-body_half, -body_half, body_front_z),
            Vec3(1, 0, 0), Vec3(0, 1, 0), wall_t, body_half * 2, wall_t, body_half * 2
        ).color(*body_color))
        shell.append(Box(
            Vec3(body_half - wall_t, -body_half, body_back_z + wall_t),
            Vec3(body_half - wall_t, -body_half, body_front_z),
            Vec3(1, 0, 0), Vec3(0, 1, 0), wall_t, body_half * 2, wall_t, body_half * 2
        ).color(*body_color))
        shell.append(Box(
            Vec3(-body_half + wall_t, body_half - wall_t, body_back_z + wall_t),
            Vec3(-body_half + wall_t, body_half - wall_t, body_front_z),
            Vec3(1, 0, 0), Vec3(0, 1, 0), body_half * 2 - wall_t * 2, wall_t, body_half * 2 - wall_t * 2, wall_t
        ).color(*body_color))
        shell.append(Box(
            Vec3(-body_half + wall_t, -body_half, body_back_z + wall_t),
            Vec3(-body_half + wall_t, -body_half, body_front_z),
            Vec3(1, 0, 0), Vec3(0, 1, 0), body_half * 2 - wall_t * 2, wall_t, body_half * 2 - wall_t * 2, wall_t
        ).color(*body_color))

        # 盒内前口加强圈
        mouth_outer = Box(
            Vec3(-152, -152, -22), Vec3(-152, -152, -8),
            Vec3(1, 0, 0), Vec3(0, 1, 0), 304, 304, 304, 304
        ).color(0.44, 0.45, 0.48, 1)
        mouth_inner = Box(
            Vec3(-126, -126, -23), Vec3(-126, -126, -7),
            Vec3(1, 0, 0), Vec3(0, 1, 0), 252, 252, 252, 252
        )
        mouth_ring = (mouth_outer - mouth_inner).color(0.40, 0.41, 0.44, 1)

        # 风扇外圈，做成更厚的内置风机套筒
        ring_outer = Cone(Vec3(0, 0, -12), Vec3(0, 0, 12), 122, 122)
        ring_inner = Cone(Vec3(0, 0, -13), Vec3(0, 0, 13), 104, 104)
        fan_ring = (ring_outer - ring_inner).color(0.46, 0.47, 0.50, 1)

        # 更有层次的轮毂
        hub_back = Cone(Vec3(0, 0, -18), Vec3(0, 0, -2), 18, 28).color(0.34, 0.36, 0.40, 1)
        hub_main = Cone(Vec3(0, 0, -2), Vec3(0, 0, 14), 28, 28).color(0.38, 0.40, 0.44, 1)
        hub_cap = Cone(Vec3(0, 0, 14), Vec3(0, 0, 23), 22, 12).color(0.43, 0.45, 0.48, 1)

        # 加厚并带一点倾角的叶片
        blade_profile = Section(
            Vec3(28, -8, 0),
            Vec3(48, -13, 0),
            Vec3(72, -15, 0),
            Vec3(92, -13, 0),
            Vec3(104, -7, 0),
            Vec3(102, 7, 0),
            Vec3(88, 13, 0),
            Vec3(68, 15, 0),
            Vec3(46, 13, 0),
            Vec3(28, 8, 0),
        )
        blade = Sweep(blade_profile, Line(Vec3(0, 0, -4), Vec3(0, 0, 4)))
        blade = rotation(Vec3(0, 1, 0), math.radians(-10)) * blade
        blade = blade.color(0.29, 0.56, 0.86, 1)

        fan = unite(fan_ring, hub_back, hub_main, hub_cap)
        blade_count = 6
        for idx in range(blade_count):
            angle = math.radians(idx * 360.0 / blade_count + 8.0)
            fan = unite(fan, rotz(angle) * blade)

        # 风机后置到盒体内部
        fan = translate(0, 0, -92) * fan

        # 电机和支撑，让风扇更像真正装在盒子里的设备
        motor = Cone(Vec3(0, 0, -132), Vec3(0, 0, -104), 22, 16).color(0.35, 0.37, 0.40, 1)
        motor_cap = Cone(Vec3(0, 0, -104), Vec3(0, 0, -96), 16, 12).color(0.40, 0.42, 0.45, 1)
        strut_1 = Box(Vec3(-4, -118, -100), Vec3(-4, -88, -100),
                      Vec3(1, 0, 0), Vec3(0, 0, 1), 8, 12, 8, 12).color(0.45, 0.46, 0.49, 1)
        strut_2 = Box(Vec3(-4, 88, -100), Vec3(-4, 118, -100),
                      Vec3(1, 0, 0), Vec3(0, 0, 1), 8, 12, 8, 12).color(0.45, 0.46, 0.49, 1)
        strut_3 = Box(Vec3(-118, -4, -100), Vec3(-88, -4, -100),
                      Vec3(0, 1, 0), Vec3(0, 0, 1), 12, 8, 12, 8).color(0.45, 0.46, 0.49, 1)
        strut_4 = Box(Vec3(88, -4, -100), Vec3(118, -4, -100),
                      Vec3(0, 1, 0), Vec3(0, 0, 1), 12, 8, 12, 8).color(0.45, 0.46, 0.49, 1)

        self['预制舱轴流风机通风口'] = unite(
            frame, grille,
            *shell, mouth_ring,
            fan, motor, motor_cap,
            strut_1, strut_2, strut_3, strut_4
        )


if __name__ == "__main__":
    FinalGeometry = 预制舱轴流风机通风口()
    place(FinalGeometry)
