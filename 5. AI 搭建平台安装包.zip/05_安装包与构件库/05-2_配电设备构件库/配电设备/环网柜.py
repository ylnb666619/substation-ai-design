# -*- coding: utf-8 -*-
from pyp3d import *


class 环网柜(Component):
    """HXGN 系列环网柜。"""

    def __init__(self):
        Component.__init__(self)
        self["环网柜"] = Attr(None, show=True)

        self["空间分类"] = Attr("建筑构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("变电设备", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("环网柜", obvious=True, readonly=True, group="构件分类")

        self["柜宽"] = Attr(500.0, obvious=True, group="柜体尺寸", description="柜体宽度 X(mm)")
        self["柜深"] = Attr(900.0, obvious=True, group="柜体尺寸", description="柜体深度 Y(mm)")
        self["柜高"] = Attr(1800.0, obvious=True, group="柜体尺寸", description="柜体总高 Z(mm)")

        self["前面板外挑"] = Attr(15.0, obvious=True, group="细化参数", description="前部功能面板向外突出距离(mm)")

        self["柜名"] = Attr("环网柜", obvious=True, group="标识", description="显示在正面的柜体名称")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["柜色"] = Attr("", obvious=True, material=True, group="自定义材质")

        self["标称重量"] = Attr(400.0, obvious=True, group="力学信息", description="设备标称重量(kg)：参与恒载与设备荷载统计，请按产品样本填写")

        self.replace()

    def _box(self, x, y, z, sx, sy, sz):
        return translate(x, y, z) * scale(sx, sy, sz) * Cube()

    def _finish(self, geom, color_value=None, material_name=""):
        if material_name:
            return geom.material(material_name)
        if color_value is not None:
            return geom.color(*color_value)
        return geom

    @export
    def replace(self):
        W = max(float(self["柜宽"]), 300.0)
        D = max(float(self["柜深"]), 300.0)
        H = max(float(self["柜高"]), 1000.0)
        front_out = max(min(float(self["前面板外挑"]), max(D * 0.16, 8.0)), 8.0)
        cabinet_name = str(self["柜名"])
        cabinet_material = self["柜色"]

        self["柜宽"] = W
        self["柜深"] = D
        self["柜高"] = H
        self["前面板外挑"] = front_out

        base_h = max(H * 0.045, 68.0)
        cap_h = max(H * 0.020, 30.0)
        top_header_bottom = H * 0.76
        operation_bottom = H * 0.24
        fuse_bottom = H * 0.11
        frame_w = max(W * 0.036, 18.0)
        panel_depth = front_out + 8.0
        trim_depth = max(front_out * 0.60, 8.0)
        plinth_out = max(front_out * 1.25, 18.0)

        c_body = (0.49, 0.55, 0.63, 1.0)
        c_light = (0.66, 0.71, 0.78, 1.0)
        c_dark = (0.25, 0.30, 0.37, 1.0)
        c_accent = (0.77, 0.81, 0.87, 1.0)
        c_handle = (0.79, 0.62, 0.31, 1.0)
        c_glass = (0.48, 0.86, 0.96, 0.28)
        c_text = (0.92, 0.12, 0.10, 1.0)

        parts = []

        def append_box(x, y, z, sx, sy, sz, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            material_name = cabinet_material if use_cabinet_material else ""
            parts.append(self._finish(self._box(x, y, z, sx, sy, sz), color_value, material_name))

        def append_frame(x, y, z, sx, sy, sz, border, color_value=None, use_cabinet_material=False):
            if sx <= 0 or sy <= 0 or sz <= 0:
                return
            if sx <= border * 2 or sz <= border * 2:
                append_box(x, y, z, sx, sy, sz, color_value, use_cabinet_material)
                return
            append_box(x, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + sx - border, y, z, border, sy, sz, color_value, use_cabinet_material)
            append_box(x + border, y, z, sx - border * 2, sy, border, color_value, use_cabinet_material)
            append_box(x + border, y, z + sz - border, sx - border * 2, sy, border, color_value, use_cabinet_material)

        append_box(0, 0, 0, W, D, H, c_body, use_cabinet_material=True)
        append_box(-W * 0.022, -plinth_out, 0, W * 1.044, max(D * 0.10, 60.0) + plinth_out, base_h, c_dark, use_cabinet_material=True)
        append_box(-W * 0.012, -front_out * 0.85, H - cap_h, W * 1.024, max(D * 0.08, 40.0) + front_out * 0.85, cap_h, c_light, use_cabinet_material=True)
        append_frame(frame_w * 0.55, -trim_depth, base_h, W - frame_w * 1.10, trim_depth + 2.0, H - base_h - cap_h * 0.35, frame_w * 0.55, c_dark)
        append_box(0, -4.0, top_header_bottom, W, 4.0, 5.0, c_dark)
        append_box(0, -4.0, operation_bottom, W, 4.0, 5.0, c_dark)
        append_box(0, -4.0, fuse_bottom, W, 4.0, 5.0, c_dark)

        header_w = W * 0.76
        header_h = max(H * 0.10, 150.0)
        header_x = (W - header_w) * 0.5
        header_z = top_header_bottom + (H - top_header_bottom - header_h) * 0.42
        append_box(header_x, -panel_depth, header_z, header_w, panel_depth + 5.0, header_h, c_light, use_cabinet_material=True)
        append_box(header_x + header_w * 0.16, -panel_depth - 5.0, header_z + header_h * 0.28, header_w * 0.30, 5.0, max(header_h * 0.10, 16.0), c_dark)
        append_box(header_x + header_w * 0.72, -panel_depth - 7.0, header_z + header_h * 0.24, max(W * 0.036, 16.0), 7.0, header_h * 0.40, c_handle)

        upper_w = W * 0.82
        upper_x = (W - upper_w) * 0.5
        upper_z = operation_bottom + H * 0.02
        upper_h = top_header_bottom - upper_z - H * 0.03
        append_box(upper_x, -panel_depth - 1.0, upper_z, upper_w, panel_depth + 8.0, upper_h, c_body, use_cabinet_material=True)
        append_frame(
            upper_x + upper_w * 0.07,
            -panel_depth - 4.0,
            upper_z + upper_h * 0.08,
            upper_w * 0.86,
            panel_depth + 11.0,
            upper_h * 0.84,
            max(upper_w * 0.028, 10.0),
            c_accent,
        )

        slot_w = upper_w * 0.28
        slot_h = max(upper_h * 0.10, 18.0)
        slot_x = upper_x + upper_w * 0.14
        slot_z = upper_z + upper_h * 0.58
        append_box(slot_x, -panel_depth - 6.0, slot_z, slot_w, panel_depth + 12.0, slot_h, c_dark)

        window_w = upper_w * 0.26
        window_h = upper_h * 0.20
        window_x = upper_x + upper_w * 0.18
        window_z = upper_z + upper_h * 0.20
        border = min(max(window_w * 0.10, 10.0), window_h * 0.30)
        append_frame(window_x, -panel_depth - 7.0, window_z, window_w, panel_depth + 13.0, window_h, border, c_dark)
        append_box(window_x + border * 0.60, -panel_depth - 9.0, window_z + border * 0.50, window_w - border * 1.20, 6.0, window_h - border * 1.00, c_glass)

        dial_size = max(W * 0.10, 22.0)
        dial_x = upper_x + upper_w * 0.72
        dial_z = upper_z + upper_h * 0.58
        append_box(dial_x, -panel_depth - 6.0, dial_z, dial_size, panel_depth + 12.0, dial_size, c_dark)
        append_box(dial_x - dial_size * 0.18, -panel_depth - 9.0, dial_z - dial_size * 0.18, dial_size * 1.36, 4.0, dial_size * 1.36, c_accent)

        append_box(upper_x + upper_w * 0.72, -panel_depth - 8.0, upper_z + upper_h * 0.18, max(W * 0.036, 16.0), panel_depth + 14.0, upper_h * 0.34, c_handle)
        append_box(upper_x + upper_w * 0.10, -panel_depth - 5.0, upper_z + upper_h * 0.82, upper_w * 0.26, 5.0, max(upper_h * 0.07, 12.0), c_dark)

        hinge_w = max(W * 0.026, 12.0)
        hinge_h = max(upper_h * 0.10, 24.0)
        for ratio in (0.16, 0.50, 0.84):
            hz = upper_z + upper_h * ratio - hinge_h * 0.5
            append_box(upper_x + 6.0, -panel_depth - 5.0, hz, hinge_w, panel_depth + 11.0, hinge_h, c_dark)

        mid_w = W * 0.74
        mid_x = (W - mid_w) * 0.5
        mid_z = fuse_bottom + H * 0.01
        mid_h = operation_bottom - mid_z - H * 0.02
        append_box(mid_x, -panel_depth, mid_z, mid_w, panel_depth + 7.0, mid_h, c_light, use_cabinet_material=True)
        append_frame(
            mid_x + mid_w * 0.08,
            -panel_depth - 3.0,
            mid_z + mid_h * 0.12,
            mid_w * 0.84,
            panel_depth + 10.0,
            mid_h * 0.76,
            max(mid_w * 0.028, 10.0),
            c_accent,
        )
        append_box(mid_x + mid_w * 0.22, -panel_depth - 7.0, mid_z + mid_h * 0.34, mid_w * 0.44, panel_depth + 13.0, max(mid_h * 0.16, 16.0), c_handle)
        append_box(mid_x + mid_w * 0.18, -panel_depth - 5.0, mid_z + mid_h * 0.72, mid_w * 0.24, 5.0, max(mid_h * 0.10, 12.0), c_dark)

        low_w = W * 0.82
        low_x = (W - low_w) * 0.5
        low_z = H * 0.03
        low_h = max(fuse_bottom - low_z - H * 0.02, 90.0)
        append_box(low_x, -panel_depth, low_z, low_w, panel_depth + 7.0, low_h, c_light, use_cabinet_material=True)
        append_frame(
            low_x + low_w * 0.06,
            -panel_depth - 3.0,
            low_z + low_h * 0.10,
            low_w * 0.88,
            panel_depth + 10.0,
            low_h * 0.80,
            max(low_w * 0.026, 10.0),
            c_accent,
        )
        louver_h = max(low_h * 0.10, 10.0)
        for i in range(3):
            append_box(low_x + low_w * 0.16, -panel_depth - 6.0, low_z + low_h * 0.20 + i * louver_h * 1.45, low_w * 0.38, 6.0, louver_h, c_dark)
        ground_size = max(W * 0.10, 22.0)
        append_box(low_x + low_w * 0.66, -panel_depth - 6.0, low_z + low_h * 0.24, ground_size, panel_depth + 12.0, ground_size, c_dark)
        append_box(low_x + low_w * 0.80, -panel_depth - 7.0, low_z + low_h * 0.22, max(W * 0.032, 16.0), panel_depth + 13.0, low_h * 0.42, c_handle)

        char_w = W * 0.12
        char_h = H * 0.070
        ascii_n = sum(1 for c in cabinet_name if ord(c) < 128)
        cjk_n = len(cabinet_name) - ascii_n
        unit_count = max(ascii_n + cjk_n * 2.2, 1.0)
        text_len = unit_count * char_w
        max_text_len = W * 0.78
        if text_len > max_text_len:
            scale_ratio = max_text_len / text_len
            char_w *= scale_ratio
            char_h *= scale_ratio
            text_len = max_text_len
        name_band_h = max(H * 0.050, 20.0)
        name_band_z = H - cap_h - name_band_h * 1.22
        append_box(W * 0.12, -panel_depth - 10.0, name_band_z, W * 0.76, 6.0, name_band_h, c_light)
        text_z = name_band_z + name_band_h * 0.16
        text_sec = (
            translate((W - text_len) * 0.5, -panel_depth - 14.0, text_z)
            * rotation(Vec3(1, 0, 0), pi * 0.5)
            * Text(cabinet_name, char_w, char_h)
        )
        parts.append(Sweep(text_sec, Line(Vec3(0, 0, 0), Vec3(0, -10, 0))).color(*c_text))

        self["环网柜"] = translate(self["X"], self["Y"], self["Z"]) * combine(*parts)


if __name__ == "__main__":
    FinalGeometry = 环网柜()
    place(FinalGeometry)
