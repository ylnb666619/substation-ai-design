# -*- coding: utf-8 -*-
"""
槽钢底座（按示意图）

构造特征：
1. 四道通长横向槽钢：底边、下部分隔梁、上部分隔梁、顶边，总长随单体数量自动变化。
2. 通高竖向槽钢沿 X 方向按单体数量均分，左右最外侧槽钢朝内扣。
3. Y 方向按非设备区、桥架、设备区三段宽度控制，总宽自动计算。
4. 下部每跨再细分：默认每跨分成 2 格，对应图中下排更密的立档。
5. 中间排位置的通高竖向槽钢腹板开 2 个圆孔，用于穿线，对应补充的侧视图。
6. 力学信息：每根槽钢按简支均布、弯曲强度控制估算承重量 P = 8·f·Wx/(g·L)，
   承重量按编号分到每一根槽钢；总承重 = 槽钢型号各杆承重合计 + 外层槽钢型号各杆承重合计。

坐标约定：
- 原点在左下角
- X 向右
- Y 向上
- Z 为槽钢厚度方向
"""

import json

from pyp3d import *


槽钢规格表 = {
    "5#": (50, 37, 4.5, 7.0),
    "6.3#": (63, 40, 4.8, 7.5),
    "8#": (80, 43, 5.0, 8.0),
    "10#": (100, 48, 5.3, 8.5),
    "12#": (120, 53, 5.5, 9.0),
    "14#": (140, 60, 6.0, 9.5),
    "16#": (160, 65, 8.5, 10.0),
    "18#": (180, 70, 9.0, 10.5),
    "20#": (200, 75, 9.0, 11.0),
    "22#": (220, 80, 9.5, 11.5),
    "25#": (250, 82, 11.0, 12.0),
    "28#": (280, 82, 7.5, 12.5),
    "32#": (320, 88, 8.0, 14.0),
    "36#": (360, 96, 9.0, 16.0),
    "40#": (400, 100, 10.5, 18.0),
}

钢材密度_KG_PER_M3 = 7850.0
钢材密度_KG_PER_MM3 = 钢材密度_KG_PER_M3 * 1.0e-9

钢材抗弯强度表_MPA = {
    "Q235B": 215.0,
    "Q355B": 305.0,
}
重力加速度_M_S2 = 9.8


def 点字符串(x, y, z):
    return "({0:.1f}, {1:.1f}, {2:.1f})".format(float(x), float(y), float(z))


def 槽钢截面面积平方毫米(型号):
    """按当前建模截面计算理论截面面积(mm2)。"""
    h, b, d, t = 槽钢规格表[型号]
    有效腹板厚 = max(min(float(d), float(b)), 0.0)
    有效翼缘厚 = max(min(float(t), float(h) * 0.5), 0.0)
    开口净宽 = max(float(b) - 有效腹板厚, 0.0)
    开口净高 = max(float(h) - 有效翼缘厚 * 2.0, 0.0)
    return float(b) * float(h) - 开口净宽 * 开口净高


def 槽钢理论线密度千克每米(型号):
    """按钢材密度 7850kg/m3 计算理论线密度(kg/m)。"""
    return 槽钢截面面积平方毫米(型号) * 0.00785


def 槽钢理论重量千克(型号, 长度毫米):
    """按钢材密度 7850kg/m3 计算理论重量(kg)。"""
    return 槽钢截面面积平方毫米(型号) * max(float(长度毫米), 0.0) * 钢材密度_KG_PER_MM3


def 槽钢截面抵抗矩立方毫米(型号):
    """按当前建模截面计算绕强轴(平行翼缘)的截面抵抗矩 Wx(mm3)。"""
    h, b, d, t = 槽钢规格表[型号]
    有效腹板厚 = max(min(float(d), float(b)), 0.0)
    有效翼缘厚 = max(min(float(t), float(h) * 0.5), 0.0)
    开口净宽 = max(float(b) - 有效腹板厚, 0.0)
    开口净高 = max(float(h) - 有效翼缘厚 * 2.0, 0.0)
    惯性矩 = (float(b) * float(h) ** 3 - 开口净宽 * 开口净高 ** 3) / 12.0
    return 惯性矩 / (float(h) * 0.5)


def 钢材抗弯强度兆帕(牌号):
    """钢材抗弯强度设计值(N/mm2)：Q235B=215，Q355B=305，未知牌号按 Q235B。"""
    return 钢材抗弯强度表_MPA.get(str(牌号), 钢材抗弯强度表_MPA["Q235B"])


def 槽钢容许弯矩千牛米(型号, 牌号):
    """弯曲容许弯矩 Mu = f·Wx (kN·m)。"""
    return 钢材抗弯强度兆帕(牌号) * 槽钢截面抵抗矩立方毫米(型号) * 1.0e-6


def 槽钢均布承重千克(型号, 牌号, 长度毫米):
    """简支均布承载估算：满跨总承重 P = 8·f·Wx / (g·L) (kg)。

    按简支梁均布荷载、弯曲强度控制：q·L^2/8 ≤ f·Wx，
    满跨总承重 P = q·L = 8·f·Wx / L，再除以 g=9.8 换算为 kg。
    """
    L = max(float(长度毫米), 1.0)
    return 8.0 * 钢材抗弯强度兆帕(牌号) * 槽钢截面抵抗矩立方毫米(型号) / (重力加速度_M_S2 * L)


def 线段长度毫米(起点, 终点):
    dx = float(终点[0]) - float(起点[0])
    dy = float(终点[1]) - float(起点[1])
    dz = float(终点[2]) - float(起点[2])
    return (dx * dx + dy * dy + dz * dz) ** 0.5


def 槽钢记录字典(
    构件编号,
    构件名称,
    构件类别,
    型号,
    开口方向,
    起点,
    终点,
    几何体,
    是否开孔=False,
    孔数=0,
    孔径=0.0,
    孔间距=0.0,
    孔组中心Y=None,
    钢材牌号="Q235B",
):
    """为单根槽钢生成可追踪的力学计算元数据（含自重与承重量）。"""
    长度毫米 = 线段长度毫米(起点, 终点)
    截面面积 = 槽钢截面面积平方毫米(型号)
    理论重量 = 槽钢理论重量千克(型号, 长度毫米)
    容许弯矩 = 槽钢容许弯矩千牛米(型号, 钢材牌号)
    承重量 = 槽钢均布承重千克(型号, 钢材牌号, 长度毫米)
    return {
        "id": str(构件编号),
        "name": str(构件名称),
        "category": str(构件类别),
        "profile": str(型号),
        "section_area_mm2": round(截面面积, 3),
        "unit_weight_kg_per_m": round(槽钢理论线密度千克每米(型号), 6),
        "length_mm": round(长度毫米, 3),
        "weight_kg": round(理论重量, 6),
        "steel_grade": str(钢材牌号),
        "allowable_moment_kNm": round(容许弯矩, 3),
        "capacity_kg": round(承重量, 3),
        "opening_direction": str(开口方向),
        "start_point": [round(float(v), 3) for v in 起点],
        "end_point": [round(float(v), 3) for v in 终点],
        "start_point_text": 点字符串(*起点),
        "end_point_text": 点字符串(*终点),
        "has_holes": bool(是否开孔),
        "hole_count": int(孔数),
        "hole_diameter_mm": round(float(孔径), 3),
        "hole_spacing_mm": round(float(孔间距), 3),
        "hole_group_center_y_mm": None if 孔组中心Y is None else round(float(孔组中心Y), 3),
        "geometry": 几何体,
    }


def 槽钢截面(型号):
    """生成真实 C 形槽钢截面，截面形心居中，开口朝 +X。"""
    h, b, d, t = 槽钢规格表[型号]
    半高 = h * 0.5
    半宽 = b * 0.5
    return Section(
        Vec2(-半宽, -半高),
        Vec2(半宽, -半高),
        Vec2(半宽, -半高 + t),
        Vec2(-半宽 + d, -半高 + t),
        Vec2(-半宽 + d, 半高 - t),
        Vec2(半宽, 半高 - t),
        Vec2(半宽, 半高),
        Vec2(-半宽, 半高),
    )


def 水平槽钢_开向上(型号, x1, x2, y, z, 材质=None):
    """沿 X 方向布置，槽口朝 +Y。"""
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(0, 1, 0), pi / 2) * 构件
    构件 = rotation(Vec3(1, 0, 0), pi / 2) * 构件
    构件 = translate(x1, y, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 水平槽钢_开向下(型号, x1, x2, y, z, 材质=None):
    """沿 X 方向布置，槽口朝 -Y。"""
    长度 = abs(x2 - x1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(0, 1, 0), pi / 2) * 构件
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = translate(x1, y, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 竖向槽钢_开向右(型号, x, y1, y2, z, 材质=None):
    """沿 Y 方向布置，槽口朝 +X。"""
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = translate(x, y1, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 竖向槽钢_开向左(型号, x, y1, y2, z, 材质=None):
    """沿 Y 方向布置，槽口朝 -X。"""
    长度 = abs(y2 - y1)
    if 长度 < 1:
        return None
    路径 = Line(Vec3(0, 0, 0), Vec3(0, 0, 长度))
    构件 = Sweep(槽钢截面(型号), 路径)
    构件 = rotation(Vec3(1, 0, 0), -pi / 2) * 构件
    构件 = rotation(Vec3(0, 1, 0), pi) * 构件
    构件 = translate(x, y1, z) * 构件
    if 材质:
        构件 = 构件.material(材质)
    return 构件


def 差集(a, b):
    """兼容不同运行环境的布尔差集。"""
    try:
        return Cut(a, b)
    except Exception:
        if "substract" in globals():
            return substract(a, b)
        return a


def 双孔竖向槽钢(
    型号,
    x,
    y1,
    y2,
    z,
    开向右=True,
    孔径=60.0,
    孔间距=120.0,
    孔组偏移=0.0,
    孔组中心Y=None,
    材质=None,
):
    """沿 Y 方向的槽钢，在腹板指定高度开两个穿线圆孔。"""
    if 开向右:
        构件 = 竖向槽钢_开向右(型号, x, y1, y2, z, 材质)
    else:
        构件 = 竖向槽钢_开向左(型号, x, y1, y2, z, 材质)
    if 构件 is None:
        return None

    h, b, d, t = 槽钢规格表[型号]
    孔半径 = max(float(孔径) * 0.5, 0.1)
    孔距 = max(float(孔间距), 孔半径 * 2.5)
    if 孔组中心Y is None:
        孔组中心Y = (y1 + y2) * 0.5
    孔组中心Y = float(孔组中心Y) + float(孔组偏移)
    腹板中心X = x - b * 0.5 + d * 0.5 if 开向右 else x + b * 0.5 - d * 0.5
    切割超长 = max(b, d) + 20.0

    for 孔中心Y in (孔组中心Y - 孔距 * 0.5, 孔组中心Y + 孔距 * 0.5):
        切割体 = Cone(
            Vec3(腹板中心X - 切割超长, 孔中心Y, z),
            Vec3(腹板中心X + 切割超长, 孔中心Y, z),
            孔半径,
            孔半径,
        )
        构件 = 差集(构件, 切割体)
    return 构件


class 槽钢底座(Component):
    def __init__(self):
        Component.__init__(self)
        self["输出模型"] = Attr(None, show=True)

        型号列表 = ["5#", "6.3#", "8#", "10#", "12#", "14#", "16#", "18#", "20#", "22#", "25#", "28#", "32#", "36#", "40#"]
        self["槽钢型号"] = Attr(
            "20#",
            obvious=True,
            combo=型号列表,
            group="型材",
            description="GB/T 706 标准槽钢型号(5#~40#)",
        )
        self["外层槽钢型号"] = Attr(
            "22#",
            obvious=True,
            combo=型号列表,
            group="型材",
            description="最外层边框使用的槽钢型号",
        )
        self["梁格明细JSON"] = Attr(
            "",
            obvious=False,
            group="梁格方案",
            description="AI装配计划传入的整舱梁格明细；为空时使用原有三段式底座逻辑",
        )

        self["最小单体长度X"] = Attr(1000.0, obvious=True, group="尺寸", description="单个最小单体长度(mm)")
        self["总长X"] = Attr(4000.0, obvious=True, readonly=True, group="尺寸", description="底座总长(mm)，由最小单体长度和单体数量自动计算")
        self["设备区宽度Y"] = Attr(1050.0, obvious=True, group="尺寸", description="设备区宽度(mm)")
        self["桥架宽度Y"] = Attr(500.0, obvious=True, group="尺寸", description="桥架宽度(mm)")
        self["非设备区宽度Y"] = Attr(950.0, obvious=True, group="尺寸", description="非设备区宽度(mm)")
        self["总宽Y"] = Attr(2500.0, obvious=True, readonly=True, group="尺寸", description="底座总宽(mm)，由设备区、桥架、非设备区宽度自动计算")

        self["单体数量"] = Attr(4, obvious=True, group="分格", description="沿 X 方向并列的最小单体数量，总长会随之自动变化")
        self["下部每跨分格"] = Attr(2, obvious=True, group="分格", description="每个单体在下排的细分格数")
        self["端部伸量"] = Attr(50.0, obvious=True, group="构造", description="杆件两端外伸长度(mm)")
        self["开孔范围"] = Attr(
            "仅通高竖向槽钢",
            obvious=True,
            combo=["全部竖向槽钢", "仅通高竖向槽钢", "仅下部附加槽钢"],
            group="开孔",
            description="选择需要开穿线孔的竖向槽钢范围",
        )
        self["中间孔径"] = Attr(60.0, obvious=True, group="开孔", description="中间双孔孔径(mm)")
        self["中间孔间距"] = Attr(120.0, obvious=True, group="开孔", description="中间双孔中心距(mm)")
        self["中间孔组偏移"] = Attr(0.0, obvious=True, group="开孔", description="孔组相对中点的偏移(mm)")

        self["钢材型号"] = Attr("Q235B", obvious=True, combo=["Q235B", "Q355B"], group="材质", description="结构钢材牌号（供承重验算读取）")
        self["材质颜色"] = Attr("", obvious=True, material=True, group="材质")

        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["槽钢总数"] = Attr(0, obvious=True, readonly=True, group="力学信息", description="当前底座包含的槽钢根数")
        self["理论总重量kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="按钢材密度7850kg/m3估算的理论总重量")
        self["内层槽钢承重合计kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="槽钢型号(内层)各杆简支均布承重合计")
        self["外层槽钢承重合计kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="外层槽钢型号各杆简支均布承重合计")
        self["总承重kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="总承重 = 槽钢型号承重合计 + 外层槽钢型号承重合计")
        self["槽钢ID汇总"] = Attr("", obvious=True, readonly=True, group="力学信息", description="当前所有槽钢的唯一编号汇总")
        self["槽钢明细JSON"] = Attr("", obvious=False, readonly=True, group="力学信息", description="每根槽钢的编号、型号、长度、理论重量、容许弯矩、承重量、开孔与坐标信息")
        self["槽钢明细属性容量"] = Attr(0, obvious=False, readonly=True, group="力学信息")

        self.replace()

    @export
    def replace(self):
        try:
            self._build()
        except Exception:
            self["输出模型"] = translate(0, 0, 0) * scale(100, 100, 100) * Cube()

    def _build(self):
        梁格明细 = str(self["梁格明细JSON"] or "").strip()
        if 梁格明细:
            self._build_from_layout(json.loads(梁格明细))
            return
        self._build_default()

    def _build_from_layout(self, 梁格):
        if not isinstance(梁格, dict):
            raise ValueError("梁格明细必须是JSON对象")

        总长 = max(float(梁格.get("length_mm") or 100.0), 100.0)
        总宽 = max(float(梁格.get("width_mm") or 100.0), 100.0)
        外层型号 = str(梁格.get("outer_profile") or self["外层槽钢型号"] or "20#")
        内层型号 = str(梁格.get("inner_profile") or self["槽钢型号"] or "12#")
        牌号 = self["钢材型号"]
        材质 = self["材质颜色"]

        self["总长X"] = 总长
        self["总宽Y"] = 总宽
        self["外层槽钢型号"] = 外层型号
        self["槽钢型号"] = 内层型号

        构件记录 = []
        for 序号, 项 in enumerate(梁格.get("members") or [], start=1):
            if not isinstance(项, dict):
                continue
            方向 = str(项.get("direction") or "").strip().lower()
            角色 = str(项.get("role") or "inner").strip().lower()
            当前型号 = 外层型号 if 角色 == "outer" else 内层型号
            z = float(项.get("z_mm") or 0.0)
            开口 = str(项.get("opening") or "").strip().lower()
            名称 = str(项.get("name") or ("梁格构件%02d" % 序号))

            if 方向 == "horizontal":
                x0 = float(项.get("x0_mm") or 0.0)
                x1 = float(项.get("x1_mm") or 0.0)
                y = float(项.get("y_mm") or 0.0)
                if x1 < x0:
                    x0, x1 = x1, x0
                if 开口 == "down":
                    构件 = 水平槽钢_开向下(当前型号, x0, x1, y, z, 材质)
                    开口方向 = "向下"
                else:
                    构件 = 水平槽钢_开向上(当前型号, x0, x1, y, z, 材质)
                    开口方向 = "向上"
                if 构件:
                    构件记录.append(
                        槽钢记录字典(
                            构件编号="CG-{0:02d}".format(序号),
                            构件名称=名称,
                            构件类别="横向槽钢",
                            型号=当前型号,
                            开口方向=开口方向,
                            起点=(x0, y, z),
                            终点=(x1, y, z),
                            几何体=构件,
                            钢材牌号=牌号,
                        )
                    )
                continue

            if 方向 == "vertical":
                x = float(项.get("x_mm") or 0.0)
                y0 = float(项.get("y0_mm") or 0.0)
                y1 = float(项.get("y1_mm") or 0.0)
                if y1 < y0:
                    y0, y1 = y1, y0
                if 开口 == "left":
                    构件 = 竖向槽钢_开向左(当前型号, x, y0, y1, z, 材质)
                    开口方向 = "向左"
                else:
                    构件 = 竖向槽钢_开向右(当前型号, x, y0, y1, z, 材质)
                    开口方向 = "向右"
                if 构件:
                    构件记录.append(
                        槽钢记录字典(
                            构件编号="CG-{0:02d}".format(序号),
                            构件名称=名称,
                            构件类别="竖向槽钢",
                            型号=当前型号,
                            开口方向=开口方向,
                            起点=(x, y0, z),
                            终点=(x, y1, z),
                            几何体=构件,
                            钢材牌号=牌号,
                        )
                    )

        if not 构件记录:
            self._写入槽钢属性([], 内层型号, 外层型号)
            self["输出模型"] = translate(0, 0, 0) * scale(100, 100, 100) * Cube()
            return

        self._写入槽钢属性(构件记录, 内层型号, 外层型号)
        部件 = [记录["geometry"] for 记录 in 构件记录]
        结果 = 部件[0] if len(部件) == 1 else combine(*部件)
        self["输出模型"] = translate(self["X"], self["Y"], self["Z"]) * 结果

    def _build_default(self):
        型号 = self["槽钢型号"]
        外层型号 = self["外层槽钢型号"]
        牌号 = self["钢材型号"]
        单体长度 = max(float(self["最小单体长度X"]), 100.0)
        设备区宽度 = max(float(self["设备区宽度Y"]), 50.0)
        桥架宽度 = max(float(self["桥架宽度Y"]), 50.0)
        非设备区宽度 = max(float(self["非设备区宽度Y"]), 50.0)
        总宽 = 设备区宽度 + 桥架宽度 + 非设备区宽度
        单体数量 = max(int(self["单体数量"]), 1)
        总长 = 单体长度 * 单体数量
        下部分格 = max(int(self["下部每跨分格"]), 1)
        伸量 = max(float(self["端部伸量"]), 0.0)
        开孔范围 = self["开孔范围"]
        中间孔径 = max(float(self["中间孔径"]), 0.0)
        中间孔间距 = max(float(self["中间孔间距"]), 0.0)
        中间孔组偏移 = float(self["中间孔组偏移"])
        材质 = self["材质颜色"]

        下梁Y = 非设备区宽度
        上梁Y = 非设备区宽度 + 桥架宽度

        self["最小单体长度X"] = 单体长度
        self["设备区宽度Y"] = 设备区宽度
        self["桥架宽度Y"] = 桥架宽度
        self["非设备区宽度Y"] = 非设备区宽度
        self["总长X"] = 总长
        self["总宽Y"] = 总宽

        通高节点 = [单体长度 * i for i in range(单体数量 + 1)]
        下部附加节点 = []
        穿线排中心Y = (下梁Y + 上梁Y) * 0.5
        if 下部分格 > 1:
            for i in range(单体数量):
                起点 = 通高节点[i]
                for j in range(1, 下部分格):
                    下部附加节点.append(起点 + 单体长度 * j / 下部分格)

        构件记录 = []

        横梁参数 = [
            ("CG-H-01", "底边横梁", 0.0, 水平槽钢_开向上, 外层型号, "向上"),
            ("CG-H-02", "下部分隔横梁", 下梁Y, 水平槽钢_开向下, 型号, "向下"),
            ("CG-H-03", "上部分隔横梁", 上梁Y, 水平槽钢_开向上, 型号, "向上"),
            ("CG-H-04", "顶边横梁", 总宽, 水平槽钢_开向下, 外层型号, "向下"),
        ]
        for 构件编号, 构件名称, y, 工厂, 当前型号, 开口方向 in 横梁参数:
            构件 = 工厂(当前型号, -伸量, 总长 + 伸量, y, 0.0, 材质)
            if 构件:
                构件记录.append(
                    槽钢记录字典(
                        构件编号=构件编号,
                        构件名称=构件名称,
                        构件类别="横向槽钢",
                        型号=当前型号,
                        开口方向=开口方向,
                        起点=(-伸量, y, 0.0),
                        终点=(总长 + 伸量, y, 0.0),
                        几何体=构件,
                        钢材牌号=牌号,
                    )
                )

        通高竖向总数 = len(通高节点)
        for i, x in enumerate(通高节点):
            if i == 0:
                开向右 = True
            elif i == 通高竖向总数 - 1:
                开向右 = False
            else:
                开向右 = (i % 2 == 0)
            当前型号 = 外层型号 if i in (0, 通高竖向总数 - 1) else 型号
            是否开孔 = 开孔范围 in ("全部竖向槽钢", "仅通高竖向槽钢") and 中间孔径 > 0
            if 开孔范围 in ("全部竖向槽钢", "仅通高竖向槽钢") and 中间孔径 > 0:
                构件 = 双孔竖向槽钢(
                    当前型号,
                    x,
                    -伸量,
                    总宽 + 伸量,
                    0.0,
                    开向右=开向右,
                    孔径=中间孔径,
                    孔间距=中间孔间距,
                    孔组偏移=中间孔组偏移,
                    孔组中心Y=穿线排中心Y,
                    材质=材质,
                )
            else:
                if 开向右:
                    构件 = 竖向槽钢_开向右(当前型号, x, -伸量, 总宽 + 伸量, 0.0, 材质)
                else:
                    构件 = 竖向槽钢_开向左(当前型号, x, -伸量, 总宽 + 伸量, 0.0, 材质)
            if 构件:
                构件记录.append(
                    槽钢记录字典(
                        构件编号="CG-V-{0:02d}".format(i + 1),
                        构件名称="通高竖向槽钢{0:02d}".format(i + 1),
                        构件类别="通高竖向槽钢",
                        型号=当前型号,
                        开口方向="向右" if 开向右 else "向左",
                        起点=(x, -伸量, 0.0),
                        终点=(x, 总宽 + 伸量, 0.0),
                        几何体=构件,
                        是否开孔=是否开孔,
                        孔数=2 if 是否开孔 else 0,
                        孔径=中间孔径 if 是否开孔 else 0.0,
                        孔间距=中间孔间距 if 是否开孔 else 0.0,
                        孔组中心Y=穿线排中心Y + 中间孔组偏移 if 是否开孔 else None,
                        钢材牌号=牌号,
                    )
                )

        for i, x in enumerate(下部附加节点):
            开向右 = (i % 2 == 1)
            是否开孔 = 开孔范围 in ("全部竖向槽钢", "仅下部附加槽钢") and 中间孔径 > 0
            if 开孔范围 in ("全部竖向槽钢", "仅下部附加槽钢") and 中间孔径 > 0:
                构件 = 双孔竖向槽钢(
                    型号,
                    x,
                    -伸量,
                    下梁Y + 伸量,
                    0.0,
                    开向右=开向右,
                    孔径=中间孔径,
                    孔间距=中间孔间距,
                    孔组偏移=中间孔组偏移,
                    孔组中心Y=穿线排中心Y,
                    材质=材质,
                )
            else:
                if 开向右:
                    构件 = 竖向槽钢_开向右(型号, x, -伸量, 下梁Y + 伸量, 0.0, 材质)
                else:
                    构件 = 竖向槽钢_开向左(型号, x, -伸量, 下梁Y + 伸量, 0.0, 材质)
            if 构件:
                构件记录.append(
                    槽钢记录字典(
                        构件编号="CG-S-{0:02d}".format(i + 1),
                        构件名称="下部附加槽钢{0:02d}".format(i + 1),
                        构件类别="下部附加竖向槽钢",
                        型号=型号,
                        开口方向="向右" if 开向右 else "向左",
                        起点=(x, -伸量, 0.0),
                        终点=(x, 下梁Y + 伸量, 0.0),
                        几何体=构件,
                        是否开孔=是否开孔,
                        孔数=2 if 是否开孔 else 0,
                        孔径=中间孔径 if 是否开孔 else 0.0,
                        孔间距=中间孔间距 if 是否开孔 else 0.0,
                        孔组中心Y=穿线排中心Y + 中间孔组偏移 if 是否开孔 else None,
                        钢材牌号=牌号,
                    )
                )

        if not 构件记录:
            self._写入槽钢属性([], 型号, 外层型号)
            self["输出模型"] = translate(0, 0, 0) * scale(100, 100, 100) * Cube()
            return

        self._写入槽钢属性(构件记录, 型号, 外层型号)

        部件 = [记录["geometry"] for 记录 in 构件记录]
        结果 = 部件[0] if len(部件) == 1 else combine(*部件)

        self["输出模型"] = translate(self["X"], self["Y"], self["Z"]) * 结果

    def _确保槽钢明细属性(self, 目标数量):
        当前容量 = int(self["槽钢明细属性容量"]) if self["槽钢明细属性容量"] else 0
        if 当前容量 >= 目标数量:
            return 当前容量

        for i in range(当前容量 + 1, 目标数量 + 1):
            前缀 = "槽钢{0:02d}".format(i)
            self[前缀 + "_ID"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_名称"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_类别"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_型号"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_长度mm"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_截面面积mm2"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_理论重量kg"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_容许弯矩kN·m"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_承重kg"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_开口方向"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_起点"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_终点"] = Attr("", obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_开孔数"] = Attr(0, obvious=False, readonly=True, group="槽钢明细")
            self[前缀 + "_孔径mm"] = Attr(0.0, obvious=False, readonly=True, group="槽钢明细")

        self["槽钢明细属性容量"] = 目标数量
        return 目标数量

    def _清空槽钢槽位(self, 索引):
        前缀 = "槽钢{0:02d}".format(索引)
        self[前缀 + "_ID"] = ""
        self[前缀 + "_名称"] = ""
        self[前缀 + "_类别"] = ""
        self[前缀 + "_型号"] = ""
        self[前缀 + "_长度mm"] = 0.0
        self[前缀 + "_截面面积mm2"] = 0.0
        self[前缀 + "_理论重量kg"] = 0.0
        self[前缀 + "_容许弯矩kN·m"] = 0.0
        self[前缀 + "_承重kg"] = 0.0
        self[前缀 + "_开口方向"] = ""
        self[前缀 + "_起点"] = ""
        self[前缀 + "_终点"] = ""
        self[前缀 + "_开孔数"] = 0
        self[前缀 + "_孔径mm"] = 0.0

    def _写入槽钢属性(self, 构件记录, 型号, 外层型号):
        数量 = len(构件记录)
        容量 = self._确保槽钢明细属性(数量)
        总重量 = 0.0
        内层承重合计 = 0.0
        外层承重合计 = 0.0
        可序列化记录 = []

        for i, 记录 in enumerate(构件记录, start=1):
            前缀 = "槽钢{0:02d}".format(i)
            self[前缀 + "_ID"] = 记录["id"]
            self[前缀 + "_名称"] = 记录["name"]
            self[前缀 + "_类别"] = 记录["category"]
            self[前缀 + "_型号"] = 记录["profile"]
            self[前缀 + "_长度mm"] = 记录["length_mm"]
            self[前缀 + "_截面面积mm2"] = 记录["section_area_mm2"]
            self[前缀 + "_理论重量kg"] = 记录["weight_kg"]
            self[前缀 + "_容许弯矩kN·m"] = 记录["allowable_moment_kNm"]
            self[前缀 + "_承重kg"] = 记录["capacity_kg"]
            self[前缀 + "_开口方向"] = 记录["opening_direction"]
            self[前缀 + "_起点"] = 记录["start_point_text"]
            self[前缀 + "_终点"] = 记录["end_point_text"]
            self[前缀 + "_开孔数"] = 记录["hole_count"]
            self[前缀 + "_孔径mm"] = 记录["hole_diameter_mm"]
            总重量 += float(记录["weight_kg"])
            if 记录["profile"] == 外层型号 and 记录["profile"] != 型号:
                外层承重合计 += float(记录["capacity_kg"])
            else:
                内层承重合计 += float(记录["capacity_kg"])

            单根记录 = dict(记录)
            单根记录.pop("geometry", None)
            可序列化记录.append(单根记录)

        for i in range(数量 + 1, 容量 + 1):
            self._清空槽钢槽位(i)

        self["槽钢总数"] = 数量
        self["理论总重量kg"] = round(总重量, 6)
        self["内层槽钢承重合计kg"] = round(内层承重合计, 3)
        self["外层槽钢承重合计kg"] = round(外层承重合计, 3)
        self["总承重kg"] = round(内层承重合计 + 外层承重合计, 3)
        self["槽钢ID汇总"] = ", ".join([记录["id"] for 记录 in 构件记录])
        self["槽钢明细JSON"] = json.dumps(可序列化记录, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    FinalGeometry = 槽钢底座()
    place(FinalGeometry)
