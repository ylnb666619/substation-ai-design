# -*- coding: utf-8 -*-
from pyp3d import *
import math


# ═══════════════════════════════════════════════════════════════
# 屋面面层（分层做法 + 密封体系）
#   覆盖在三角桁架/屋面龙骨上方，双坡面板，分层建模：
#     隔汽层 → 保温层(缩进) → 防水层 → 压型钢板基底 + 梯形波脊
#   附件：屋脊盖板 + 檐口泛水(含滴水折边)
#   密封：屋脊密封条 + 山墙泛水板(Z形封边)
#   一点放置
# ═══════════════════════════════════════════════════════════════

class 屋面面层(Component):
    """双坡屋面板：多层构造，匹配预制舱围护体系实际做法。"""

    def __init__(self):
        Component.__init__(self)
        self["输出模型"] = Attr(None, show=True)

        # 构件分类（只读）
        self["场布分类"] = Attr("建/构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("屋架/屋面", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("屋面面层", obvious=True, readonly=True, group="构件分类")

        # 屋面尺寸
        self["整体长度"] = Attr(12100.0, obvious=True, group="屋面尺寸", description="屋面总长 X(mm)")
        self["整体宽度"] = Attr(3500.0, obvious=True, group="屋面尺寸", description="屋面总宽 Y(mm)")
        self["起坡高度"] = Attr(250.0, obvious=True, group="屋面尺寸", description="屋脊高出檐口(mm)，3.5m宽时≈7%坡度")
        self["端部外伸"] = Attr(100.0, obvious=True, group="屋面尺寸", description="面板两端 X 向伸出(mm)")
        self["檐口外伸"] = Attr(100.0, obvious=True, group="屋面尺寸", description="面板檐口 Y 向伸出(mm)")
        self["消除穿模"] = Attr(True, obvious=True, group="屋面尺寸", description="布尔并集融合屋脊(慢但干净)")

        # 压型板
        self["面板厚"] = Attr(1.0, obvious=True, group="压型板", description="压型钢板基底厚度(mm)")
        self["波高"] = Attr(51.0, obvious=True, group="压型板", description="梯形波凸起高度(mm)")
        self["波距"] = Attr(250.0, obvious=True, group="压型板", description="相邻波峰间距(mm)")
        self["波底宽"] = Attr(150.0, obvious=True, group="压型板", description="梯形波底部宽度(mm)")
        self["波顶宽"] = Attr(100.0, obvious=True, group="压型板", description="梯形波顶部宽度(mm)")

        # 功能层
        self["防水层厚"] = Attr(3.0, obvious=True, group="功能层", description="防水卷材/涂料厚度(mm)，0=跳过")
        self["保温层厚"] = Attr(75.0, obvious=True, group="功能层", description="岩棉/EPS 保温层厚度(mm)，0=跳过")
        self["隔汽层厚"] = Attr(1.0, obvious=True, group="功能层", description="PE 膜/铝箔隔汽层厚度(mm)，0=跳过")
        self["保温缩进"] = Attr(30.0, obvious=True, group="功能层", description="保温层边缘距面板边的缩进(mm)")

        # 附件
        self["屋脊盖板宽"] = Attr(300.0, obvious=True, group="附件", description="屋脊盖板总宽度(mm)")
        self["屋脊盖板厚"] = Attr(2.0, obvious=True, group="附件", description="屋脊盖板厚度(mm)")
        self["檐口泛水深"] = Attr(50.0, obvious=True, group="附件", description="檐口泛水板下折深度(mm)")

        # 密封件
        self["屋脊密封条宽"] = Attr(50.0, obvious=True, group="密封件", description="屋脊密封条宽度(mm)，垫在盖板下")
        self["屋脊密封条厚"] = Attr(3.0, obvious=True, group="密封件", description="屋脊密封条厚度(mm)，0=跳过")
        self["山墙泛水板厚"] = Attr(1.5, obvious=True, group="密封件", description="山墙泛水板厚度(mm)，0=跳过")
        self["山墙泛水板高"] = Attr(80.0, obvious=True, group="密封件", description="山墙泛水板高度(mm)，含上翻+下折")
        self["屋脊填充"] = Attr(True, obvious=True, group="密封件", description="填充屋脊V形缺口，消除贯穿性缝隙")

        # 定位
        self["X"] = Attr(0.0, obvious=True, group="定位", description="插入点 X 坐标(mm)")
        self["Y"] = Attr(0.0, obvious=True, group="定位", description="插入点 Y 坐标(mm)")
        self["Z"] = Attr(0.0, obvious=True, group="定位", description="插入点 Z 坐标(mm)")

        # 自定义材质
        self["面板颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["防水层颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["保温层颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["隔汽层颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["屋脊盖板颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["檐口泛水颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["屋脊密封条颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["山墙泛水颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")
        self["屋脊填充颜色"] = Attr("", obvious=True, material=True, group="自定义材质项")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        # ── 参数读取与校验 ──
        L = self["整体长度"]
        W = self["整体宽度"]
        H = self["起坡高度"]
        if L < 500:
            L = 500; self["整体长度"] = L
        if W < 500:
            W = 500; self["整体宽度"] = W
        if H < 30:
            H = 30; self["起坡高度"] = H

        面板厚 = max(self["面板厚"], 1.0); self["面板厚"] = 面板厚
        波高 = max(self["波高"], 5.0); self["波高"] = 波高
        波距 = max(self["波距"], 30.0); self["波距"] = 波距
        波底宽 = max(self["波底宽"], 10.0); self["波底宽"] = 波底宽
        波顶宽 = max(self["波顶宽"], 5.0); self["波顶宽"] = 波顶宽
        防水层厚 = max(self["防水层厚"], 0.0); self["防水层厚"] = 防水层厚
        保温层厚 = max(self["保温层厚"], 0.0); self["保温层厚"] = 保温层厚
        隔汽层厚 = max(self["隔汽层厚"], 0.0); self["隔汽层厚"] = 隔汽层厚
        保温缩进 = max(self["保温缩进"], 0.0); self["保温缩进"] = 保温缩进
        屋脊盖板宽 = max(self["屋脊盖板宽"], 0.0); self["屋脊盖板宽"] = 屋脊盖板宽
        屋脊盖板厚 = max(self["屋脊盖板厚"], 0.5); self["屋脊盖板厚"] = 屋脊盖板厚
        檐口泛水深 = max(self["檐口泛水深"], 0.0); self["檐口泛水深"] = 檐口泛水深
        屋脊密封条宽 = max(self["屋脊密封条宽"], 10.0); self["屋脊密封条宽"] = 屋脊密封条宽
        屋脊密封条厚 = max(self["屋脊密封条厚"], 0.0); self["屋脊密封条厚"] = 屋脊密封条厚
        山墙泛水板厚 = max(self["山墙泛水板厚"], 0.0); self["山墙泛水板厚"] = 山墙泛水板厚
        山墙泛水板高 = max(self["山墙泛水板高"], 20.0); self["山墙泛水板高"] = 山墙泛水板高

        overhang_x = max(self["端部外伸"], 0)
        overhang_y = max(self["檐口外伸"], 0)
        融合 = self["消除穿模"]

        面板色 = self["面板颜色"]
        防水色 = self["防水层颜色"]
        保温色 = self["保温层颜色"]
        隔汽色 = self["隔汽层颜色"]
        盖板色 = self["屋脊盖板颜色"]
        泛水色 = self["檐口泛水颜色"]
        密封条色 = self["屋脊密封条颜色"]
        山墙泛水色 = self["山墙泛水颜色"]
        屋脊填充色 = self["屋脊填充颜色"]

        # 波形约束：这里的“顶宽/底宽”用于俯视梯形轮廓
        if 波顶宽 >= 波底宽:
            波顶宽 = 波底宽 * 0.5; self["波顶宽"] = 波顶宽
        if 波距 < 波底宽 * 1.2:
            波距 = 波底宽 * 1.2; self["波距"] = 波距
        _预板长 = L + max(self["端部外伸"], 0) * 2
        if 波距 > _预板长 * 0.8:
            波距 = _预板长 * 0.5; self["波距"] = 波距

        # ── 坡度几何 ──
        半宽 = W * 0.5
        坡角 = math.atan2(H, 半宽)
        坡长 = math.sqrt(半宽 ** 2 + H ** 2)
        外伸斜面 = overhang_y / math.cos(坡角)
        坡面斜长 = 坡长 + 外伸斜面
        板长X = L + overhang_x * 2
        屋脊额外抬高 = overhang_y * math.tan(坡角)

        # 保温缩进不能吃掉整块板
        max_setback = min(L * 0.2, W * 0.2, 坡面斜长 * 0.3)
        if 保温缩进 > max_setback:
            保温缩进 = max_setback; self["保温缩进"] = 保温缩进

        def 构建单侧(起点X, 起点Y, 起点Z, 坡角值, 建屋脊盖板, 建檐口泛水, 屋脊在远端=True, 建山墙泛水=True):
            """构建一侧坡面的所有层 + 附件 + 密封件"""
            parts = []
            z = 0.0

            def 着色(geom, color):
                return geom.material(color) if color else geom

            # 1. 隔汽层
            if 隔汽层厚 >= 0.5:
                parts.append(着色(translate(0, 0, z) * scale(板长X, 坡面斜长, 隔汽层厚) * Cube(), 隔汽色))
                z += 隔汽层厚

            # 2. 保温层
            if 保温层厚 >= 0.5:
                s = 保温缩进
                parts.append(着色(translate(s, s, z) * scale(板长X - 2 * s, 坡面斜长 - 2 * s, 保温层厚) * Cube(), 保温色))
                z += 保温层厚

            # 3. 防水层
            if 防水层厚 >= 0.5:
                parts.append(着色(translate(0, 0, z) * scale(板长X, 坡面斜长, 防水层厚) * Cube(), 防水色))
                z += 防水层厚

            # 4. 压型钢板基底平板
            parts.append(着色(translate(0, 0, z) * scale(板长X, 坡面斜长, 面板厚) * Cube(), 面板色))
            波基Z = z + 面板厚

            # 5. 长条梯形波脊（俯视为长条矩形，前视为梯形）
            排布宽 = 波底宽
            波数 = max(1, int((板长X - 排布宽) / 波距) + 1)
            波起点 = max(排布宽 * 0.5, (板长X - (波数 - 1) * 波距) * 0.5)
            for i in range(波数):
                x_ctr = 波起点 + i * 波距
                底端X = x_ctr - 波底宽 * 0.5
                顶端X = x_ctr - 波顶宽 * 0.5
                wave = Box(Vec3(底端X, 0, 波基Z), Vec3(顶端X, 0, 波基Z + 波高),
                          Vec3(1, 0, 0), Vec3(0, 1, 0), 波底宽, 坡面斜长, 波顶宽, 坡面斜长)
                parts.append(着色(wave, 面板色))

            总厚 = 波基Z + 波高
            屋脊Y = 坡面斜长 if 屋脊在远端 else 0.0

            # 6. 屋脊盖板
            if 建屋脊盖板 and 屋脊盖板宽 > 0 and 屋脊盖板厚 >= 0.5:
                半盖 = 屋脊盖板宽 * 0.5
                盖板Z = 总厚 + (屋脊密封条厚 if 屋脊密封条厚 >= 0.5 else 0.0)
                parts.append(着色(translate(0, 屋脊Y - (半盖 if 屋脊在远端 else 0.0), 盖板Z)
                            * scale(板长X, 半盖, 屋脊盖板厚) * Cube(), 盖板色))

            # 7. 檐口泛水
            if 建檐口泛水 and 檐口泛水深 > 0:
                檐口Y = 0.0 if 屋脊在远端 else 坡面斜长
                滴水折边 = 10.0
                parts.append(着色(translate(0, 檐口Y, -檐口泛水深) * scale(板长X, 面板厚 * 2, 檐口泛水深) * Cube(), 泛水色))
                parts.append(着色(translate(0, 檐口Y, -檐口泛水深 - 滴水折边) * scale(板长X, 面板厚 * 4, 滴水折边) * Cube(), 泛水色))

            # 8. 屋脊密封条
            if 建屋脊盖板 and 屋脊密封条宽 > 0 and 屋脊密封条厚 >= 0.5:
                条Y0 = 屋脊Y - (屋脊密封条宽 if 屋脊在远端 else 0.0)
                parts.append(着色(translate(0, 条Y0, 总厚) * scale(板长X, 屋脊密封条宽, 屋脊密封条厚) * Cube(), 密封条色))

            # 9. 山墙泛水板
            if 建山墙泛水 and 山墙泛水板厚 >= 0.5 and 山墙泛水板高 > 0:
                上翻高 = 山墙泛水板高 * 0.4
                下折深 = 山墙泛水板高 * 0.6
                for 端X in [0, 板长X - 山墙泛水板厚]:
                    parts.append(着色(translate(端X, 0, 0) * scale(山墙泛水板厚, 坡面斜长, 上翻高) * Cube(), 山墙泛水色))
                    parts.append(着色(translate(端X, 0, -下折深) * scale(山墙泛水板厚, 坡面斜长, 下折深) * Cube(), 山墙泛水色))
                    if 建檐口泛水 and 檐口泛水深 > 0:
                        檐口端Y = 0.0 if 屋脊在远端 else 坡面斜长
                        转角包边 = 面板厚 + 波高
                        parts.append(着色(translate(端X, 檐口端Y, -檐口泛水深)
                                    * scale(山墙泛水板厚, 面板厚 * 2, 檐口泛水深 + 转角包边) * Cube(), 山墙泛水色))

            local_geom = combine(*parts)
            return translate(起点X, 起点Y, 起点Z) * rotation(Vec3(1, 0, 0), 坡角值) * local_geom

        # ── 左坡 & 右坡 ──
        左侧 = 构建单侧(起点X=-overhang_x, 起点Y=-overhang_y, 起点Z=0, 坡角值=坡角, 建屋脊盖板=True, 建檐口泛水=True)
        右侧 = 构建单侧(起点X=-overhang_x, 起点Y=半宽, 起点Z=H + 屋脊额外抬高, 坡角值=-坡角,
                     建屋脊盖板=True, 建檐口泛水=True, 屋脊在远端=False)

        # ── 屋脊V形缺口填充 ──
        if 融合:
            result = 左侧 + 右侧
        else:
            result = combine(左侧, 右侧)

        if self["屋脊填充"]:
            _实隔汽 = 隔汽层厚 if 隔汽层厚 >= 0.5 else 0.0
            _实保温 = 保温层厚 if 保温层厚 >= 0.5 else 0.0
            _实防水 = 防水层厚 if 防水层厚 >= 0.5 else 0.0
            外总厚 = _实隔汽 + _实保温 + _实防水 + 面板厚 + 波高
            缺口顶宽 = 2 * 外总厚 * math.sin(坡角)
            内表面Z = H + 屋脊额外抬高
            if 缺口顶宽 > 0.5:
                填充块 = translate(-overhang_x, 半宽 - 缺口顶宽 * 0.5, 内表面Z) * scale(板长X, 缺口顶宽, 外总厚) * Cube()
                if 屋脊填充色:
                    填充块 = 填充块.material(屋脊填充色)
                if 融合:
                    result = result + 填充块
                else:
                    result = combine(result, 填充块)

        self["输出模型"] = translate(self["X"], self["Y"], self["Z"]) * result

        # —— 自重：双坡展开面积 × 面板厚 × 钢 ——
        _L = float(self["整体长度"]); _W = float(self["整体宽度"])
        _h = float(self["起坡高度"]); _t = float(self["面板厚"])
        _slope = ((_W / 2.0) ** 2 + _h ** 2) ** 0.5 if _h > 0 else _W / 2.0
        _area = _L * (2.0 * _slope if _h > 0 else _W)
        self["自重_kg"] = round(_area * _t * 7850.0 / 1e9, 2)


if __name__ == "__main__":
    FinalGeometry = 屋面面层()
    place(FinalGeometry)
