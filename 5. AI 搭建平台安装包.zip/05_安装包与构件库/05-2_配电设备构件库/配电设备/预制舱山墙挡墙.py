# -*- coding: utf-8 -*-
"""
================================================================================
 BIMBase PyP3d 参数化 预制舱山墙挡墙（三角复合墙，双坡收顶）

 构件说明：
   · 用于预制舱刚架两端山墙位置的三角填充挡墙：下口平坐复合墙顶(共面)，
     两斜边沿屋面坡度收口藏入屋面面层(简)之下
   · 三层夹芯做法与"三层复合墙"一致：外波纹金属板 + 保温层 + 内护板，
     上口用布尔求差沿双坡切平(平滑斜边，无锯齿)
   · 波纹轮廓在波峰两肩与波谷处圆角过渡(参数"波纹圆角")，曲线平滑接近
     冷弯成型钢板；设为 0 可退回直角梯形波
   · 关键参数与 屋面龙骨 / 屋面面层(简) 同名同默认：
       整体宽度(W)=底边长度(沿Y, 默认3500)，起坡高度(H)=屋脊高出檐口(默认500)
     ⇒ 只要设成与它们相同的值，坡角/底宽/脊线即自动一致，接缝共面
   · 默认底部 Z=0（与下部复合墙顶平齐），顶边比坡线低"上口缩量"，藏于屋面板下

 坐标系：
   X = 墙厚方向(波纹朝 -X 外露，内护板朝 +X)，Y = 底边/山墙宽度方向，
   Z = 高度方向，底边中心在原点（屋脊在 Y=0 上方）
================================================================================
"""

from pyp3d import *
from math import acos, tan


# ============================================================================
# 【1】辅助函数（与三层复合墙一致；另加"坡切楔"用于上口切坡）
# ============================================================================

def _切点距(A, B, C, r):
    """角点 B 处圆角的切点距 t=r/tan(φ/2)，限制不越过任一邻边的 45%。"""
    bax, bay = A[0] - B[0], A[1] - B[1]
    bcx, bcy = C[0] - B[0], C[1] - B[1]
    la = (bax * bax + bay * bay) ** 0.5
    lc = (bcx * bcx + bcy * bcy) ** 0.5
    if la < 1e-9 or lc < 1e-9:
        return 0.0
    cosv = (bax * bcx + bay * bcy) / (la * lc)
    t = r / tan(acos(max(-1.0, min(1.0, cosv))) * 0.5)
    return min(t, 0.45 * la, 0.45 * lc)


def _圆角采样(A, B, C, r, n=8):
    """折线 A→B→C 在角点 B 处的圆角采样点（两切点间二次贝塞尔，切向连续）。"""
    t = _切点距(A, B, C, r)
    if t <= 1e-9:
        return [Vec2(B[0], B[1])]
    bax, bay = A[0] - B[0], A[1] - B[1]
    bcx, bcy = C[0] - B[0], C[1] - B[1]
    la = (bax * bax + bay * bay) ** 0.5
    lc = (bcx * bcx + bcy * bcy) ** 0.5
    t1x, t1y = B[0] + bax / la * t, B[1] + bay / la * t
    t2x, t2y = B[0] + bcx / lc * t, B[1] + bcy / lc * t
    pts = []
    for i in range(n + 1):
        s = i / float(n)
        u = 1.0 - s
        pts.append(Vec2(u * u * t1x + 2 * u * s * B[0] + s * s * t2x,
                        u * u * t1y + 2 * u * s * B[1] + s * s * t2y))
    return pts


def _波纹截面(spc, dep, thk, 顶宽比=0.35, 圆角=12.0, 首波=False):
    """单个（圆角过渡）梯形波纹的 2D 闭合截面（x=沿墙长/波距, y=厚度方向）。

    波峰两肩与波谷用圆角平滑过渡；左波谷的圆角并入右谷一次性做出，
    相邻单元拼接处仍为同一条圆角线，不重复不缺角。
    首波=True 时左端保持平口波谷(起点 x=0)，与山墙端头平齐。
    """
    顶半宽 = spc * 顶宽比 * 0.5
    坡起 = spc * 0.5 - 顶半宽
    坡止 = spc * 0.5 + 顶半宽
    if 圆角 <= 1e-9 or 坡起 <= 1e-9 or dep <= 1e-9:
        return Section(
            Vec2(0, 0),
            Vec2(坡起, dep),
            Vec2(坡止, dep),
            Vec2(spc, 0),
            Vec2(spc, -thk),
            Vec2(0, -thk),
        )
    L = (坡起 * 坡起 + dep * dep) ** 0.5
    ux, uy = 坡起 / L, dep / L                # 左坡上行单位向量
    tv = _切点距((坡止, dep), (spc, 0), (spc + 坡起, dep), 圆角)   # 波谷切点距

    if 首波:
        pts = [Vec2(0, 0)]                                      # 首波左端平口
    else:
        pts = [Vec2(ux * tv, uy * tv)]                          # 左谷圆角后切点起步
    pts += _圆角采样((0, 0), (坡起, dep), (坡止, dep), 圆角)                # 左肩
    pts += _圆角采样((坡起, dep), (坡止, dep), (spc, 0), 圆角)              # 右肩
    pts += _圆角采样((坡止, dep), (spc, 0), (spc + 坡起, dep), 圆角)        # 右谷(连下一波)
    pts += [Vec2(spc + ux * tv, -thk), Vec2(ux * tv, -thk)]                 # 右缘、底面、闭合
    return Section(*pts)


def _平板(L, T, H):
    """平板，厚度 T 作为 Y 轴负方向偏移（复合墙本地系）。"""
    return trans(0, -T, 0) * scale(L, T, H) * Cube()


def _坡切楔(YZ多边形, x起点, x长):
    """沿 X(墙厚)方向扫掠一个 YZ 平面四边形，作为布尔求差用的切坡体。

    Section 在 XOY、扫掠沿局部 Z，再用 R_y(+90°) 把扫掠方向转到 +X：
    此时局部截面坐标 → 世界 (y=sy, z=-sx)，故传 Vec2(-z, y)。
    """
    sec = Section(*[Vec2(-z, y) for (y, z) in YZ多边形])
    w = Sweep(sec, Line(Vec3(0, 0, 0), Vec3(0, 0, x长)))
    w = rotation(Vec3(0, 1, 0), pi / 2) * w
    return translate(x起点, 0, 0) * w


def _转置到挡墙系(g):
    """复合墙本地系(长沿X/厚沿Y/高沿Z) → 挡墙本地系(厚沿X/底边沿Y/高沿Z)。
    绕 Z 转 +90°：(x,y,z)→(-y,x,z)。"""
    return rotation(Vec3(0, 0, 1), pi / 2) * g


def 差集(a, b):
    """兼容不同运行环境的布尔差集（同槽钢底座.py）。"""
    try:
        return Cut(a, b)
    except Exception:
        if "substract" in globals():
            return substract(a, b)
        return a


# ============================================================================
# 【2】默认几何参数
# ============================================================================

GABLE_WIDTH   = 3500.0     # 底边长度(整体宽度 Y,mm) — 与屋面龙骨/面层同名
RIDGE_HEIGHT  = 500.0      # 起坡高度(屋脊高出檐口 Z,mm)
TOP_SINK      = 3.0        # 上口缩量：顶边比坡线低出的量(mm)，藏入屋面板下


# ============================================================================
# 【3】BIMBase 参数化组件类
# ============================================================================

class 预制舱山墙挡墙(Component):
    """预制舱山墙挡墙 — 三角复合墙，双坡收顶，下口平坐复合墙顶。"""

    def __init__(self):
        Component.__init__(self)
        self["预制舱山墙挡墙"] = Attr(None, show=True)

        # 构件分类信息
        self["场布分类"] = Attr("建/构筑物", obvious=True, readonly=True, group="构件分类")
        self["构件类型"] = Attr("墙、板", obvious=True, readonly=True, group="构件分类")
        self["构件名称"] = Attr("预制舱山墙挡墙(三角复合墙)", obvious=True, readonly=True,
                                group="构件分类")

        # 总体尺寸（与屋面龙骨/屋面面层同名同默认，设相同值即接缝共面）
        self["整体宽度"] = Attr(GABLE_WIDTH, obvious=True, group="总体尺寸",
                                description="山墙底边长度 Y(mm)，应=屋面龙骨/面层 整体宽度")
        self["起坡高度"] = Attr(RIDGE_HEIGHT, obvious=True, group="总体尺寸",
                                description="屋脊高出檐口(mm)，应=屋面龙骨/面层 起坡高度")
        self["上口缩量"] = Attr(TOP_SINK, obvious=True, group="总体尺寸",
                                description="顶边低于屋面坡线的高度(mm)，藏入屋面板下")

        # 组合总厚度（只读，三层自动求和，不含波峰外凸）
        self["总厚度"] = Attr(0.0, obvious=False, readonly=True, group="总体尺寸",
                              description="三层总厚度(mm)")

        # 外层：波纹金属板（同三层复合墙）
        self["外层厚度"] = Attr(0.6, obvious=True, group="外层波纹板",
                                description="基板厚度(mm)")
        self["波纹间距"] = Attr(210.0, obvious=True, group="外层波纹板",
                                description="单个波纹宽度(mm)")
        self["波纹深度"] = Attr(35.0, obvious=True, group="外层波纹板",
                                description="波纹凸起高度(mm)")
        self["波峰宽比"] = Attr(0.35, obvious=True, group="外层波纹板",
                                description="波峰平台宽/波距比例(0.1~0.8)")
        self["波纹圆角"] = Attr(12.0, obvious=True, group="外层波纹板",
                                description="波峰/波谷圆角半径(mm)，0=直角梯形波")
        self["外板材质"] = Attr("", obvious=True, material=True, group="外层波纹板",
                                description="推荐镀铝锌AZ150或氟碳彩涂")

        # 中层：保温层
        self["保温厚度"] = Attr(100.0, obvious=True, group="中层保温",
                                description="岩棉/玻璃棉厚度(mm)")
        self["保温材质"] = Attr("", obvious=True, material=True, group="中层保温",
                                description="推荐A级不燃岩棉")

        # 内层：内护板
        self["内层厚度"] = Attr(0.6, obvious=True, group="内墙板",
                                description="内侧护板厚度(mm)")
        self["内板材质"] = Attr("", obvious=True, material=True, group="内墙板",
                                description="推荐哑光白聚酯彩涂板")

        # 定位参数（底边中心/屋脊投影点）
        self["X"] = Attr(0.0, obvious=True, group="定位")
        self["Y"] = Attr(0.0, obvious=True, group="定位")
        self["Z"] = Attr(0.0, obvious=True, group="定位")

        self["自重_kg"] = Attr(0.0, obvious=True, readonly=True, group="力学信息", description="构件理论自重(kg)：由几何尺寸与材料密度自动计算，供恒载统计读取")

        self.replace()

    @export
    def replace(self):
        W = float(self["整体宽度"])     # 底边长度（Y，山墙跨度）
        H = float(self["起坡高度"])     # 屋脊高出檐口（Z）
        inset = float(self["上口缩量"]) # 顶边内藏量
        t_out = float(self["外层厚度"])
        spc = float(self["波纹间距"])
        dep = float(self["波纹深度"])
        ratio = float(self["波峰宽比"])
        fil = float(self["波纹圆角"])
        t_ins = float(self["保温厚度"])
        t_in = float(self["内层厚度"])
        t_tot = t_out + t_ins + t_in
        self["总厚度"] = t_tot

        # ── 参数校验 ──
        if W < 500:
            W = 500; self["整体宽度"] = W
        if H < 50:
            H = 50; self["起坡高度"] = H
        if spc < 20:
            spc = 20; self["波纹间距"] = spc
        if dep < 5:
            dep = 5; self["波纹深度"] = dep
        if fil < 0:
            fil = 0.0; self["波纹圆角"] = fil
        if inset < 0:
            inset = 0.0; self["上口缩量"] = inset
        if inset > H * 0.4:
            inset = H * 0.4; self["上口缩量"] = inset

        # ══════════════════════════════════════════════════════
        # 1. 先在"复合墙本地系"里造三层矩形件（长=W沿X, 高=H沿Z, 厚沿-Y）
        #    再整体转90°到挡墙系（厚沿X, 底边沿Y, 高沿Z），并居中(Y-半宽)
        # ══════════════════════════════════════════════════════
        n = int(W / spc)
        rem = W - n * spc

        def 转中(件):
            return translate(0, -W * 0.5, 0) * _转置到挡墙系(件)

        # ── 外层波纹板（矩形，顶先到 H，上口待切）──
        外层 = combine()
        if n > 0:
            wave_unit = Sweep(_波纹截面(spc, dep, t_out, ratio, fil),
                              Line(Vec3(0, 0, 0), Vec3(0, 0, H)))
            wave_first = Sweep(_波纹截面(spc, dep, t_out, ratio, fil, 首波=True),
                               Line(Vec3(0, 0, 0), Vec3(0, 0, H)))
            if self["外板材质"]:
                wave_unit = wave_unit.material(self["外板材质"])
                wave_first = wave_first.material(self["外板材质"])
            for i in range(n):
                单元 = wave_first if i == 0 else wave_unit
                外层.append(trans(i * spc, 0, 0) * 单元)
        if rem > 1:
            tail = _平板(rem, t_out, H)
            if self["外板材质"]:
                tail = tail.material(self["外板材质"])
            外层.append(trans(n * spc, 0, 0) * tail)

        # ── 中层保温板 ──
        保温 = trans(0, -t_out, 0) * _平板(W, t_ins, H)
        if self["保温材质"]:
            保温 = 保温.material(self["保温材质"])

        # ── 内墙板 ──
        内板 = trans(0, -t_out - t_ins, 0) * _平板(W, t_in, H)
        if self["内板材质"]:
            内板 = 内板.material(self["内板材质"])

        # ══════════════════════════════════════════════════════
        # 2. 上口双坡切平（平滑斜边）
        #    墙厚 X 覆盖范围 [ -dep(波峰外露侧), t_tot(内板背侧) ]，
        #    切坡楔在其两侧各放 2mm 余量，保证一次切透。
        #    两楔 YZ 剖面为四边形：底边到(坡线-缩量)的斜边＋竖直回到顶，
        #    可把矩形顶部坡线以上的全部材料移除（含近屋脊的薄条）。
        # ══════════════════════════════════════════════════════
        m = 2.0
        x0 = -dep - m
        xlen = (t_tot + dep) + 2.0 * m
        hc = H - inset                     # 收口后的屋脊顶点高
        b = W * 0.5                        # 半底宽

        左楔 = _坡切楔([(-b, -m), (0, hc), (0, H), (-b, H)], x0, xlen)
        右楔 = _坡切楔([(b, -m), (0, hc), (0, H), (b, H)], x0, xlen)

        件_外 = 差集(差集(转中(外层), 左楔), 右楔)
        件_保 = 差集(差集(转中(保温), 左楔), 右楔)
        件_内 = 差集(差集(转中(内板), 左楔), 右楔)

        合 = combine(件_外, 件_保, 件_内)

        # 定位
        dx = float(self["X"])
        dy = float(self["Y"])
        dz = float(self["Z"])
        self["预制舱山墙挡墙"] = translate(dx, dy, dz) * 合

        # —— 自重：三角形面积 × 三层夹芯 ——
        _W = float(self["整体宽度"]); _H = float(self["起坡高度"])
        _to = float(self["外层厚度"]); _ti = float(self["内层厚度"]); _tc = float(self["保温厚度"])
        self["自重_kg"] = round(0.5 * _W * _H * (_to * 1.15 * 7850.0 + _ti * 1.15 * 7850.0 + _tc * 110.0) / 1e9, 2)


# ============================================================================
# 【4】插件执行入口
# ============================================================================

if __name__ == "__main__":
    FinalGeometry = 预制舱山墙挡墙()
    place(FinalGeometry)
